This is the first release of Plushplayer and Matedit.

Plushplayer
=======
You can load any *.scx (Scene XML) file in the "mods" folder.
Use F3 to popup the file open dialog.

In the scene, you can navigate using the mouse and the following buttons:
w - step forward
a - step left
s - step backward
d - step right

Matedit
=====
You can modify the material using various sliders.
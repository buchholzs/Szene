/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#ifndef MX_PLATFORM_ALLEGRO
#define MX_PLATFORM_DEGFX
#endif

/* The core DEPUI files and optional components */
#include "depui/src/core.c"
#include "depui/src/slider.c"
#include "depui/src/scroll.c"
#include "depui/src/list.c"
#include "depui/src/gfxmode.c"
#include "depui/src/filesel.c"

/* Figure out the themes to include */
#ifdef MX_THEME_ALL
#define MX_THEME_DEFAULT
#define MX_THEME_WIN95
#define MX_THEME_MONO
#define MX_THEME_ROUNDED
#endif

/* The themes */
#include "depui/src/allegro/default.c"
#include "depui/src/allegro/win95.c"
#include "depui/src/allegro/mono.c"
#include "depui/src/degfx/default.c"
#include "depui/src/degfx/win95.c"
#include "depui/src/degfx/mono.c"
#include "depui/src/degfx/rounded.c"

#ifndef MX_THEME_EXISTS
#define MX_THEME_DEFAULT
#include "depui/src/allegro/default.c"
#include "depui/src/degfx/default.c"
#endif

/* The platforms */
#include "depui/src/allegro/allegro.c"
#include "depui/src/degfx/degfx.c"

/* Warn for missing platform or theme */
#ifndef MX_PLATFORM_EXISTS
#error Sorry no platform found
#endif

#ifndef MX_THEME_EXISTS
#error Sorry no theme found
#endif

/* Bring in supporting libs */
#define MX_DETK_ATOM
#define MX_DETK_RECTATOM
#define MX_DETK_STRING
#include "detk/detk.c"

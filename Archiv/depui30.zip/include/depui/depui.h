/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#ifndef MX_DEPUI_HEADER
#define MX_DEPUI_HEADER

#include "detk/detk.h"
#include <limits.h>
#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

/*--------------------------------------------------------------------------*/
#define MX_DEPUI_VERSION 3
#define MX_DEPUI_SUBVERSION 0

/* Base objects */
struct MX_OBJ;
struct MX_DERIVED;
struct MX_TEXTUAL;
struct MX_BUTTON;
struct MX_WIN;
struct MX_WINBORDER;

struct MX_THEME;

/* Optional objects */
struct MX_SLIDER;
struct MX_SCROLL;
struct MX_LISTELEM;
struct MX_LIST;

/* Main functions */
int mx_guimain(int argc, char *argv[]);

unsigned mx_start(void);
int mx_execute(void);

void mx__gui_redraw(const MX_RECT * rect);

/* Event handling */
typedef enum MX_EVENT {
	 MX_NOTHING = 0,
	 MX_DESTRUCT,
	 MX_EXPOSE,
	 MX_GEOMETRY,
	 MX_DEFAULTRECT,
	 MX_ARM,
	 MX_SELECT,
	 MX_TOP,
	 MX_ACTIVE,
	 MX_VSCROLL,
	 MX_HSCROLL,
	 MX_LIST_CHANGED,
	 MX_THEME_CHANGE,

	 MX__INTERACT_BEGIN,
	 MX_POINTER_WANT,
	 MX_POINTER_ENTER,
	 MX_POINTER_LEAVE,
	 MX_POINTER_MOVE,
	 MX_POINTER_PRESS,
	 MX_POINTER_RELEASE,
	 MX_POINTER_CLICK,
	 MX_FOCUS_WANT,
	 MX_FOCUS_LOST,
	 MX_FOCUS_GOT,
	 MX_KEY,
	 MX_KEY_UNUSED,
	 MX__INTERACT_END,

	 MX_GFXMODE_OK,
	 MX_FILESEL_OK,

	 MX_LAST
} MX_EVENT;

/* Event information known to all objects */
typedef struct MX_EVENTSTACK {
	 struct MX_DERIVED *obj;
	 MX_EVENT event;
	 const void *data;
	 void *_answer;
} MX_EVENTSTACK;

extern MX_EVENTSTACK mx;

/* Event handling functions */
void mx_handler_default(void);
void mx__event_default(void);

void *mx_obj_event(struct MX_OBJ *obj, MX_EVENT type, const void *data);

#define mx_event(o,t,d) mx_obj_event(MXOBJ(o),(t),(d))

void mx_answer(void *answer);

void *mx_emit(MX_EVENT type, const void *data);
void *mx_inform(MX_EVENT type, const void *data);

/* Expose functions */
const MX_RECT *mx_expose_rect(void);
unsigned mx_exposing(void);
void mx_obj_dirty(struct MX_OBJ *obj, const unsigned children);

#define mx_dirty(o,c) mx_obj_dirty(MXOBJ(o),(c));
void mx_expose_background(const MX_RECT * rect);

/* Theme functions */
typedef struct MX_THEME {
	 unsigned (*start) (void);
	 void (*stop) (void);
	 void (*event) (void);
	 void (*obj) (struct MX_OBJ * obj);
	 void (*vslider) (struct MX_SLIDER * slider);
	 void (*hslider) (struct MX_SLIDER * slider);
	 void (*textual) (struct MX_TEXTUAL * text);
	 void (*scrollcorner) (struct MX_OBJ * scrollcorner);
	 void (*scrolltitle) (struct MX_TEXTUAL * scrolltitle);
	 void (*scroll) (struct MX_SCROLL * scroll);
	 void (*button) (struct MX_BUTTON * button);
	 void (*listelem) (struct MX_LISTELEM * listelem);
	 void (*root) (struct MX_WIN * root);
	 void (*winborder) (struct MX_WINBORDER * border);
	 void (*win) (struct MX_WIN * win);
	 void (*textsize) (const char *text, int l, int *w, int *h);
} MX_THEME;

extern MX_THEME mx_theme_default;
extern MX_THEME mx_theme_win95;
extern MX_THEME mx_theme_mono;
extern MX_THEME mx_theme_rounded;

void mx_theme_set(MX_THEME * theme);

extern const MX_THEME *mx__theme;

/* Platform functions */
typedef struct MX_PLATFORM_DRIVER {
	 void *driver;
	 const char *text;
} MX_PLATFORM_DRIVER;

typedef struct MX_PLATFORM_RESOLUTION {
	 int w, h;
	 const char *text;
} MX_PLATFORM_RESOLUTION;

typedef struct MX_PLATFORM_DEPTH {
	 int c;
	 const char *text;
} MX_PLATFORM_DEPTH;

typedef struct MX_PLATFORM_THEME {
	 struct MX_THEME *theme;
	 const char *text;
} MX_PLATFORM_THEME;

unsigned mx_platform_clip(const MX_RECT * r);
void mx_platform_modes(MX_PLATFORM_DRIVER * d[], MX_PLATFORM_RESOLUTION * r[], MX_PLATFORM_DEPTH * c[], MX_PLATFORM_THEME * t[]);
unsigned mx_platform_start(int w, int h, int c, void *driver);
void mx_platform_stop(void);
const MX_RECT *mx_platform_rect(void);
unsigned mx_platform_poll(void);
void mx_platform_dirty(const MX_RECT * rect);
unsigned mx_platform_pointer(int *px, int *py, int *pb);
unsigned mx_platform_key(int *scan, long *ascii);

/* Pointer handling */
typedef struct MX_POINTER_INFO {
	 int x, y, b;
	 int dx, dy;
} MX_POINTER_INFO;

const MX_POINTER_INFO *mx_pointer_info(void);
unsigned mx_pointer_hold(void);
unsigned mx_pointer_release(void);

/* Key handling */
typedef struct MX_KEY_INFO {
	 int code;
	 long ascii;
} MX_KEY_INFO;

const MX_KEY_INFO *mx_key_info(void);

/* Object functions */
typedef void (*MX_CLASS) (void);

typedef struct MX_OBJ {
	 union {
		  MX_RECTATOM rectatom;
		  MX_ATOM atom;
	 } base;
	 MX_CLASS _class;
	  MX_NODE(struct MX_OBJ);
	 struct MX_WIN *_win;
	 int _id;
#ifndef NDEBUG
	 unsigned long _magic;
#endif
	 unsigned _destroying:1;
	 unsigned _armed:1;
	 unsigned _armable:1;
	 unsigned _selected:1;
	 unsigned _selectable:1;
	 unsigned _disabled:1;
	 unsigned _wantmove:1;
} MX_OBJ;

#define MXOBJ(o)   (&(o)->base.obj)
#define MXCLASS(o) ((const MX_CLASS)(MXOBJ(o)->_class))
#define MXID(o)    ((const int)(MXOBJ(o)->_id))

typedef struct MX_DERIVED {
	 union {
		  MX_OBJ obj;
		  MX_RECTATOM rectatom;
		  MX_ATOM atom;
	 } base;
	 /* Must have no data! */
} MX_DERIVED;

int mx_obj_x(MX_OBJ * obj);
int mx_obj_y(MX_OBJ * obj);

#define mx_x(o) mx_obj_x(MXOBJ(o))
#define mx_y(o) mx_obj_y(MXOBJ(o))

MX_RECT *mx_place_rect(void);
void mx_obj_place(MX_OBJ * obj, const MX_RECT * rect);

#define mx_place(o,r) mx_obj_place(MXOBJ(o),(r))

void mx_obj_position(MX_OBJ * obj, int x, int y, int w, int h);

#define mx_position(o,x,y,w,h) mx_obj_position(MXOBJ(o),(x),(y),(w),(h))

void mx_obj_move(MX_OBJ * obj, int x, int y);

#define mx_move(o,x,y) mx_obj_move(MXOBJ(o),(x),(y))

void mx_obj_resize(MX_OBJ * obj, int w, int h);

#define mx_resize(o,w,h) mx_obj_resize(MXOBJ(o),(w),(h))

void mx_obj_geometry(MX_OBJ * obj);

#define mx_geometry(o) mx_obj_geometry(MXOBJ(o))

MX_RECT *mx_defaultrect_data(void);
void mx_obj_defaultrect(MX_OBJ * obj, MX_RECT * rect);

#define mx_defaultrect(o,r) mx_obj_defaultrect(MXOBJ(o),(r))

typedef enum MX_LAYOUT {
	 MX_LAYOUT_RIGHT = (1 << 0),
	 MX_LAYOUT_LEFT = (1 << 1),
	 MX_LAYOUT_TOP = (1 << 2),
	 MX_LAYOUT_BOTTOM = (1 << 3),
	 MX_LAYOUT_X1 = (1 << 4),
	 MX_LAYOUT_Y1 = (1 << 5),
	 MX_LAYOUT_X2 = (1 << 6),
	 MX_LAYOUT_Y2 = (1 << 7),
	 MX_LAYOUT_W = (1 << 8),
	 MX_LAYOUT_H = (1 << 9),
	 MX_LAYOUT_HCENTER = (1 << 10),
	 MX_LAYOUT_VCENTER = (1 << 11),
	 MX_LAYOUT_CENTER = MX_LAYOUT_HCENTER | MX_LAYOUT_VCENTER
} MX_LAYOUT;

void mx_obj_layout(MX_OBJ * obj, MX_LAYOUT flags, const MX_OBJ * other, int x, int y);

#define mx_layout(o,f,r,x,y) mx_obj_layout(MXOBJ(o),(f),MXOBJ(r),(x),(y))

void mx_obj_wantmove(MX_OBJ * obj, unsigned wantmove);

#define mx_wantmove(o,w) mx_obj_wantmove(MXOBJ(o),(w))

unsigned mx_obj_armed(const MX_OBJ * obj);

#define mx_armed(o) mx_obj_armed(MXOBJ(o))

void *mx_obj_arm(MX_OBJ * obj, unsigned arm);

#define mx_arm(o,a) mx_obj_arm(MXOBJ(o),(a))

void mx_obj_armable(MX_OBJ * obj, unsigned armable);

#define mx_armable(o,s) mx_obj_armable(MXOBJ(o),(s))

unsigned mx_obj_is_armable(const MX_OBJ * obj);

#define mx_is_armable(o) mx_obj_is_armable(MXOBJ(o))

unsigned mx_obj_selected(const MX_OBJ * obj);

#define mx_selected(o) mx_obj_selected(MXOBJ(o))

void *mx_obj_select(MX_OBJ * obj, unsigned select);

#define mx_select(o,s) mx_obj_select(MXOBJ(o),(s))

void mx_obj_selectable(MX_OBJ * obj, unsigned selectable);

#define mx_selectable(o,s) mx_obj_selectable(MXOBJ(o),(s))

unsigned mx_obj_is_selectable(const MX_OBJ * obj);

#define mx_is_selectable(o) mx_obj_selectable(MXOBJ(o))

void mx_obj_disable(MX_OBJ * obj, unsigned disable);

#define mx_disable(o,d) mx_obj_disable(MXOBJ(o),(d))

unsigned mx_obj_disabled(const MX_OBJ * obj);

#define mx_disabled(o) mx_obj_disabled(MXOBJ(o))

void *mx_obj_top(MX_OBJ * obj);

#define mx_top(o) mx_obj_top(MXOBJ(o))

void mx_obj_focus(MX_OBJ * obj);

#define mx_focus(o) mx_obj_focus(MXOBJ(o))

void mx_obj_unfocus(MX_OBJ * obj);

#define mx_unfocus(o) mx_obj_unfocus(MXOBJ(o))

/* Base object class */
void mx_obj_class(void);
void *mx_obj(MX_OBJ * obj, MX_CLASS _class, size_t size, MX_OBJ * parent, int id);

/* Textual object */
typedef enum MX_ALIGN {
	 MX_ALIGN_NONE = 0,
	 MX_ALIGN_RIGHT = (1 << 0),
	 MX_ALIGN_LEFT = (1 << 1),
	 MX_ALIGN_TOP = (1 << 2),
	 MX_ALIGN_BOTTOM = (1 << 3),
	 MX_ALIGN_HCENTER = (1 << 4),
	 MX_ALIGN_VCENTER = (1 << 5),
	 MX_ALIGN_CENTER = MX_ALIGN_HCENTER | MX_ALIGN_VCENTER
} MX_ALIGN;

typedef struct MX_TEXTUAL {
	 union {
		  MX_OBJ obj;
		  MX_RECTATOM rectatom;
		  MX_ATOM atom;
	 } base;
	 MX_STRING _text;
	 MX_ALIGN _align;
	 int _textwidth;
	 int _textheight;
} MX_TEXTUAL;

#define MXTEXTUAL(o)         (&(o)->base.textual)

void mx_textual_set(MX_TEXTUAL * text, const char *str, long len, MX_FREE free);

#define mx_text_set(o,t,l,f) mx_textual_set(MXTEXTUAL(o),(t),(l),(f))

const char *mx_textual_text(const MX_TEXTUAL * text, long *len);

#define mx_text(o,l) mx_textual_text(MXTEXTUAL(o),(l))

int mx_textual_width(const MX_TEXTUAL * text);

#define mx_text_width(o) mx_textual_width(MXTEXTUAL(o))

int mx_textual_height(const MX_TEXTUAL * text);

#define mx_text_height(o) mx_textual_height(MXTEXTUAL(o))

void mx_textual_align(MX_TEXTUAL * text, MX_ALIGN align);

#define mx_text_align(o,a) mx_textual_align(MXTEXTUAL(o),(a))

MX_ALIGN mx_textual_align_get(const MX_TEXTUAL * text);

#define mx_text_align_get(o) mx_textual_align_get(MXTEXTUAL(o))

void mx_textual_class(void);
MX_TEXTUAL *mx_obj_textual(MX_TEXTUAL * text, size_t size, MX_OBJ * parent, int id);

#define mx_textual(m,s,p,i) mx_obj_textual((m),(s),MXOBJ(p),(i))

void mx__textual_align(const MX_TEXTUAL * textual, int *x1, int *y1, int x2, int y2);

/* Button object */
typedef struct MX_BUTTON {
	 union {
		  MX_TEXTUAL textual;
		  MX_OBJ obj;
		  MX_RECTATOM rectatom;
		  MX_ATOM atom;
	 } base;
} MX_BUTTON;

#define MXBUTTON(o)   (&(o)->base.button)

void mx_button_class(void);
MX_BUTTON *mx_obj_button(MX_BUTTON * button, size_t size, MX_OBJ * parent, int id);

#define mx_button(m,s,p,i) mx_obj_button((m),(s),MXOBJ(p),(i))

/* For composite objects we can set an ID as a helper */
typedef enum MX__ID {
	 MXID_WINBORDER = 0xf000,
	 MXID_WINCLOSE,
	 MXID_WINRESIZE,
} MX__ID;

/* Window object */
typedef void (*MX_HANDLER) (struct MX_WIN * win);

typedef struct MX_WIN {
	 union {
		  MX_TEXTUAL textual;
		  MX_OBJ obj;
		  MX_RECTATOM rectatom;
		  MX_ATOM atom;
	 } base;
	 MX_HANDLER _handler;

	 struct MX_WINBORDER *border;

	  MX_NODE(struct MX_WIN);

	 int _modallock;
	 unsigned _ismodal:1;
} MX_WIN;

#define MXWIN(o)   (&(o)->base.win)

void mx_win_class(void);
void mx_win_handler(MX_WIN * win);
MX_WIN *mx_win(MX_WIN * win, size_t size, MX_HANDLER handler, int id);

unsigned mx_win_active(const MX_WIN * win);

#define mx_active(w) mx_win_active(MXWIN(w))

unsigned mx_win_activate(MX_WIN * win);

#define mx_activate(w) mx_win_activate(MXWIN(w))

void mx_win_dirty(MX_WIN * win);

/* Window border object */
typedef struct MX_WINBORDER {
	 union {
		  MX_OBJ obj;
		  MX_RECTATOM rectatom;
		  MX_ATOM atom;
	 } base;
	 MX_HANDLER _callback;
	 MX_BUTTON _close;
	 MX_BUTTON _resize;
} MX_WINBORDER;

void mx_winborder_class(void);
void mx_winborder_callback(MX_WIN * win);
MX_WINBORDER *mx_winborder(MX_WINBORDER * border, size_t size, MX_WIN * owner, int id);

void mx_win_child(MX_WIN * win, MX_WIN * target);

#define mx_child(w,t) mx_win_child(MXWIN(w), MXWIN(t))

void mx_win_modal(MX_WIN * win, MX_WIN * target);

#define mx_modal(w,t) mx_win_modal(MXWIN(w), MXWIN(t))

/*--------------------------------------------------------------------------*/
/* Optional objects */

/* Generic slider object */
typedef struct MX_SLIDER {
	 union {
		  MX_OBJ obj;
		  MX_RECTATOM rectatom;
		  MX_ATOM atom;
	 } base;
	 int _min;
	 int _upper;
	 int _lower;
	 int _dim;
	 int _range;
	 int _size;
	 int _value;
} MX_SLIDER;

#define MXSLIDER(o)         (&(o)->base.slider)

void mx_slider_set(MX_SLIDER * slider, int range, int size, int value);
void mx_slider_to(MX_SLIDER * slider, int value);
int mx_slider_value(MX_SLIDER * slider);

/* Vertical slider object */
void mx_vslider_class(void);
MX_SLIDER *mx_obj_vslider(MX_SLIDER * slider, size_t size, MX_OBJ * parent, int id);

#define mx_vslider(s,si,p,i) mx_obj_vslider((s),(si),MXOBJ(p),(i))

/* Horizontal slider object */
void mx_hslider_class(void);
MX_SLIDER *mx_obj_hslider(MX_SLIDER * slider, size_t size, MX_OBJ * parent, int id);

#define mx_hslider(s,si,p,i) mx_obj_hslider((s),(si),MXOBJ(p),(i))

/* Scrollable area object */
typedef struct MX_SCROLL {
	 union {
		  MX_TEXTUAL textual;
		  MX_OBJ obj;
		  MX_RECTATOM rectatom;
		  MX_ATOM atom;
	 } base;
	 int _x, _y;
	 int _w, _h;
	 int _vw, _vh;
	 MX_TEXTUAL _text;
	 MX_SLIDER *_hscroll;
	 MX_SLIDER *_vscroll;
	 MX_OBJ *_corner;
} MX_SCROLL;

#define MXSCROLL(o)         (&(o)->base.scroll)

void mx_scrollcorner_class(void);
void mx_scrolltitle_class(void);

void mx_scroll_class(void);
MX_SCROLL *mx_obj_scroll(MX_SCROLL * scroll, size_t size, MX_OBJ * parent, int id);

#define mx_scroll(s,si,p,i) mx_obj_scroll((s),(si),MXOBJ(p),(i))

unsigned mx_scroll_scrollable_element(const MX_SCROLL * scroll, const MX_OBJ * ptr);

/* List element objects for scrollable lists */
typedef struct MX_LISTELEM {
	 union {
		  MX_BUTTON button;
		  MX_TEXTUAL textual;
		  MX_OBJ obj;
		  MX_RECTATOM rectatom;
		  MX_ATOM atom;
	 } base;
	 struct MX_LIST *_list;
	 struct MX_LISTELEM *_prev;
	 struct MX_LISTELEM *_next;
} MX_LISTELEM;

void mx_listelem_class(void);
MX_LISTELEM *mx_listelem(MX_LISTELEM * listelem, size_t size, struct MX_LIST *parent, int id);

/* Scrollable list object */
typedef struct MX_LIST {
	 union {
		  MX_SCROLL scroll;
		  MX_TEXTUAL textual;
		  MX_OBJ obj;
		  MX_RECTATOM rectatom;
		  MX_ATOM atom;
	 } base;
	 MX_LISTELEM *_first;
	 unsigned _multiple:1;
	 unsigned _changeing:1;
} MX_LIST;

#define MXLIST(o)   (&(o)->base.list)

void mx_list_class(void);
MX_LIST *mx_obj_list(MX_LIST * list, size_t size, MX_OBJ * parent, int id);

#define mx_list(m,s,p,i) mx_obj_list((m),(s),MXOBJ(p),(i))

void mx_list_append(MX_LIST * list, const char *text, long len, MX_FREE free, int id);
void mx_list_multiple(MX_LIST * list, const unsigned multi);

void mx_list_link(MX_LIST * list, MX_LISTELEM * listelem);
void mx_list_unlink(MX_LISTELEM * listelem);

void mx_list_select_id(MX_LIST * list, int id, unsigned doit);

int mx_list_selected_id(MX_LIST * list, MX_LISTELEM * ptr);
MX_LISTELEM *mx_list_selected(MX_LIST * list, MX_LISTELEM * ptr);
MX_LISTELEM *mx_list_iter(MX_LIST * list, MX_LISTELEM * ptr);

void mx_list_empty(MX_LIST * list);

/* GFXmode selector window */
typedef struct MX_GFXMODE {
	 union {
		  MX_WIN win;
		  MX_TEXTUAL textual;
		  MX_OBJ obj;
		  MX_RECTATOM rectatom;
		  MX_ATOM atom;
	 } base;

	 MX_BUTTON _ok;
	 MX_BUTTON _apply;
	 MX_LIST _res;
	 MX_LIST _depth;
	 MX_LIST _driver;
	 MX_LIST _theme;

	 int _resw, _depthw, _driverw, _themeh;
} MX_GFXMODE;

void mx_gfxmode_handler(MX_WIN * win);
MX_GFXMODE *mx_gfxmodewin(MX_GFXMODE * gfx, size_t size, MX_HANDLER handler, int id);

#define mx_gfxmode(g,s,h,i,t) mx_gfxmodewin((g),(s),(h),(i),MXWIN(t))

typedef struct MX_GFXMODE_INFO {
	 int w, h, c;
	 void *driver;
	 MX_THEME *theme;
} MX_GFXMODE_INFO;

MX_GFXMODE_INFO *mx_gfxmode_info(void);

/* FIXME!!! Borland free compiler does something wierd.  PATH_MAX is
   included in limits.h so I include it, but for some reason PATH_MAX
   doesnt get defined.  So I'll just make a reasonable guess.
*/
#if !defined(PATH_MAX) && defined(__WIN32__) && (__BORLANDC__ >= 0x550)
#define PATH_MAX 512
#endif

/* File selector window */
typedef struct MX_FILESEL {
	 union {
		  MX_WIN win;
		  MX_TEXTUAL textual;
		  MX_OBJ obj;
		  MX_RECTATOM rectatom;
		  MX_ATOM atom;
	 } base;

	 MX_LIST _dirs;
	 MX_LIST _files;
	 MX_BUTTON _ok;
	 MX_TEXTUAL _file;

	 char _current[PATH_MAX + FILENAME_MAX + 1];
	 int _currentlen;
} MX_FILESEL;

void mx_filesel_handler(MX_WIN * win);
MX_FILESEL *mx_fileselwin(MX_FILESEL * sel, size_t size, MX_HANDLER handler, int id);

/* Ok its funny that the macro arguments turned out like that, but its
   purely accidental */
#define mx_filesel(g,s,h,i,t) mx_fileselwin((g),(s),(h),(i),MXWIN(t))

void mx_filesel_refresh(MX_FILESEL * sel);
void mx_filesel_path(MX_FILESEL * sel, const char * path, int len);

const char *mx_filesel_info(void);

/*--------------------------------------------------------------------------*/
/* Some helper macros */
#ifndef NDEBUG
#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#define MXMAGIC 0xdeadbeef
#define MXINVARIANT(o) do {           \
    MXASSERT(o);                      \
    MXASSERT((o)->_magic == MXMAGIC); \
    MXASSERT((o)->_class);            \
    MXASSERT((o)->_win);              \
} while(0)
#else
#define MXINVARIANT(o)
#endif

#define MXMINSIZE(s,a)                   \
    if ((s == MXDEF) || (s < sizeof(a))) \
        s = sizeof(a);

/*--------------------------------------------------------------------------*/
#ifdef __cplusplus
}
#endif
#endif

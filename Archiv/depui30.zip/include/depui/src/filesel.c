/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#if defined(MX_LIB) || defined(MX_DEPUI_FILESEL)
#ifndef MX_HAVE_DEPUI_FILESEL
#define MX_HAVE_DEPUI_FILESEL

#include "depui/depui.h"
#include <string.h>
#include <sys/stat.h>

#define MX_DEPUI_LIST
#include "depui/src/list.c"

#define MX_DETK_MATCH
#define MX_DETK_BASENAME
#define MX_DETK_PATHFIX
#include "detk/detk.c"

/* LCC doesnt have dirent.h (opendir etc) so we have to emulate them */
#if defined(__LCC__) || (defined(__WATCOMC__) && defined(_WIN32))
#define MX_DEPUI_DIRENT
#include "depui/src/dirent.c"
#else
#include <dirent.h>
#endif

static void mx__filesel_geometry(MX_FILESEL * sel)
{
	 int lh;
	 const int lw = (mx_w(sel) - 7) / 2;

	 mx_defaultrect(&sel->_ok, 0);
	 mx_layout(&sel->_ok, (MX_LAYOUT) (MX_LAYOUT_X2 | MX_LAYOUT_Y2), sel, -2, -2);

	 mx_defaultrect(&sel->_file, 0);
	 mx_resize(&sel->_file, mx_w(sel) - 4, MXDEF);

	 mx_layout(&sel->_file, (MX_LAYOUT) (MX_LAYOUT_X2 | MX_LAYOUT_TOP), &sel->_ok, 0, 2);

	 lh = mx_y(&sel->_file) - 5;

	 mx_position(&sel->_dirs, 2, 2, lw, lh);
	 mx_geometry(&sel->_dirs);

	 mx_position(&sel->_files, lw + 5, 2, lw + 1, lh);
	 mx_geometry(&sel->_files);
}

void mx_filesel_refresh(MX_FILESEL * sel)
{
	 DIR *dir;
	 struct dirent *entry;
	 char *end;
	 char pattern[FILENAME_MAX + 1];

#ifdef __DJGPP__
	 const unsigned short old_djstat_flags = _djstat_flags;

	 _djstat_flags |= _STAT_INODE | _STAT_EXEC_EXT | _STAT_EXEC_MAGIC | _STAT_DIRSIZE | _STAT_ROOT_TIME | _STAT_WRITEBIT;
#endif

	 mx_list_empty(&sel->_files);
	 mx_list_empty(&sel->_dirs);

	 end = (char *) mx_basename(sel->_current);
	 strcpy(pattern, end);

	 *end = '\0';
	 dir = opendir(sel->_current);

	 while ((dir) && ((entry = readdir(dir)) != 0)) {
		  char *text;
		  struct stat sbuf;
		  int len;
		  MX_LIST *thelist = 0;

		  if ((entry->d_name[0] == '.') && (entry->d_name[1] == '\0'))
				continue;

		  len = strlen(entry->d_name);

		  text = (char *) mx_malloc(len + 1);
		  strncpy(text, entry->d_name, len);
		  text[len] = 0;

		  strcpy(end, text);

		  if (!stat(sel->_current, &sbuf)) {
				thelist = &sel->_files;

				if (S_ISDIR(sbuf.st_mode))
					 thelist = &sel->_dirs;

				else if (!mx_filename_match(pattern, end))
					 thelist = 0;
		  }

		  if (thelist)
				mx_list_append(thelist, text, len, mx_free, 0);
		  else
				mx_free(text);
	 }
	 strcpy(end, pattern);

	 closedir(dir);

#ifdef __DJGPP__
	 _djstat_flags = old_djstat_flags;
#endif
}

static void mx__filesel_dir(MX_FILESEL * sel, const char *text, int len)
{
	 char pattern[FILENAME_MAX + 1];
	 char *end = (char *) mx_basename(sel->_current);

	 if (!text)
		  return;

	 strcpy(pattern, end);

	 if (len < 0)
		  strcpy(end, text);
	 else {
		  strncpy(end, text, len);
		  end[len] = '\0';
	 }

	 strcat(sel->_current, "/");
	 mx_path_fix(sel->_current);
	 strcat(sel->_current, pattern);

	 mx_filesel_refresh(sel);
	 mx__filesel_geometry(sel);

	 mx_disable(&sel->_ok, true);

	 mx_dirty(&sel->_ok, true);
	 mx_dirty(&sel->_file, true);
	 mx_dirty(&sel->_dirs, true);
	 mx_dirty(&sel->_files, true);
}

void mx_filesel_handler(MX_WIN * win)
{
	 MX_FILESEL *sel = (MX_FILESEL *) win;

	 MXINVARIANT(MXOBJ(win));
	 MXINVARIANT(MXOBJ(mx.obj));

	 /* Handle selmode events */
	 if (MXOBJ(mx.obj) == MXOBJ(win)) {
		  switch (mx.event) {

		  case MX_GEOMETRY:
				mx_win_handler(win);
				mx__filesel_geometry(sel);
				return;

		  case MX_DEFAULTRECT:{
					 MX_RECT *rect = mx_defaultrect_data();

					 rect->x2 = rect->x1 + 320;
					 rect->y2 = rect->y1 + 200;
					 return;
				}

		  default:
				break;
		  }

		  /* Handle list selection events */
	 } else if (mx.event == MX_LIST_CHANGED) {

		  /* Has dir been clicked */
		  if (MXOBJ(mx.obj) == MXOBJ(&sel->_dirs)) {
				const MX_LISTELEM *elem;

				mx_win_handler(win);

				elem = mx_list_selected(&sel->_dirs, 0);
				if (elem) {
					 long len = 0;
					 const char *text = mx_text(elem, &len);

					 mx__filesel_dir(sel, text, len);
				}
				return;

				/* Has a file been clicked, then enable/disable OK button */
		  } else if (MXOBJ(mx.obj) == MXOBJ(&sel->_files)) {

				if (mx_list_selected(&sel->_files, 0))
					 mx_disable(&sel->_ok, false);
				else
					 mx_disable(&sel->_ok, true);

				mx_dirty(&sel->_ok, true);
		  }

		  /* Handle selection events */
	 } else if ((mx.event == MX_SELECT) && (mx.data)) {

		  /* Button ok selected */
		  if (MXOBJ(mx.obj) == MXOBJ(&sel->_ok)) {
        
            /* Put the selected filename in the current place*/
            MX_LISTELEM * selected = mx_list_selected(&sel->_files, 0);
            if (selected) {
                long len = 0;
                const char * text = mx_text(selected, &len);

                if ((text) && (len)) {
                    char * end = (char *) mx_basename(sel->_current);

                    if (len < 0) {
                        strcpy(end, text);
                        
                    } else {
                        strncpy(end, text, len);
                        end[len] = 0;
                    }
                }
            }
            
            mx_inform(MX_FILESEL_OK, sel->_current);
				mx_delete(sel);
				return;
		  }
	 }
	 mx_win_handler(win);
}

MX_FILESEL *mx_fileselwin(MX_FILESEL * sel, size_t size, MX_HANDLER handler, int theid)
{
	 MXMINSIZE(size, MX_FILESEL);

	 if (!handler)
		  handler = mx_filesel_handler;

	 sel = (MX_FILESEL *) mx_win(MXWIN(sel), size, handler, theid);
	 if (sel) {
		  mx_button(&sel->_ok, 0, sel, 0);
		  mx_text_set(&sel->_ok, "ok", -1, 0);
		  mx_text_align(&sel->_ok, MX_ALIGN_CENTER);
		  mx_disable(&sel->_ok, true);
		  MXNAMESET(&sel->_ok, "filesel_ok");

		  mx_list(&sel->_dirs, 0, sel, 0);
		  mx_text_set(&sel->_dirs, "dir", -1, 0);
		  MXNAMESET(&sel->_dirs, "filesel_dir");

		  mx_list(&sel->_files, 0, sel, 0);
		  mx_text_set(&sel->_files, "file", -1, 0);
		  MXNAMESET(&sel->_files, "filesel_files");

		  mx_textual(&sel->_file, 0, sel, 0);
		  MXNAMESET(&sel->_file, "filesel_file");

		  strcpy(sel->_current, "./*.*");
		  mx_textual_set(&sel->_file, sel->_current, -1, 0);
/*		  mx_filesel_refresh(sel); */
	 }
	 return sel;
}

void mx_filesel_path(MX_FILESEL * sel, const char * path, int len)
{
    MXINVARIANT(MXOBJ(sel));
    MXASSERT(path);

    if (len < 0)
       len = PATH_MAX - 1;

    strncpy(sel->_current, path, len);
    sel->_current[PATH_MAX - 1] = 0;
}

const char * mx_filesel_info(void)
{
    if (mx.event != MX_FILESEL_OK)
        return 0;

    return (const char*) mx.data;
}

#endif
#endif

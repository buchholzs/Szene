/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#if defined(MX_LIB) || defined(MX_DEPUI_SCROLL)
#ifndef MX_HAVE_DEPUI_SCROLL
#define MX_HAVE_DEPUI_SCROLL

#include "depui/depui.h"

#define MX_DEPUI_SLIDER
#include "depui/src/slider.c"

static void mx__scroll_hscroll(MX_SCROLL * scroll)
{
	 if (!scroll->_hscroll) {
		  scroll->_hscroll = mx_hslider(0, 0, scroll, 0);
		  mx_defaultrect(scroll->_hscroll, 0);
	 }
}

static void mx__scroll_vscroll(MX_SCROLL * scroll)
{
	 if (!scroll->_vscroll) {
		  scroll->_vscroll = mx_vslider(0, 0, scroll, 0);
		  mx_defaultrect(scroll->_vscroll, 0);
	 }
}

void mx_scrollcorner_class(void)
{
	 MXINVARIANT(MXOBJ(mx.obj));

	 switch (mx.event) {

	 case MX_EXPOSE:
		  mx__theme->scrollcorner(MXOBJ(mx.obj));
		  return;

	 default:
		  break;
	 }
	 mx_obj_class();
}

void mx_scrolltitle_class(void)
{
	 MX_TEXTUAL *text = (MX_TEXTUAL *) mx.obj;

	 MXINVARIANT(MXOBJ(mx.obj));

	 switch (mx.event) {

	 case MX_EXPOSE:
		  mx__theme->scrolltitle(text);
		  return;

	 default:
		  break;
	 }
	 mx_textual_class();
}

unsigned mx_scroll_scrollable_element(const MX_SCROLL * scroll, const MX_OBJ * ptr)
{
	 if ((ptr != MXOBJ(scroll->_vscroll)) && (ptr != MXOBJ(scroll->_hscroll)) && (ptr != MXOBJ(&scroll->_text))
		  && (ptr != scroll->_corner))
		  return true;
	 return false;
}

static void mx__scroll_geometry(MX_SCROLL * scroll, int x1, int y1, int x2, int y2)
{
	 long len;
	 const char *text = mx_text(scroll, &len);
	 int yoff = mx_text_height(scroll);

	 int vsize = 0;
	 int hsize = 0;
	 unsigned need_v = false;
	 unsigned need_h = false;

	 MXINVARIANT(MXOBJ(scroll));

	 if (!text)
		  yoff = 0;

	 y1 -= yoff;

	 scroll->_x = x1;
	 scroll->_y = y1;
	 scroll->_w = x2 - x1;
	 scroll->_h = y2 - y1 - yoff - 1;
	 scroll->_vw = mx_w(scroll);
	 scroll->_vh = mx_h(scroll) - yoff - 1;

	 if (scroll->_h > scroll->_vh) {
		  mx__scroll_vscroll(scroll);
		  scroll->_vw -= mx_w(scroll->_vscroll) + 1;
		  need_v = true;
	 }
	 if (scroll->_w > scroll->_vw) {
		  mx__scroll_hscroll(scroll);
		  scroll->_vh -= mx_h(scroll->_hscroll) + 1;
		  need_h = true;
	 }
	 if ((scroll->_h > scroll->_vh) && (!need_v)) {
		  mx__scroll_vscroll(scroll);
		  scroll->_vw -= mx_w(scroll->_vscroll) + 1;
		  need_v = true;
	 }
	 if ((scroll->_w > scroll->_vw) && (!need_h)) {
		  mx__scroll_hscroll(scroll);
		  scroll->_vh -= mx_h(scroll->_hscroll) + 1;
		  need_h = true;
	 }

	 if ((!need_h) && (scroll->_hscroll)) {
		  mx_delete(scroll->_hscroll);
		  scroll->_hscroll = 0;
	 }
	 if ((!need_v) && (scroll->_vscroll)) {
		  mx_delete(scroll->_vscroll);
		  scroll->_vscroll = 0;
	 }

	 mx_node_remove(MXOBJ(&scroll->_text));
	 mx_node_insert(MXOBJ(&scroll->_text), MXOBJ(scroll));

	 mx_textual_set(&scroll->_text, text, len, 0);
	 mx_textual_align(&scroll->_text, mx_text_align_get(scroll));

	 if (text)
		  mx_resize(&scroll->_text, mx_w(scroll), yoff - 1);
	 else
		  mx_position(&scroll->_text, -1, -1, -1, -1);

	 if (scroll->_vscroll) {
		  MXASSERT(need_v);

		  vsize = mx_w(scroll->_vscroll);
		  mx_position(scroll->_vscroll, mx_w(scroll) - vsize, yoff, vsize, scroll->_vh + 1);
		  mx_geometry(scroll->_vscroll);

		  mx_slider_set(scroll->_vscroll, scroll->_h, scroll->_vh, -y1 - yoff);

		  mx_node_remove(MXOBJ(scroll->_vscroll));
		  mx_node_insert(MXOBJ(scroll->_vscroll), MXOBJ(scroll));
	 }
	 if (scroll->_hscroll) {
		  MXASSERT(need_h);

		  hsize = mx_h(scroll->_hscroll);
		  mx_position(scroll->_hscroll, 0, mx_h(scroll) - hsize, scroll->_vw, hsize);
		  mx_geometry(scroll->_hscroll);

		  mx_slider_set(scroll->_hscroll, scroll->_w, scroll->_vw, -x1);

		  mx_node_remove(MXOBJ(scroll->_hscroll));
		  mx_node_insert(MXOBJ(scroll->_hscroll), MXOBJ(scroll));
	 }

	 if ((scroll->_vscroll) && (scroll->_hscroll)) {
		  if (!scroll->_corner) {
				scroll->_corner = (MX_OBJ *) mx_obj(0, mx_scrollcorner_class, 0, MXOBJ(scroll), 0);
				MXNAMESET(scroll->_corner, "scrollcorner");
		  }

		  mx_obj_position(scroll->_corner, mx_w(scroll) - vsize, mx_h(scroll) - hsize, vsize, hsize);

		  mx_node_remove(scroll->_corner);
		  mx_node_insert(scroll->_corner, MXOBJ(scroll));

	 } else if (scroll->_corner) {
		  mx_delete(scroll->_corner);
		  scroll->_corner = 0;
	 }
}

static void mx__scroll_geometry_refresh(MX_SCROLL * scroll)
{
	 unsigned int haselem = false;
	 int x1 = 0, y1 = 0, x2 = 0, y2 = 0;
	 MX_OBJ *ptr = MXOBJ(scroll)->_last;

	 MXINVARIANT(MXOBJ(scroll));

	 while (ptr) {
		  MXINVARIANT(ptr);
		  if (mx_scroll_scrollable_element(scroll, ptr)) {
				const MX_RECT *pos = MXRECT(ptr);

				if ((!haselem) || (pos->x1 < x1))
					 x1 = pos->x1;
				if ((!haselem) || (pos->y1 < y1))
					 y1 = pos->y1;
				if ((!haselem) || (pos->x2 > x2))
					 x2 = pos->x2;
				if ((!haselem) || (pos->y2 > y2))
					 y2 = pos->y2;

				haselem = true;
		  }
		  ptr = ptr->_prev;
	 }
	 x1 -= mx_x1(scroll);
	 y1 -= mx_y1(scroll);
	 x2 -= mx_x1(scroll);
	 y2 -= mx_y1(scroll);

	 mx__scroll_geometry(scroll, x1, y1, x2, y2);
}

static void mx__scroll_do(MX_SCROLL * scroll, int dx, int dy)
{
	 MX_OBJ *ptr = MXOBJ(scroll)->_last;

	 MXINVARIANT(MXOBJ(scroll));

	 while (ptr) {
		  MXINVARIANT(ptr);
		  if (mx_scroll_scrollable_element(scroll, ptr)) {
				MX_RECT pos;
                pos = *MXRECT(ptr);

				pos.x1 -= dx;
				pos.y1 -= dy;
				pos.x2 -= dx;
				pos.y2 -= dy;
				mx_rectatom_place(MX__RECTATOM(ptr), &pos);
		  }
		  ptr = ptr->_prev;
	 }

	 scroll->_x -= dx;
	 scroll->_y -= dy;
}

void mx_scroll_class(void)
{
	 MX_SCROLL *scroll = (MX_SCROLL *) mx.obj;

	 MXINVARIANT(MXOBJ(mx.obj));

	 switch (mx.event) {

	 case MX_EXPOSE:
		  mx__theme->scroll(scroll);
		  return;

	 case MX_GEOMETRY:
		  mx__scroll_geometry_refresh(scroll);
		  return;

	 case MX_HSCROLL:
		  if (scroll->_hscroll) {
				const int dx = mx_slider_value(scroll->_hscroll) + scroll->_x;

				mx__scroll_do(scroll, dx, 0);
				mx_dirty(scroll, true);
		  }
		  break;

	 case MX_VSCROLL:
		  if (scroll->_vscroll) {
				const int dy = mx_slider_value(scroll->_vscroll) + scroll->_y;

				mx__scroll_do(scroll, 0, dy);
				mx_dirty(scroll, true);
		  }
		  break;

	 default:
		  break;
	 }
	 mx_textual_class();
}

MX_SCROLL *mx_obj_scroll(MX_SCROLL * scroll, size_t size, MX_OBJ * parent, int theid)
{
	 MXMINSIZE(size, MX_SCROLL);

	 scroll = (MX_SCROLL *) mx_obj_textual(MXTEXTUAL(scroll), size, parent, theid);
	 if (scroll) {
		  MXOBJ(scroll)->_class = mx_scroll_class;
		  MXNAMESET(scroll, "scroll");

		  mx_textual(&scroll->_text, 0, scroll, 0);
		  MXOBJ(&scroll->_text)->_class = mx_scrolltitle_class;
		  MXNAMESET(&scroll->_text, "scroll_text");
	 }
	 MXINVARIANT(MXOBJ(scroll));
	 return scroll;
}

#endif
#endif

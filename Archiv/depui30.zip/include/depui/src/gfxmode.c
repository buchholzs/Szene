/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#if defined(MX_LIB) || defined(MX_DEPUI_GFXMODE)
#ifndef MX_HAVE_DEPUI_GFXMODE
#define MX_HAVE_DEPUI_GFXMODE

#include "depui/depui.h"

#define MX_DEPUI_LIST
#include "depui/src/list.c"

static void mx__gfxmode_sizes(MX_GFXMODE * gfx)
{
	 MX_LISTELEM *ptr;
	 MX_PLATFORM_RESOLUTION *r = 0;
	 MX_PLATFORM_DEPTH *c = 0;
	 MX_PLATFORM_DRIVER *d = 0;
	 MX_PLATFORM_THEME *t = 0;

	 MXINVARIANT(MXOBJ(gfx));

	 gfx->_driverw = -1;
	 gfx->_resw = -1;
	 gfx->_depthw = -1;
	 gfx->_themeh = 0;

	 mx_platform_modes(&d, &r, &c, &t);
	 if (d) {
		  int maxw = 0;

		  ptr = 0;
		  while ((ptr = mx_list_iter(&gfx->_driver, ptr)) != 0) {
				int w;
				MX_RECT rect;

				mx_defaultrect(ptr, &rect);
				w = rect.x2 - rect.x1;

				maxw = MXMAX(maxw, w);
		  }

		  maxw = MXMAX(maxw, mx_text_width(&gfx->_driver));
		  gfx->_driverw = maxw;
	 }

	 if (r) {
		  int maxw = 0;

		  ptr = 0;
		  while ((ptr = mx_list_iter(&gfx->_res, ptr)) != 0) {
				int w;
				MX_RECT rect;

				mx_defaultrect(ptr, &rect);
				w = rect.x2 - rect.x1;

				maxw = MXMAX(maxw, w);
		  }

		  maxw = MXMAX(maxw, mx_text_width(&gfx->_res));
		  gfx->_resw = maxw;
	 }

	 if (c) {
		  int maxw = 0;

		  ptr = 0;
		  while ((ptr = mx_list_iter(&gfx->_depth, ptr)) != 0) {
				int w;
				MX_RECT rect;

				mx_defaultrect(ptr, &rect);
				w = rect.x2 - rect.x1;

				maxw = MXMAX(maxw, w);
		  }

		  maxw = MXMAX(maxw, mx_text_width(&gfx->_depth));
		  gfx->_depthw = maxw;
	 }

	 if (t) {
		  int h = 0, num = 0;

		  ptr = 0;
		  while ((ptr = mx_list_iter(&gfx->_theme, ptr)) != 0) {
				int objh;
				MX_RECT rect;

				mx_defaultrect(ptr, &rect);
				objh = rect.y2 - rect.y1;

				if (num < 4)
					 h += objh + 1;

				++num;
		  }
		  gfx->_themeh = h - 1 + mx_text_height(&gfx->_theme);
	 }
}

static void mx__gfxmode_geometry(MX_GFXMODE * gfx)
{
	 int x;
	 int w = mx_w(gfx) - 4;
	 int h = mx_h(gfx) - 4;
	 int th = gfx->_themeh;
	 const int listw = gfx->_resw + gfx->_depthw + gfx->_driverw;

	 if (h < (3 * th))
		  th = h / 3;

	 mx_defaultrect(&gfx->_ok, 0);
	 mx_defaultrect(&gfx->_apply, 0);
	 h -= mx_h(&gfx->_ok) + 4 + th + 8;

	 w -= 8;

	 mx_position(&gfx->_driver, 2, 2, (gfx->_driverw * w) / listw, h);
	 mx_geometry(&gfx->_driver);

	 x = mx_x(&gfx->_driver) + mx_w(&gfx->_driver) + 4;
	 mx_position(&gfx->_res, x, 2, (gfx->_resw * w) / listw, h);
	 mx_geometry(&gfx->_res);

	 x = mx_x(&gfx->_res) + mx_w(&gfx->_res) + 4;
	 mx_position(&gfx->_depth, x, 2, (gfx->_depthw * w) / listw, h);
	 mx_geometry(&gfx->_depth);

	 mx_position(&gfx->_theme, 2, mx_h(&gfx->_driver) + 8, w + 8, th);
	 mx_geometry(&gfx->_theme);

	 mx_layout(&gfx->_ok, (MX_LAYOUT) (MX_LAYOUT_X2 | MX_LAYOUT_Y2), gfx, -2, -2);

	 mx_layout(&gfx->_apply, (MX_LAYOUT) (MX_LAYOUT_LEFT | MX_LAYOUT_Y1), &gfx->_ok, 4, 0);
}

static void mx__gfxmode_apply(MX_GFXMODE * gfx)
{
	 MX_GFXMODE_INFO info;

	 MX_PLATFORM_RESOLUTION *r = 0;
	 MX_PLATFORM_DEPTH *c = 0;
	 MX_PLATFORM_DRIVER *d = 0;
	 MX_PLATFORM_THEME *t = 0;
	 const int rsel = mx_list_selected_id(&gfx->_res, 0);
	 const int csel = mx_list_selected_id(&gfx->_depth, 0);
	 const int dsel = mx_list_selected_id(&gfx->_driver, 0);
	 const int tsel = mx_list_selected_id(&gfx->_theme, 0);

	 memset(&info, 0, sizeof(info));

	 mx_platform_modes(&d, &r, &c, &t);

	 if ((r) && (rsel >= 0)) {
		  info.w = r[rsel].w;
		  info.h = r[rsel].h;
	 }

	 if ((c) && (csel >= 0))
		  info.c = c[csel].c;

	 if ((c) && (dsel >= 0))
		  info.driver = d[dsel].driver;

	 if ((t) && (tsel >= 0))
		  info.theme = t[tsel].theme;

	 if (mx_inform(MX_GFXMODE_OK, &info) == 0) {

		  if ((csel >= 0) || (dsel >= 0) || (rsel >= 0)) {
				mx_platform_start(info.w, info.h, info.c, info.driver);
				mx_platform_dirty(mx_platform_rect());
		  }

		  if (info.theme) {
				mx_theme_set(info.theme);
				mx_platform_dirty(mx_platform_rect());
		  }
	 }
}

void mx_gfxmode_handler(MX_WIN * win)
{
	 MX_GFXMODE *gfx = (MX_GFXMODE *) win;

	 MXINVARIANT(MXOBJ(win));
	 MXINVARIANT(MXOBJ(mx.obj));

	 /* Handle gfxmode events */
	 if (MXOBJ(mx.obj) == MXOBJ(win)) {
		  switch (mx.event) {

		  case MX_GEOMETRY:
				mx_win_handler(win);
				mx__gfxmode_geometry(gfx);
				return;

		  case MX_THEME_CHANGE:
				mx__gfxmode_sizes(gfx);
				break;

		  case MX_DEFAULTRECT:{
					 MX_RECT *rect = mx_defaultrect_data();

					 rect->x2 = rect->x1 + 320;
					 rect->y2 = rect->y1 + 200;
					 return;
				}

		  default:
				break;
		  }

		  /* Handle button select events */
	 } else if (mx.event == MX_SELECT) {

		  /* Ok button */
		  if (MXOBJ(mx.obj) == MXOBJ(&gfx->_ok)) {
				mx__gfxmode_apply(gfx);
				mx_delete(gfx);
				return;

				/* Apply button */
		  } else if (MXOBJ(mx.obj) == MXOBJ(&gfx->_apply)) {
				mx__gfxmode_apply(gfx);
				return;
		  }
	 }
	 mx_win_handler(win);
}

MX_GFXMODE *mx_gfxmodewin(MX_GFXMODE * gfx, size_t size, MX_HANDLER handler, int theid)
{
	 MXMINSIZE(size, MX_GFXMODE);

	 if (!handler)
		  handler = mx_gfxmode_handler;

	 gfx = (MX_GFXMODE *) mx_win(MXWIN(gfx), size, handler, theid);
	 if (gfx) {
		  MX_PLATFORM_RESOLUTION *r = 0;
		  MX_PLATFORM_DEPTH *c = 0;
		  MX_PLATFORM_DRIVER *d = 0;
		  MX_PLATFORM_THEME *t = 0;

		  mx_text_set(gfx, "GFXmode", -1, 0);
		  MXNAMESET(gfx, "gfxmode");

		  mx_button(&gfx->_ok, 0, gfx, 0);
		  mx_text_set(&gfx->_ok, "ok", -1, 0);
		  mx_text_align(&gfx->_ok, MX_ALIGN_CENTER);
		  MXNAMESET(&gfx->_ok, "gfxmode_ok");

		  mx_button(&gfx->_apply, 0, gfx, 0);
		  mx_text_set(&gfx->_apply, "apply", -1, 0);
		  mx_text_align(&gfx->_apply, MX_ALIGN_CENTER);
		  MXNAMESET(&gfx->_apply, "gfxmode_ok");

		  mx_list(&gfx->_res, 0, gfx, 0);
		  mx_text_set(&gfx->_res, "Resolution", -1, 0);
		  MXNAMESET(&gfx->_res, "gfxmode_res");

		  mx_list(&gfx->_depth, 0, gfx, 0);
		  mx_text_set(&gfx->_depth, "Depth", -1, 0);
		  MXNAMESET(&gfx->_depth, "gfxmode_depth");

		  mx_list(&gfx->_driver, 0, gfx, 0);
		  mx_text_set(&gfx->_driver, "Driver", -1, 0);
		  MXNAMESET(&gfx->_driver, "gfxmode_driver");

		  mx_list(&gfx->_theme, 0, gfx, 0);
		  mx_text_set(&gfx->_theme, "Theme", -1, 0);
		  MXNAMESET(&gfx->_theme, "gfxmode_theme");

		  /* Fill each of the lists with the gfx mode info */
		  mx_platform_modes(&d, &r, &c, &t);
		  if (d) {
				int num = 0;
				MX_PLATFORM_DRIVER *ptr = d;

				while (ptr->text) {
					 MX_LISTELEM *elem = mx_listelem(0, 0, &gfx->_driver, num);

					 mx_text_set(elem, ptr->text, -1, 0);
					 mx_defaultrect(elem, 0);
					 ++ptr;
					 ++num;
				}
		  }
		  if (r) {
				int num = 0;
				MX_PLATFORM_RESOLUTION *ptr = r;

				while (ptr->text) {
					 MX_LISTELEM *elem = mx_listelem(0, 0, &gfx->_res, num);

					 mx_text_set(elem, ptr->text, -1, 0);
					 mx_defaultrect(elem, 0);
					 ++ptr;
					 ++num;
				}
		  }
		  if (c) {
				int num = 0;
				MX_PLATFORM_DEPTH *ptr = c;

				while (ptr->text) {
					 MX_LISTELEM *elem = mx_listelem(0, 0, &gfx->_depth, num);

					 mx_text_set(elem, ptr->text, -1, 0);
					 mx_defaultrect(elem, 0);
					 ++ptr;
					 ++num;
				}
		  }
		  if (t) {
				int num = 0;
				MX_PLATFORM_THEME *ptr = t;

				while (ptr->text) {
					 MX_LISTELEM *elem = mx_listelem(0, 0, &gfx->_theme, num);

					 mx_text_set(elem, ptr->text, -1, 0);
					 mx_defaultrect(elem, 0);
					 ++ptr;
					 ++num;
				}
		  }

		  mx__gfxmode_sizes(gfx);
	 }

	 MXINVARIANT(MXOBJ(gfx));
	 return gfx;
}

#endif
#endif

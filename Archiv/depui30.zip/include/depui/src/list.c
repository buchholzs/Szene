/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#if defined(MX_LIB) || defined(MX_DEPUI_LIST)
#ifndef MX_HAVE_DEPUI_LIST
#define MX_HAVE_DEPUI_LIST

#include "depui/depui.h"

#define MX_DEPUI_SCROLL
#include "depui/src/scroll.c"

void mx_list_unlink(MX_LISTELEM * listelem)
{
	 MXINVARIANT(MXOBJ(listelem));

    if (!listelem->_list)
        return;
    
	 MXINVARIANT(MXOBJ(listelem->_list));

	 if (listelem->_prev)
		  listelem->_prev->_next = listelem->_next;
	 if (listelem->_next)
		  listelem->_next->_prev = listelem->_prev;

	 if (listelem == listelem->_list->_first)
		  listelem->_list->_first = listelem->_prev;

	 listelem->_list = 0;
	 listelem->_next = 0;
	 listelem->_prev = 0;
}

void mx_listelem_class(void)
{
	 MX_LISTELEM *listelem = (MX_LISTELEM *) mx.obj;

	 MXINVARIANT(MXOBJ(mx.obj));

	 switch (mx.event) {

	 case MX_DESTRUCT:
   	  mx_list_unlink(listelem);
		  break;

	 case MX_EXPOSE:
		  mx__theme->listelem(listelem);
		  return;

	 case MX_SELECT:
		  if ((listelem->_list) && (!listelem->_list->_changeing)) {
				if (!listelem->_list->_multiple) {
					 MX_LISTELEM *ptr = listelem->_list->_first;
                     
				    listelem->_list->_changeing = true;

					 while (ptr) {
                    MXASSERT(ptr->_list == listelem->_list);
                
                    if (ptr != listelem)
                        mx_select(ptr, false);
                       
						  ptr = ptr->_prev;
					 }
                listelem->_list->_changeing = false;
				}

				mx_button_class();
            
				mx_event(listelem->_list, MX_LIST_CHANGED, 0);
				return;
		  }
		  break;

	 case MX_DEFAULTRECT:
		  mx_textual_class();
		  return;

	 default:
		  break;
	 }

	 mx_button_class();
}

MX_LISTELEM *mx_listelem(MX_LISTELEM * listelem, size_t size, MX_LIST * parent, int theid)
{
	 MXMINSIZE(size, MX_LISTELEM);

	 listelem = (MX_LISTELEM *) mx_obj_button(MXBUTTON(listelem), size, MXOBJ(parent), theid);
	 if (listelem) {
		  MXOBJ(listelem)->_class = mx_listelem_class;
		  MXNAMESET(listelem, "listelem");

		  mx_armable(listelem, true);

		  if (parent)
				mx_list_link(parent, listelem);
	 }
	 MXINVARIANT(MXOBJ(listelem));
	 return listelem;
}

void mx_list_class(void)
{
	 MX_LIST *list = (MX_LIST *) mx.obj;

	 MXINVARIANT(MXOBJ(mx.obj));

	 switch (mx.event) {

	 case MX_DESTRUCT:
		  while (list->_first)
				mx_list_unlink(list->_first);
		  break;

	 case MX_GEOMETRY:{
				MX_LISTELEM *ptr = list->_first;
				int y = (mx_text(list, 0)) ? (mx_text_height(list)) : (0);
            const int sy = y;
            int w = 0;

				while ((ptr) && (ptr->_prev))
                ptr = ptr->_prev;

				while (ptr) {
					 mx_defaultrect(ptr, 0);
					 mx_position(ptr, 0, y, MXDEF, MXDEF);

					 y = mx_y(ptr) + mx_h(ptr) + 1;
                w = MXMAX(w, mx_w(ptr));
                
                ptr = ptr->_next;
				}

            mx__scroll_geometry(MXSCROLL(list), 0, sy, w, y - 1);

            ptr = list->_first;
				while (ptr) {
  				    mx_resize(ptr, MXSCROLL(list)->_vw, MXDEF);
                ptr = ptr->_prev;
            }
				return;
		  }

	 default:
		  break;
	 }
	 mx_scroll_class();
}

MX_LIST *mx_obj_list(MX_LIST * list, size_t size, MX_OBJ * parent, int theid)
{
	 MXMINSIZE(size, MX_LIST);

	 list = (MX_LIST *) mx_obj_scroll(MXSCROLL(list), size, parent, theid);
	 if (list) {
		  MXOBJ(list)->_class = mx_list_class;
		  MXNAMESET(list, "list");

		  list->_first = 0;
	 }
	 MXINVARIANT(MXOBJ(list));
	 return list;
}

void mx_list_multiple(MX_LIST * list, const unsigned multi)
{
	 MXINVARIANT(MXOBJ(list));

	 list->_multiple = multi;
}

void mx_list_link(MX_LIST * list, MX_LISTELEM * listelem)
{
	 MXINVARIANT(MXOBJ(list));
	 MXINVARIANT(MXOBJ(listelem));

	 MXASSERT(listelem->_list == 0);
	 MXASSERT(listelem->_prev == 0);
	 MXASSERT(listelem->_next == 0);

	 listelem->_prev = list->_first;
	 listelem->_list = list;

	 if (list->_first)
		  list->_first->_next = listelem;
	 list->_first = listelem;
}

void mx_list_append(MX_LIST * list, const char *text, long len, MX_FREE free, int theid)
{
	 MX_LISTELEM *listelem = mx_listelem(0, 0, list, theid);

	 MXINVARIANT(MXOBJ(list));

	 mx_text_set(listelem, text, len, free);
}

void mx_list_select_id(MX_LIST * list, int theid, unsigned doit)
{
	 MX_LISTELEM *ptr = list->_first;
    
	 while (ptr) {
        if (MXID(ptr) == theid) {
            if ((mx_selected(ptr) && (!doit)) ||
                (!mx_selected(ptr) && (doit)))
                mx_select(ptr, doit);
        }
		  ptr = ptr->_prev;
	 }
}

void mx_list_empty(MX_LIST * list)
{
	 MXINVARIANT(MXOBJ(list));

	 while (list->_first) {
        MX_LISTELEM * listelem = list->_first;
        
		  mx_list_unlink(listelem);
        mx_node_remove(MXOBJ(listelem));
		  mx_delete(listelem);
    }
}

MX_LISTELEM *mx_list_iter(MX_LIST * list, MX_LISTELEM * ptr)
{
	 MXINVARIANT(MXOBJ(list));

	 return (ptr) ? (ptr->_prev) : (list->_first);
}

MX_LISTELEM *mx_list_selected(MX_LIST * list, MX_LISTELEM *ptr)
{
    if (!ptr)
        ptr = list->_first;

	 MXINVARIANT(MXOBJ(list));

	 while ((ptr) && (!mx_selected(ptr)))
		  ptr = ptr->_prev;

	 return ptr;
}

int mx_list_selected_id(MX_LIST * list, MX_LISTELEM *ptr)
{
	 ptr = mx_list_selected(list, ptr);
    if (ptr)
        return MXID(ptr);
        
    return -1;
}

#endif
#endif

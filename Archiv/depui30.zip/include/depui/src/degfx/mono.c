/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#ifdef MX_PLATFORM_DEGFX
#if defined(MX_LIB) || defined(MX_THEME_MONO)
#ifndef MX_HAVE_THEME_MONO
#define MX_HAVE_THEME_MONO
#define MX_THEME_EXISTS

#include "degfx/degfx.h"
#include "depui/depui.h"

#define MX_DEGFX_BITLINE
#define MX_DEGFX_FONTDRAW

static MX_PIXEL mx_theme_mono_wintile_tgadata[] = {
	 MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255,
																																									255, 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255,
																																									255,
																																									255, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0,
																																											0, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0,
																																											0,
																																											0,
																																											0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255,
																																									255, 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255,
																																									255,
																																									255, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0,
																																											0, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0,
																																											0,
																																											0,
																																											0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255,
																																									255, 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255,
																																									255,
																																									255, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0,
																																											0, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0,
																																											0,
																																											0,
																																											0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255,
																																									255, 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255,
																																									255,
																																									255, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0,
																																											0, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0,
																																											0,
																																											0,
																																											0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255,
																																									255, 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255,
																																									255,
																																									255, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0,
																																											0, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0,
																																											0,
																																											0,
																																											0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255,
																																									255, 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255,
																																									255,
																																									255, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0,
																																											0, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0,
																																											0,
																																											0,
																																											0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255,
																																									255, 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255,
																																									255,
																																									255, 0),
	 0
};

static MX_BITMAP mx_theme_mono_wintile = MXBITMAP_DECLARE(mx_theme_mono_wintile_tgadata, 12, 13);

static unsigned mx_theme_mono_start(void)
{
	 return true;
}

static void mx_theme_mono_stop(void)
{
}

static void mx_theme_mono_event(void)
{
	 mx__event_default();
}

static void mx_theme_mono_obj(MX_OBJ * obj)
{
	 if (mx_exposing()) {
		  const MX_RECT *objrect = MXRECT(obj);

		  mx_rectfill(objrect->x1, objrect->y1, objrect->x2, objrect->y2, MXCOLOR_white);
	 }
}

static void mx_theme_mono_vslider(MX_SLIDER * slider)
{
	 if (mx_exposing()) {
		  const MX_RECT *objrect = MXRECT(slider);
		  MX_PIXEL fill = MXCOLOR_white;
		  MX_PIXEL edge1 = MXCOLOR_grey25;
		  MX_PIXEL edge2 = MXRGB(164, 164, 164);

		  mx_rectfill(objrect->x1, objrect->y1, objrect->x2, objrect->y2, MXCOLOR_black);

		  if (mx_armed(slider)) {
				fill = MXCOLOR_grey50;
				edge1 = MXRGB(225, 225, 225);
				edge2 = MXCOLOR_grey25;
		  }
		  mx_frame(objrect->x1 + 1, objrect->y1 + slider->_upper, objrect->x2 - 1, objrect->y1 + slider->_lower, 1, edge2, edge1, fill);
	 }
}

static void mx_theme_mono_hslider(MX_SLIDER * slider)
{
	 if (mx_exposing()) {
		  const MX_RECT *objrect = MXRECT(slider);
		  MX_PIXEL fill = MXCOLOR_white;
		  MX_PIXEL edge1 = MXCOLOR_grey25;
		  MX_PIXEL edge2 = MXRGB(164, 164, 164);

		  mx_rectfill(objrect->x1, objrect->y1, objrect->x2, objrect->y2, MXCOLOR_black);

		  if (mx_armed(slider)) {
				fill = MXCOLOR_grey50;
				edge1 = MXRGB(225, 225, 225);
				edge2 = MXCOLOR_grey25;
		  }

		  mx_frame(objrect->x1 + slider->_upper, objrect->y1 + 1, objrect->x1 + slider->_lower, objrect->y2 - 1, 1, edge2, edge1, fill);
	 }
}

static void mx_theme_mono_textual_draw(const MX_TEXTUAL * textual, int x1, int y1, int x2, int y2, int offsetx, int offsety)
{
	 long len = 0;
	 const char *text = mx_string_text(&textual->_text, &len);
	 MX_PIXEL fore = MXCOLOR_black;
	 MX_PIXEL back = MXCOLOR_white;

	 if (mx_selected(textual))
		  back = MXCOLOR_wheat4;

	 if (mx_disabled(textual))
		  fore = MXCOLOR_grey50;

	 if ((mx_is_armable(textual)) && (mx_armed(textual)))
		  back = MXCOLOR_grey50;

	 mx_rectfill(x1, y1, x2, y2, back);

	 if (text) {
		  mx__textual_align(textual, &x1, &y1, x2, y2);
		  mx_font_drawblock(0, text, len, x1 + offsetx, y1 + offsety, fore, fore);
	 }
}

static void mx_theme_mono_textual(MX_TEXTUAL * text)
{
	 if (mx_exposing()) {
		  const MX_RECT *objrect = MXRECT(text);

		  mx_theme_mono_textual_draw(text, objrect->x1, objrect->y1, objrect->x2, objrect->y2, 0, 0);
	 }
}

static void mx_theme_mono_scrollcorner(MX_OBJ * scrollcorner)
{
	 if (mx_exposing()) {
		  const MX_RECT *objrect = MXRECT(scrollcorner);

		  mx_rectfill(objrect->x1, objrect->y1, objrect->x2, objrect->y2, MXCOLOR_wheat);
	 }
}

static void mx_theme_mono_scrolltitle(MX_TEXTUAL * scrolltitle)
{
	 if (mx_exposing()) {
		  long len = 0;
		  const char *text = mx_textual_text(scrolltitle, &len);
		  const MX_RECT *objrect = MXRECT(scrolltitle);
		  int x1 = objrect->x1;
		  int y1 = objrect->y1;
		  int x2 = objrect->x2;
		  int y2 = objrect->y2;

		  mx_rectfill(x1, y1, x2, y2, MXCOLOR_wheat);

		  if (text) {
				mx__textual_align(scrolltitle, &x1, &y1, x2, y2);
				mx_font_drawblock(0, text, len, x1, y1, MXCOLOR_black, MXCOLOR_black);
		  }
	 }
}

static void mx_theme_mono_scroll(MX_SCROLL * scroll)
{
	 if (mx_exposing()) {
		  const MX_RECT *objrect = MXRECT(scroll);

		  mx_rectfill(objrect->x1, objrect->y1, objrect->x2, objrect->y2, MXCOLOR_white);
	 }
}

static void mx_theme_mono_button(MX_BUTTON * button)
{
	 if (mx_exposing()) {
		  const MX_RECT *objrect = MXRECT(button);
		  int offset = 0;

		  if (mx_selected(button))
				offset = 1;

		  if (mx_armed(button))
				mx_box(objrect->x1, objrect->y1, objrect->x2, objrect->y2, 1, MXCOLOR_grey25, MXCOLOR_grey25);
		  else if (mx_selected(button))
				mx_box(objrect->x1, objrect->y1, objrect->x2, objrect->y2, 1, MXCOLOR_grey25, MXCOLOR_grey75);
		  else
				mx_box(objrect->x1, objrect->y1, objrect->x2, objrect->y2, 1, MXCOLOR_grey75, MXCOLOR_grey25);

		  mx_theme_mono_textual_draw(MXTEXTUAL(button), objrect->x1 + 1, objrect->y1 + 1, objrect->x2 - 1, objrect->y2 - 1, 1 + offset,
											  1 + offset);
	 }
}

void mx_theme_mono_listelem(MX_LISTELEM * listelem)
{
	 if (mx_exposing()) {
		  const MX_RECT *objrect = MXRECT(listelem);

		  mx_theme_mono_textual_draw(MXTEXTUAL(listelem), objrect->x1, objrect->y1, objrect->x2, objrect->y2, 0, 0);
	 }
}

static void mx_theme_mono_root(MX_WIN * root)
{
	 if (mx_exposing()) {
		  const MX_RECT *objrect = MXRECT(root);

		  mx_rectfill(objrect->x1, objrect->y1, objrect->x2, objrect->y2, MXCOLOR_lightskyblue);
	 }
}

static void mx_theme_mono_winborder(MX_WINBORDER * border)
{
	 if (mx_exposing()) {
		  MX_WIN *owner = MXOBJ(border)->_win;
		  const MX_RECT *objrect = MXRECT(border);
		  int x1 = objrect->x1;
		  int y1 = objrect->y1;
		  const int x2 = objrect->x2;
		  const int y2 = objrect->y2;
		  MX_PIXEL fill = MXCOLOR_wheat3;

		  if (mx_win_active(owner))
				fill = MXCOLOR_lemon;

		  mx_box(x1, y1, x2, y2, 1, MXCOLOR_grey25, MXCOLOR_grey25);

		  mx_rectfill(x1 + 1, y1 + 1, x2 - 1, mx_y1(owner) - 2, fill);
		  mx_hline(x1 + 1, mx_y1(owner) - 1, x2 - 1, MXCOLOR_wheat);

		  mx_hline(x1 + 1, mx_y2(owner) + 1, x2 - 1, MXCOLOR_wheat);
		  mx_rectfill(x1 + 1, mx_y2(owner) + 2, x2 - 1, y2 - 1, fill);

		  if (owner) {
				long len = 0;
				const char *text = mx_text(owner, &len);

				if (text) {
					 mx__textual_align(MXTEXTUAL(owner), &x1, &y1, x2, y2);
					 mx_font_drawblock(0, text, len, x1 + 2, y1 + 2, MXCOLOR_black, MXCOLOR_black);
				}
		  }
	 }
}

static void mx_theme_mono_win(MX_WIN * win)
{
	 if (mx_exposing()) {
		  int x, y;
		  const MX_RECT *objrect = MXRECT(win);

		  for (y = objrect->y1; y < objrect->y2; y += mx_h(&mx_theme_mono_wintile))
				for (x = objrect->x1; x < objrect->x2; x += mx_w(&mx_theme_mono_wintile))
					 mx_blit(&mx_theme_mono_wintile, 0, 0, x, y, mx_w(&mx_theme_mono_wintile), mx_h(&mx_theme_mono_wintile));
	 }
}

MX_THEME mx_theme_mono = {
	 mx_theme_mono_start,
	 mx_theme_mono_stop,
	 mx_theme_mono_event,
	 mx_theme_mono_obj,
	 mx_theme_mono_vslider,
	 mx_theme_mono_hslider,
	 mx_theme_mono_textual,
	 mx_theme_mono_scrollcorner,
	 mx_theme_mono_scrolltitle,
	 mx_theme_mono_scroll,
	 mx_theme_mono_button,
	 mx_theme_mono_listelem,
	 mx_theme_mono_root,
	 mx_theme_mono_winborder,
	 mx_theme_mono_win,
	 mx__degfx_textsize
};

#endif
#endif
#endif

/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#ifdef MX_PLATFORM_DEGFX
#if defined(MX_LIB) || defined(MX_THEME_WIN95)
#ifndef MX_HAVE_THEME_WIN95
#define MX_HAVE_THEME_WIN95
#define MX_THEME_EXISTS

#include "degfx/degfx.h"
#include "depui/depui.h"

#define MX_DEGFX_BITLINE
#define MX_DEGFX_BITDRAW
#define MX_DEGFX_FONTDRAW
#define MX_DEGFX_LOADTGA
#define MX_DEGFX_DECORATE

#define MX_DEPUI_SLIDER

static void mx__degfx_textsize(const char *text, int l, int *w, int *h);

static MX_PIXEL mx_theme_win95_wincolor;
static MX_PIXEL mx_theme_win95_backcolor;
static MX_PIXEL mx_theme_win95_forecolor;
static MX_PIXEL mx_theme_win95_selectbackcolor;
static MX_PIXEL mx_theme_win95_selectforecolor;
static MX_PIXEL mx_theme_win95_armcolor;
static MX_PIXEL mx_theme_win95_disabledcolor;
static MX_FONT* mx_theme_win95_font;

static MX_PIXEL mx_theme_win95_buttonup_tgadata[] = {
	 MXRGBT(255, 255, 255, 0), MXRGBT(255, 255, 255, 0), MXRGBT(255, 255, 255, 0), MXRGBT(255, 255, 255, 0), MXRGBT(255, 255, 255, 0),
	 MXRGBT(0, 0, 0, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(224, 224, 224, 0), MXRGBT(224, 224, 224, 0), MXRGBT(224, 224, 224, 0), MXRGBT(127, 127, 127, 0),
	 MXRGBT(0, 0, 0, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(224, 224, 224, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(127, 127, 127, 0),
	 MXRGBT(0, 0, 0, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(224, 224, 224, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(127, 127, 127, 0),
	 MXRGBT(0, 0, 0, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(224, 224, 224, 0), MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0),
	 MXRGBT(0, 0, 0, 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0),
	 0
};

static MX_BITMAP mx_theme_win95_buttonup = MXBITMAP_DECLARE(mx_theme_win95_buttonup_tgadata, 6, 6);

static MX_PIXEL mx_theme_win95_buttondown_tgadata[] = {
	 MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0),
	 MXRGBT(0, 0, 0, 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(127, 127, 127, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(127, 127, 127, 0),
	 MXRGBT(0, 0, 0, 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(127, 127, 127, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(127, 127, 127, 0),
	 MXRGBT(0, 0, 0, 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0),
	 MXRGBT(0, 0, 0, 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0),
	 0
};

static MX_BITMAP mx_theme_win95_buttondown = MXBITMAP_DECLARE(mx_theme_win95_buttondown_tgadata, 6, 6);

static MX_PIXEL mx_theme_win95_buttonclose_tgadata[] = {
	 MXRGBT(255, 255, 255, 0), MXRGBT(255, 255, 255, 0), MXRGBT(255, 255, 255, 0), MXRGBT(255, 255, 255, 0), MXRGBT(255, 255, 255, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(255, 255, 255, 0), MXRGBT(255, 255, 255, 0), MXRGBT(255, 255, 255, 0), MXRGBT(255, 255, 255,
																																						 0), MXRGBT(255,
																																										255,
																																										255,
																																										0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(255, 255, 255, 0), MXRGBT(255, 255, 255, 0), MXRGBT(255, 255, 255, 0), MXRGBT(0, 0, 0, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(223, 223, 223, 0), MXRGBT(223, 223, 223, 0), MXRGBT(223, 223, 223, 0), MXRGBT(223, 223, 223, 0),
	 MXRGBT(223, 223, 223, 0), MXRGBT(223, 223, 223, 0), MXRGBT(223, 223, 223, 0), MXRGBT(223, 223, 223, 0), MXRGBT(223, 223, 223,
																																						 0), MXRGBT(223,
																																										223,
																																										223,
																																										0),
	 MXRGBT(223, 223, 223, 0), MXRGBT(223, 223, 223, 0), MXRGBT(223, 223, 223, 0), MXRGBT(127, 127, 127, 0), MXRGBT(0, 0, 0, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(223, 223, 223, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191,
																																						 0), MXRGBT(191,
																																										191,
																																										191,
																																										0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(127, 127, 127, 0), MXRGBT(0, 0, 0, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(223, 223, 223, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(0, 0, 0, 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(127, 127, 127, 0), MXRGBT(0,
																																											0,
																																											0,
																																											0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(223, 223, 223, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0,
																																									0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(127, 127, 127, 0), MXRGBT(0, 0, 0, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(223, 223, 223, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(191, 191, 191,
																																							0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(127, 127, 127, 0), MXRGBT(0, 0, 0, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(223, 223, 223, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(127, 127, 127,
																																						 0), MXRGBT(0, 0,
																																										0,
																																										0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(223, 223, 223, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(191, 191, 191,
																																							0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(127, 127, 127, 0), MXRGBT(0, 0, 0, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(223, 223, 223, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0,
																																									0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(127, 127, 127, 0), MXRGBT(0, 0, 0, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(223, 223, 223, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(0, 0, 0, 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(127, 127, 127, 0), MXRGBT(0,
																																											0,
																																											0,
																																											0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(223, 223, 223, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191,
																																						 0), MXRGBT(191,
																																										191,
																																										191,
																																										0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(127, 127, 127, 0), MXRGBT(0, 0, 0, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(223, 223, 223, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191,
																																						 0), MXRGBT(191,
																																										191,
																																										191,
																																										0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(127, 127, 127, 0), MXRGBT(0, 0, 0, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0),
	 MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127,
																																						 0), MXRGBT(127,
																																										127,
																																										127,
																																										0),
	 MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0), MXRGBT(0, 0, 0, 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0,
																																											  0,
																																											  0,
																																											  0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0),
	 0
};

static MX_BITMAP mx_theme_win95_buttonclose = MXBITMAP_DECLARE(mx_theme_win95_buttonclose_tgadata, 16, 14);

static MX_PIXEL mx_theme_win95_buttonclose2_tgadata[] = {
	 MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0,
																																											  0,
																																											  0,
																																											  0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(255, 255, 255, 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0),
	 MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127,
																																						 0), MXRGBT(127,
																																										127,
																																										127,
																																										0),
	 MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0), MXRGBT(223, 223, 223, 0), MXRGBT(255, 255, 255,
																																						 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(127, 127, 127, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191,
																																						 0), MXRGBT(191,
																																										191,
																																										191,
																																										0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(223, 223, 223, 0), MXRGBT(255, 255, 255,
																																						 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(127, 127, 127, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191,
																																						 0), MXRGBT(191,
																																										191,
																																										191,
																																										0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(223, 223, 223, 0), MXRGBT(255, 255, 255,
																																						 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(127, 127, 127, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(191, 191, 191, 0), MXRGBT(223, 223, 223, 0),
	 MXRGBT(255, 255, 255, 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(127, 127, 127, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(0,
																																											0,
																																											0,
																																											0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(223, 223, 223, 0), MXRGBT(255, 255, 255, 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(127, 127, 127, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0,
																																									0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(223, 223, 223, 0), MXRGBT(255, 255, 255,
																																						 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(127, 127, 127, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(223, 223, 223,
																																						 0), MXRGBT(255,
																																										255,
																																										255,
																																										0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(127, 127, 127, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0,
																																									0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(223, 223, 223, 0), MXRGBT(255, 255, 255,
																																						 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(127, 127, 127, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(0,
																																											0,
																																											0,
																																											0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(223, 223, 223, 0), MXRGBT(255, 255, 255, 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(127, 127, 127, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(0, 0, 0, 0), MXRGBT(0, 0, 0, 0), MXRGBT(191, 191, 191, 0), MXRGBT(223, 223, 223, 0),
	 MXRGBT(255, 255, 255, 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(127, 127, 127, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191,
																																						 0), MXRGBT(191,
																																										191,
																																										191,
																																										0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(223, 223, 223, 0), MXRGBT(255, 255, 255,
																																						 0),
	 MXRGBT(0, 0, 0, 0), MXRGBT(223, 223, 223, 0), MXRGBT(223, 223, 223, 0), MXRGBT(223, 223, 223, 0), MXRGBT(223, 223, 223, 0),
	 MXRGBT(223, 223, 223, 0), MXRGBT(223, 223, 223, 0), MXRGBT(223, 223, 223, 0), MXRGBT(223, 223, 223, 0), MXRGBT(223, 223, 223,
																																						 0), MXRGBT(223,
																																										223,
																																										223,
																																										0),
	 MXRGBT(223, 223, 223, 0), MXRGBT(223, 223, 223, 0), MXRGBT(223, 223, 223, 0), MXRGBT(223, 223, 223, 0), MXRGBT(255, 255, 255,
																																						 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(255, 255, 255, 0), MXRGBT(255, 255, 255, 0), MXRGBT(255, 255, 255, 0), MXRGBT(255, 255, 255, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(255, 255, 255, 0), MXRGBT(255, 255, 255, 0), MXRGBT(255, 255, 255, 0), MXRGBT(255, 255, 255,
																																						 0), MXRGBT(255,
																																										255,
																																										255,
																																										0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(255, 255, 255, 0), MXRGBT(255, 255, 255, 0), MXRGBT(255, 255, 255, 0), MXRGBT(255, 255, 255,
																																						 0),
	 0
};

static MX_BITMAP mx_theme_win95_buttonclose2 = MXBITMAP_DECLARE(mx_theme_win95_buttonclose2_tgadata, 16, 14);

static MX_PIXEL mx_theme_win95_buttonresize_tgadata[] = {
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191,
																																						 0), MXRGBT(191,
																																										191,
																																										191,
																																										0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191,
																																						 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191,
																																						 0), MXRGBT(191,
																																										191,
																																										191,
																																										0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191,
																																						 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191,
																																						 0), MXRGBT(191,
																																										191,
																																										191,
																																										0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(127, 127, 127, 0), MXRGBT(191, 191, 191,
																																						 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191,
																																						 0), MXRGBT(191,
																																										191,
																																										191,
																																										0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0), MXRGBT(191, 191, 191,
																																						 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191,
																																						 0), MXRGBT(191,
																																										191,
																																										191,
																																										0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191,
																																						 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191,
																																						 0), MXRGBT(255,
																																										255,
																																										255,
																																										0),
	 MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191,
																																						 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255,
																																						 0), MXRGBT(127,
																																										127,
																																										127,
																																										0),
	 MXRGBT(127, 127, 127, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(127, 127, 127, 0), MXRGBT(191, 191, 191,
																																						 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(127, 127, 127,
																																						 0), MXRGBT(127,
																																										127,
																																										127,
																																										0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0), MXRGBT(191, 191, 191,
																																						 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127,
																																						 0), MXRGBT(191,
																																										191,
																																										191,
																																										0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191,
																																						 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0), MXRGBT(191, 191, 191,
																																						 0), MXRGBT(255,
																																										255,
																																										255,
																																										0),
	 MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191,
																																						 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255,
																																						 0), MXRGBT(127,
																																										127,
																																										127,
																																										0),
	 MXRGBT(127, 127, 127, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(127, 127, 127, 0), MXRGBT(191, 191, 191,
																																						 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0),
	 MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(127, 127, 127,
																																						 0), MXRGBT(127,
																																										127,
																																										127,
																																										0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0), MXRGBT(191, 191, 191,
																																						 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(127, 127, 127, 0),
	 MXRGBT(127, 127, 127, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127,
																																						 0), MXRGBT(191,
																																										191,
																																										191,
																																										0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(127, 127, 127, 0), MXRGBT(127, 127, 127, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191,
																																						 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191,
																																						 0), MXRGBT(191,
																																										191,
																																										191,
																																										0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191, 0), MXRGBT(191, 191, 191,
																																						 0),
	 0
};

static MX_BITMAP mx_theme_win95_buttonresize = MXBITMAP_DECLARE(mx_theme_win95_buttonresize_tgadata, 16, 14);

static MX_PIXEL mx_theme_win95_scrollback_tgadata[] = {
	 MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191,
																																						 0), MXRGBT(255,
																																										255,
																																										255,
																																										0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191,
																																						 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255,
																																						 0), MXRGBT(191,
																																										191,
																																										191,
																																										0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255,
																																						 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191,
																																						 0), MXRGBT(255,
																																										255,
																																										255,
																																										0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191,
																																						 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255,
																																						 0), MXRGBT(191,
																																										191,
																																										191,
																																										0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255,
																																						 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191,
																																						 0), MXRGBT(255,
																																										255,
																																										255,
																																										0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191,
																																						 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255,
																																						 0), MXRGBT(191,
																																										191,
																																										191,
																																										0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255,
																																						 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191,
																																						 0), MXRGBT(255,
																																										255,
																																										255,
																																										0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191,
																																						 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255,
																																						 0), MXRGBT(191,
																																										191,
																																										191,
																																										0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255,
																																						 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191,
																																						 0), MXRGBT(255,
																																										255,
																																										255,
																																										0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191,
																																						 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255,
																																						 0), MXRGBT(191,
																																										191,
																																										191,
																																										0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255,
																																						 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191,
																																						 0), MXRGBT(255,
																																										255,
																																										255,
																																										0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191,
																																						 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255,
																																						 0), MXRGBT(191,
																																										191,
																																										191,
																																										0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255,
																																						 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191,
																																						 0), MXRGBT(255,
																																										255,
																																										255,
																																										0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191,
																																						 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255,
																																						 0), MXRGBT(191,
																																										191,
																																										191,
																																										0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255,
																																						 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191,
																																						 0), MXRGBT(255,
																																										255,
																																										255,
																																										0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191,
																																						 0),
	 MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255,
																																						 0), MXRGBT(191,
																																										191,
																																										191,
																																										0),
	 MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255, 0), MXRGBT(191, 191, 191, 0), MXRGBT(255, 255, 255,
																																						 0),
	 0
};

static MX_BITMAP mx_theme_win95_scrollback = MXBITMAP_DECLARE(mx_theme_win95_scrollback_tgadata, 16, 16);

static unsigned mx_theme_win95_start(void)
{
	 mx_theme_win95_wincolor = MXRGB(192, 192, 192);
	 mx_theme_win95_backcolor = MXRGB(255, 255, 255);
	 mx_theme_win95_forecolor = MXRGB(0, 0, 0);
	 mx_theme_win95_selectbackcolor = MXRGB(0, 0, 127);
	 mx_theme_win95_selectforecolor = MXRGB(255, 255, 255);
	 mx_theme_win95_armcolor = MXRGB(127, 127, 127);
	 mx_theme_win95_disabledcolor = MXRGB(127, 127, 127);

	 mx_theme_win95_font = mx_font_pcx("./theme/win95/font.pcx", 0x20);
	 return true;
}

static void mx_theme_win95_stop(void)
{
    mx_delete(mx_theme_win95_font);
}

static void mx_theme_win95_event(void)
{
	 MX_RECT *rect = mx_defaultrect_data();

	 if (rect) {

		  /* For a close or resize button make it so big as the bitmap */
		  if (MXID(mx.obj) == MXID_WINCLOSE) {
				rect->x2 = rect->x1 + mx_w(&mx_theme_win95_buttonclose);
				rect->y2 = rect->y1 + mx_h(&mx_theme_win95_buttonclose);
				return;

		  } else if (MXID(mx.obj) == MXID_WINRESIZE) {
				rect->x2 = rect->x1 + mx_w(&mx_theme_win95_buttonresize);
				rect->y2 = rect->y1 + mx_h(&mx_theme_win95_buttonresize);
				return;

				/* For a window border, make it a bit wider */
		  } else if (MXID(mx.obj) == MXID_WINBORDER) {
				mx__event_default();

				rect->x1 -= 2;
				rect->x2 += 2;
				return;

				/* Sliders have to have a minimum width/ height */
		  } else if (MXCLASS(mx.obj) == mx_vslider_class) {
				MX_SLIDER *slider = (MX_SLIDER *) mx.obj;

				slider->_min = 5;
				rect->x2 = rect->x1 + 12;
				return;

		  } else if (MXCLASS(mx.obj) == mx_hslider_class) {
				MX_SLIDER *slider = (MX_SLIDER *) mx.obj;

				slider->_min = 5;
				rect->y2 = rect->y1 + 12;
				return;

		  }
        
		  if (MXCLASS(mx.obj) == mx_winborder_class) {
				mx__event_default();

				rect->y2 += 2;
				return;
		  }

		  /* Position close buttons differently */
	 } else if (MXCLASS(mx.obj) == mx_winborder_class) {
		  if (mx.event == MX_GEOMETRY) {
				MX_WINBORDER *border = (MX_WINBORDER *) mx.obj;

				mx_move(&border->_close, mx_w(border) - mx_w(&border->_close) - 3, 3);
				mx_move(&border->_resize, mx_w(border) - mx_w(&border->_resize) - 2, mx_h(border) - mx_h(&border->_resize) - 2);
				return;
		  }
	 }

	 mx__event_default();
}

static void mx_theme_win95_obj(MX_OBJ * obj)
{
	 if (mx_exposing()) {
		  const MX_RECT *objrect = MXRECT(obj);

		  mx_rectfill(objrect->x1, objrect->y1, objrect->x2, objrect->y2, mx_theme_win95_backcolor);
	 }
}

static void mx_theme_win95_vslider(MX_SLIDER * slider)
{
	 if (mx_exposing()) {
		  int x, y;
		  const MX_RECT *objrect = MXRECT(slider);
		  MX_BITMAP *bit = &mx_theme_win95_buttonup;

		  for (y = 0; y < mx_h(slider); y += mx_h(&mx_theme_win95_scrollback))
				for (x = 0; x < mx_w(slider); x += mx_w(&mx_theme_win95_scrollback))
					 mx_blit(&mx_theme_win95_scrollback, 0, 0, objrect->x1 + x, objrect->y1 + y, mx_w(&mx_theme_win95_scrollback),
								mx_h(&mx_theme_win95_scrollback));

		  if (mx_armed(slider))
				bit = &mx_theme_win95_buttondown;

		  mx_decorate(bit, MXDEF, MXDEF, objrect->x1, objrect->y1 + slider->_upper, objrect->x2, objrect->y1 + slider->_lower);
	 }
}

static void mx_theme_win95_hslider(MX_SLIDER * slider)
{
	 if (mx_exposing()) {
		  int x, y;
		  const MX_RECT *objrect = MXRECT(slider);
		  MX_BITMAP *bit = &mx_theme_win95_buttonup;

		  for (y = 0; y < mx_h(slider); y += mx_h(&mx_theme_win95_scrollback))
				for (x = 0; x < mx_w(slider); x += mx_w(&mx_theme_win95_scrollback))
					 mx_blit(&mx_theme_win95_scrollback, 0, 0, objrect->x1 + x, objrect->y1 + y, mx_w(&mx_theme_win95_scrollback),
								mx_h(&mx_theme_win95_scrollback));

		  if (mx_armed(slider))
				bit = &mx_theme_win95_buttondown;

		  mx_decorate(bit, MXDEF, MXDEF, objrect->x1 + slider->_upper, objrect->y1, objrect->x1 + slider->_lower, objrect->y2);
	 }
}

static void mx_theme_win95_textual_draw(const MX_TEXTUAL * textual, int x1, int y1, int x2, int y2, int offsetx, int offsety)
{
	 long len = 0;
	 const char *text = mx_string_text(&textual->_text, &len);
	 int fore = mx_theme_win95_forecolor;
	 int back = mx_theme_win95_backcolor;

	 if (mx_selected(textual)) {
		  fore = mx_theme_win95_selectforecolor;
		  back = mx_theme_win95_selectbackcolor;
	 }

	 if (mx_disabled(textual))
		  fore = mx_theme_win95_armcolor;

	 if ((mx_is_armable(textual)) && (mx_armed(textual)))
		  back = mx_theme_win95_armcolor;

	 mx_rectfill(x1, y1, x2, y2, back);

	 if (text) {
		  mx__textual_align(textual, &x1, &y1, x2, y2);

		  mx_font_drawblock(mx_theme_win95_font,  text, len, x1 + offsetx, y1 + offsety, fore, fore);
	 }
}

static void mx_theme_win95_textual(MX_TEXTUAL * text)
{
	 if (mx_exposing()) {
		  const MX_RECT *objrect = MXRECT(text);

		  mx_theme_win95_textual_draw(text, objrect->x1, objrect->y1, objrect->x2, objrect->y2, 0, 0);
	 }
}

static void mx_theme_win95_scrollcorner(MX_OBJ * scrollcorner)
{
	 if (mx_exposing()) {
		  const MX_RECT *objrect = MXRECT(scrollcorner);

		  mx_rectfill(objrect->x1, objrect->y1, objrect->x2, objrect->y2, mx_theme_win95_wincolor);
	 }
}

static void mx_theme_win95_scrolltitle(MX_TEXTUAL * scrolltitle)
{
	 if (mx_exposing()) {
		  long len = 0;
		  const char *text = mx_textual_text(scrolltitle, &len);
		  const MX_RECT *objrect = MXRECT(scrolltitle);
		  int x1 = objrect->x1;
		  int y1 = objrect->y1;
		  int x2 = objrect->x2;
		  int y2 = objrect->y2;

		  mx_rectfill(x1, y1, x2, y2, mx_theme_win95_wincolor);

		  if (text) {
				mx__textual_align(scrolltitle, &x1, &y1, x2, y2);
				mx_font_drawblock(mx_theme_win95_font,  text, len, x1, y1, mx_theme_win95_forecolor, mx_theme_win95_forecolor);
		  }
	 }
}

static void mx_theme_win95_scroll(MX_SCROLL * scroll)
{
	 if (mx_exposing()) {
		  const MX_RECT *objrect = MXRECT(scroll);

		  mx_rectfill(objrect->x1, objrect->y1, objrect->x2, objrect->y2, mx_theme_win95_backcolor);
	 }
}

static void mx_theme_win95_button(MX_BUTTON * button)
{
	 if (mx_exposing()) {
		  const MX_RECT *objrect = MXRECT(button);
		  int offset = 0;
		  MX_BITMAP *bit = &mx_theme_win95_buttonup;
		  int fore = mx_theme_win95_forecolor;
		  int x1 = objrect->x1;
		  int y1 = objrect->y1;
		  int x2 = objrect->x2;
		  int y2 = objrect->y2;
		  long len = 0;
		  const char *text = mx_text(button, &len);

		  /* Special handling for close and resize buttons */
		  if (MXID(mx.obj) == MXID_WINCLOSE) {
				bit = &mx_theme_win95_buttonclose;

				if (mx_armed(button))
					 bit = &mx_theme_win95_buttonclose2;

				mx_decorate(bit, MXDEF, MXDEF, x1, y1, x2, y2);
				return;

		  } else if (MXID(mx.obj) == MXID_WINRESIZE) {
				bit = &mx_theme_win95_buttonresize;

				mx_decorate(bit, MXDEF, MXDEF, x1, y1, x2, y2);
				return;
		  }

		  /* Now for normal buttons */
		  if (mx_selected(button)) {
				bit = &mx_theme_win95_buttondown;
				offset = 1;
		  }
		  if (mx_armed(button))
				bit = &mx_theme_win95_buttondown;

		  if (mx_disabled(button))
				fore = mx_theme_win95_disabledcolor;

		  mx_decorate(bit, MXDEF, MXDEF, x1, y1, x2, y2);

		  if (text) {
				mx__textual_align(MXTEXTUAL(button), &x1, &y1, x2, y2);
				mx_font_drawblock(mx_theme_win95_font,  text, len, x1 + offset, y1 + offset, fore, fore);
		  }
	 }
}

void mx_theme_win95_listelem(MX_LISTELEM * listelem)
{
	 if (mx_exposing()) {
		  const MX_RECT *objrect = MXRECT(listelem);

		  mx_theme_win95_textual_draw(MXTEXTUAL(listelem), objrect->x1, objrect->y1, objrect->x2, objrect->y2, 0, 0);
	 }
}

static void mx_theme_win95_root(MX_WIN * root)
{
	 if (mx_exposing()) {
		  const MX_RECT *objrect = MXRECT(root);

		  mx_rectfill(objrect->x1, objrect->y1, objrect->x2, objrect->y2, mx_theme_win95_wincolor);
	 }
}

static void mx_theme_win95_winborder(MX_WINBORDER * border)
{
	 if (mx_exposing()) {
		  MX_WIN *owner = MXOBJ(border)->_win;
		  const MX_RECT *objrect = MXRECT(border);
		  int fill = mx_theme_win95_armcolor;
		  int fore = mx_theme_win95_wincolor;
		  int x1 = objrect->x1;
		  int y1 = objrect->y1;
		  int x2 = objrect->x2;
		  int y2 = objrect->y2;
		  MX_BITMAP *bit = &mx_theme_win95_buttonup;

		  if (mx_win_active(owner)) {
				fill = mx_theme_win95_selectbackcolor;
				fore = mx_theme_win95_selectforecolor;
		  }

		  mx_decorate(bit, MXDEF, MXDEF, x1, y1, x2, y2);
		  mx_rectfill(x1 + 2, y1 + 2, x2 - 2, mx_y1(owner) - 1, fill);

		  if (owner) {
				long len = 0;
				const char *text = mx_text(owner, &len);

				if (text) {
					 mx__textual_align(MXTEXTUAL(owner), &x1, &y1, x2, y2);
					 mx_font_drawblock(mx_theme_win95_font,  text, len, x1 + 3, y1 + 3, fore, fore);
				}
		  }
	 }
}

static void mx_theme_win95_win(MX_WIN * win)
{
	 if (mx_exposing()) {
		  const MX_RECT *objrect = MXRECT(win);

		  mx_rectfill(objrect->x1, objrect->y1, objrect->x2, objrect->y2, mx_theme_win95_wincolor);
	 }
}

static void mx_theme_win95_textsize(const char *text, int l, int *w, int *h)
{
	 mx_font_blocksize(mx_theme_win95_font, text, l, w, h);
}

MX_THEME mx_theme_win95 = {
	 mx_theme_win95_start,
	 mx_theme_win95_stop,
	 mx_theme_win95_event,
	 mx_theme_win95_obj,
	 mx_theme_win95_vslider,
	 mx_theme_win95_hslider,
	 mx_theme_win95_textual,
	 mx_theme_win95_scrollcorner,
	 mx_theme_win95_scrolltitle,
	 mx_theme_win95_scroll,
	 mx_theme_win95_button,
	 mx_theme_win95_listelem,
	 mx_theme_win95_root,
	 mx_theme_win95_winborder,
	 mx_theme_win95_win,
	 mx_theme_win95_textsize
};

#endif
#endif
#endif

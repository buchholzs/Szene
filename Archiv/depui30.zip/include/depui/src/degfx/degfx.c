/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#if defined(MX_LIB) || defined(MX_PLATFORM_DEGFX)
#ifndef MX_HAVE_PLATFORM_DEGFX
#define MX_HAVE_PLATFORM_DEGFX
#define MX_PLATFORM_EXISTS

#include "depui/depui.h"
#include "degfx/degfx.h"
#include <string.h>

#define MX_DEGFX_FONTDRAW
#include "degfx/degfx.c"

void mx__degfx_textsize(const char *text, int l, int *w, int *h)
{
	 mx_font_blocksize(0, text, l, w, h);
}

static MX_PLATFORM_RESOLUTION mx__degfx_resolutions[] = {
	 {320, 200, "320 x 200"},
	 {640, 480, "640 x 480"},
	 {800, 600, "800 x 600"},
	 {1024, 768, "1024 x 768"},
	 {1280, 1024, "1280 x 1024"},
	 {0, 0, 0}
};

static MX_PLATFORM_DEPTH mx__degfx_depths[] = {
	 {4, "4"},
	 {8, "8"},
	 {16, "16"},
	 {24, "24"},
	 {32, "32"},
	 {0, 0}
};

struct MX_PLATFORM_DRIVER mx__degfx_drivers[] = {
#ifdef MX_HAVE_DRIVER_FULLSCREEN
	 {&mx_driver_fullscreen, "fullscreen"},
#endif
#ifdef MX_HAVE_DRIVER_WINDOWED
	 {&mx_driver_windowed, "windowed"},
#endif
#ifdef MX_HAVE_DRIVER_VGA
	 {&mx_driver_vga, "vga"},
#endif
#ifdef MX_HAVE_DRIVER_13H
	 {&mx_driver_13h, "13h"},
#endif
	 {0, 0}
};

struct MX_PLATFORM_THEME mx__degfx_themes[] = {
#ifdef MX_HAVE_THEME_DEFAULT
	 {&mx_theme_default, "Default"},
#endif
#ifdef MX_HAVE_THEME_WIN95
	 {&mx_theme_win95, "Win95"},
#endif
#ifdef MX_HAVE_THEME_MONO
	 {&mx_theme_mono, "Monochrome"},
#endif
#ifdef MX_HAVE_THEME_ROUNDED
	 {&mx_theme_rounded, "Rounded"},
#endif
	 {0, 0}
};

void mx_platform_modes(MX_PLATFORM_DRIVER * d[], MX_PLATFORM_RESOLUTION * r[], MX_PLATFORM_DEPTH * c[], MX_PLATFORM_THEME * t[])
{
	 *d = mx__degfx_drivers;
	 *r = mx__degfx_resolutions;
	 *c = mx__degfx_depths;
	 *t = mx__degfx_themes;
}

unsigned mx_platform_start(int w, int h, int c, void *driver)
{
	 MX_GFX_ARGS args;

	 memset(&args, 0, sizeof(args));
	 args.w = w;
	 args.h = h;
	 args.c = c;
	 args.driver = (MX_DRIVER *) driver;
	 args.redraw = mx__gui_redraw;

	 return mx_gfx_start(&args);
}

void mx_platform_stop(void)
{
	 mx_gfx_stop();
}

unsigned mx_platform_clip(const MX_RECT * r)
{
	 return mx_bitmap_clip(MXSCREEN, r);
}

const MX_RECT *mx_platform_rect(void)
{
	 return (&(mx_gfx_info()->screen));
}

unsigned mx_platform_poll(void)
{
	 return mx_gfx_poll();
}

void mx_platform_dirty(const MX_RECT * rect)
{
	 mx_gfx_dirty(rect);
}

unsigned mx_platform_pointer(int *px, int *py, int *pb)
{
	 return mx_gfx_pointer(px, py, pb);
}

unsigned mx_platform_key(int *scan, long *ascii)
{
	 return mx_gfx_key(scan, ascii);
}

int mx_gfxmain(int argc, char *argv[])
{
	 return mx_guimain(argc, argv);
}

#endif
#endif

/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#if defined(MX_LIB) || defined(MX_DEPUI_SLIDER)
#ifndef MX_HAVE_DEPUI_SLIDER
#define MX_HAVE_DEPUI_SLIDER

#include "depui/depui.h"

#define MX__SLIDER_SIZE 10

void mx_slider_set(MX_SLIDER * slider, int range, int size, int value)
{
	 int highest;

	 MXINVARIANT(MXOBJ(slider));

	 if (range != MXDEF)
		  slider->_range = range;
	 if (size != MXDEF)
		  slider->_size = size;
	 if (value != MXDEF)
		  slider->_value = value;

	 highest = slider->_range - slider->_size;

	 if (slider->_value > highest)
		  slider->_value = highest;
	 if (slider->_value < 0)
		  slider->_value = 0;

	 slider->_upper = 0;
	 slider->_lower = slider->_dim + 1;

	 if (slider->_range) {
		  const int _range = (slider->_dim + 1) - slider->_min;
		  const int _thumb = slider->_size * _range / slider->_range;
		  const int _index = slider->_value * _range / slider->_range;

		  slider->_upper = _index;
		  slider->_lower = slider->_upper + _thumb + slider->_min;
	 }
}

void mx_slider_to(MX_SLIDER * slider, int value)
{
	 const int oldvalue = slider->_value;

	 MXINVARIANT(MXOBJ(slider));

	 mx_slider_set(slider, MXDEF, MXDEF, value);

	 if (slider->_value != oldvalue) {

		  if (slider->_dim == mx_w(slider)) {
				mx_emit(MX_HSCROLL, 0);

		  } else if (slider->_dim == mx_h(slider)) {
				mx_emit(MX_VSCROLL, 0);

		  } else {
				MXASSERT(0);
		  }

		  mx_dirty(slider, true);
	 }
}

int mx_slider_value(MX_SLIDER * slider)
{
	 MXINVARIANT(MXOBJ(slider));

	 return slider->_value;
}

void mx_vslider_class(void)
{
	 MX_SLIDER *slider = (MX_SLIDER *) mx.obj;

	 MXINVARIANT(MXOBJ(mx.obj));

	 switch (mx.event) {

	 case MX_EXPOSE:
		  mx__theme->vslider(slider);
		  return;

	 case MX_ARM:
		  mx_dirty(slider, true);

		  mx_obj_class();
		  mx_wantmove(slider, mx_armed(slider));

		  return;

	 case MX_POINTER_PRESS:{
				const MX_POINTER_INFO *info = mx_pointer_info();

				if (info->y < mx_y1(slider) + slider->_upper) {
					 mx_slider_to(slider, slider->_value - slider->_size);
					 return;

				} else if (info->y > mx_y1(slider) + slider->_lower) {
					 mx_slider_to(slider, slider->_value + slider->_size);
					 return;
				}

				mx_pointer_hold();
				break;

		  }
	 case MX_POINTER_RELEASE:
		  mx_dirty(slider, true);
		  mx_pointer_release();
		  break;

	 case MX_POINTER_MOVE:
		  if (mx_armed(slider)) {
				const MX_POINTER_INFO *info = mx_pointer_info();

				if ((info->dy) && (slider->_range)) {
					 const int _range = mx_h(slider) - 2 - slider->_min;
					 const int dy = info->dy * slider->_range / _range;

					 mx_slider_to(slider, slider->_value + dy);
				}
		  }
		  break;

	 case MX_GEOMETRY:
		  slider->_dim = mx_h(slider);
		  mx_slider_set(slider, MXDEF, MXDEF, MXDEF);
		  return;

	 case MX_DEFAULTRECT:{
				MX_RECT *rect = mx_defaultrect_data();

				rect->x2 = rect->x1 + MX__SLIDER_SIZE;
				return;
		  }

	 default:
		  break;
	 }
	 mx_obj_class();
}

MX_SLIDER *mx_obj_vslider(MX_SLIDER * slider, size_t size, MX_OBJ * parent, int theid)
{
	 MXMINSIZE(size, MX_SLIDER);

	 slider = (MX_SLIDER *) mx_obj(MXOBJ(slider), mx_vslider_class, size, parent, theid);
	 if (slider) {
		  MXNAMESET(slider, "vslider");

		  mx_armable(slider, true);
		  mx_selectable(slider, true);
		  slider->_min = 5;
	 }
	 MXINVARIANT(MXOBJ(slider));
	 return slider;
}

void mx_hslider_class(void)
{
	 MX_SLIDER *slider = (MX_SLIDER *) mx.obj;

	 MXINVARIANT(MXOBJ(mx.obj));

	 switch (mx.event) {

	 case MX_EXPOSE:
		  mx__theme->hslider(slider);
		  return;

	 case MX_ARM:
		  mx_dirty(slider, true);

		  mx_obj_class();
		  mx_wantmove(slider, mx_armed(slider));

		  return;

	 case MX_POINTER_PRESS:{
				const MX_POINTER_INFO *info = mx_pointer_info();

				if (info->x < mx_x1(slider) + slider->_upper) {
					 mx_slider_to(slider, slider->_value - slider->_size);
					 return;

				} else if (info->x > mx_x1(slider) + slider->_lower) {
					 mx_slider_to(slider, slider->_value + slider->_size);
					 return;
				}

				mx_pointer_hold();
				break;

		  }
	 case MX_POINTER_RELEASE:
		  mx_dirty(slider, true);
		  mx_pointer_release();
		  break;

	 case MX_POINTER_MOVE:
		  if (mx_armed(slider)) {
				const MX_POINTER_INFO *info = mx_pointer_info();

				if ((info->dx) && (slider->_range)) {
					 const int _range = mx_w(slider) - 2 - slider->_min;
					 const int dx = info->dx * slider->_range / _range;

					 mx_slider_to(slider, slider->_value + dx);
				}
		  }
		  break;

	 case MX_GEOMETRY:
		  slider->_dim = mx_w(slider);
		  mx_slider_set(slider, MXDEF, MXDEF, MXDEF);
		  return;

	 case MX_DEFAULTRECT:{
				MX_RECT *rect = mx_defaultrect_data();

				rect->y2 = rect->y1 + MX__SLIDER_SIZE;
				return;
		  }

	 default:
		  break;
	 }
	 mx_obj_class();
}

MX_SLIDER *mx_obj_hslider(MX_SLIDER * slider, size_t size, MX_OBJ * parent, int theid)
{
	 MXMINSIZE(size, MX_SLIDER);

	 slider = (MX_SLIDER *) mx_obj(MXOBJ(slider), mx_hslider_class, size, parent, theid);
	 if (slider) {
		  MXNAMESET(slider, "hslider");

		  mx_armable(slider, true);
		  mx_selectable(slider, true);
		  slider->_min = 5;
	 }
	 MXINVARIANT(MXOBJ(slider));
	 return slider;
}

#endif
#endif

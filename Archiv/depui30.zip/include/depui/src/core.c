/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#include "depui/depui.h"
#include <string.h>

#ifdef DEBUG
static const char *mx__eventname[] = {
	 "NOTHING",
	 "DESTRUCT",
	 "EXPOSE",
	 "GEOMETRY",
	 "DEFAULTRECT",
	 "ARM",
	 "SELECT",
	 "TOP",
	 "ACTIVE",
	 "VSCROLL",
	 "HSCROLL",
	 "LIST_CHANGED",
	 "THEME_CHANGE",

	 "_INTERACT_BEGIN",
	 "POINTER_WANT",
	 "POINTER_ENTER",
	 "POINTER_LEAVE",
	 "POINTER_MOVE",
	 "POINTER_PRESS",
	 "POINTER_RELEASE",
	 "POINTER_CLICK",
	 "FOCUS_WANT",
	 "FOCUS_LOST",
	 "FOCUS_GOT",
	 "KEY",
	 "KEY_UNUSED",
	 "_INTERACT_END",

	 "MX_GFXMODE_OK",
	 "MX_FILESEL_OK",

	 "LAST"
};
#endif

/* Publically accessable static data */
MX_EVENTSTACK mx;
const MX_THEME *mx__theme;

/* Private static data */
typedef struct PRIVATE_STATICS {
	 MX_WIN _root;

	 MX_RECT _clip;

	 MX_POINTER_INFO _pointer;
	 MX_OBJ *_pointed;
	 MX_OBJ *_pointerhold;

	 MX_OBJ *_focus;
	 MX_WIN *_active;

#ifndef NDEBUG
	 int _framerate;
	 int _framecount;
	 clock_t _framenext;
	 unsigned _exposing:1;
#endif

	 unsigned _running:1;
} PRIVATE_STATICS;

static PRIVATE_STATICS mx_;

/* Some macros to make the code a bit neater */
#define OBJ     MXOBJ(mx.obj)
#define ROOTOBJ MXOBJ(&mx_._root)
#define ROOTWIN (&mx_._root)

void mx_handler_default(void)
{
	 MXINVARIANT(OBJ);

	 OBJ->_class();
}

void mx__event_default(void)
{
	 MXINVARIANT(OBJ);
	 MXINVARIANT(MXOBJ(OBJ->_win));
	 MXASSERT(OBJ->_win);

	 if (OBJ->_win->_handler)
		  OBJ->_win->_handler(OBJ->_win);

	 else
		  OBJ->_class();
}

#ifdef DEBUG
#ifdef MX_PLATFORM_DEGFX
typedef union STRINGVEC {
	 MX_STRING *data;
	 MX_VECTOR vector;
} STRINGVEC;

static int mx__eventcount = 0;
static int mx__eventlogsize = 20;
static STRINGVEC mx__eventlog;

static void mx__logevent(void)
{
	 int len;
	 char temp[1024];
	 char *ptr;
	 MX_STRING string;

	 if (mx.event == MX_EXPOSE)
		  return;

	 sprintf(temp, "%6i %s %s[%p] %p (%i)", mx__eventcount++, mx__eventname[mx.event], MXNAME(mx.obj), (void *) mx.obj, mx.data,
				MX__ATOM(mx.obj)->_lock);

	 len = strlen(temp);
	 ptr = (char *) mx_malloc(len + 2);
	 strcpy(ptr, temp);

	 mx_string(&string);
	 mx_string_set(&string, ptr, len, mx_free);
	 mx_vector_append(&mx__eventlog, &string, 1);

	 if (mx_vector_size(&mx__eventlog) > mx__eventlogsize) {
		  mx_string_free(&mx__eventlog.data[0]);
		  mx_vector_remove(&mx__eventlog, 0, 1);
	 }
}
#endif
#endif

void *mx_obj_event(MX_OBJ * obj, MX_EVENT event, const void *data)
{
	 void *ret = 0;
	 const MX_EVENTSTACK prev = mx;
	 MX_WIN *win;

	 if (!obj)
		  obj = OBJ;
	 win = obj->_win;

	 MXINVARIANT(obj);
	 MXINVARIANT(MXOBJ(win));

	 MXASSERT(event);
	 MXASSERT(event != MX_EXPOSE);

#if !defined(NDEBUG)
	 if (mx_._exposing)
		  MXASSERT(0);
#endif

	 if (event != MX_DESTRUCT) {
		  mx_lock(win);
		  mx_lock(obj);
	 }

	 /* Before we try to send a message, filter out interactive messages when
	    an app has a modal window open */
	 if ((win->_modallock) && (event > MX__INTERACT_BEGIN) && (event < MX__INTERACT_END))
		  goto done;

	 /* A (little) dirty hack to make the mx.obj a derived class of MX_OBJ
	    which makes the nice macros usable even for mx.obj.  The cast is safe
	    becasue MX_DERIVED is only a wrapper of MX_OBJ and has (must have!) no 
	    data of its own */
	 mx.obj = (MX_DERIVED *) obj;
	 mx.event = event;
	 mx.data = data;
	 mx._answer = 0;

	 MXASSERT(OBJ == obj);

#ifdef DEBUG
	 fprintf(stderr, "Enter event %s to %s[%p] with %p level %i\n", mx__eventname[event], MXNAME(obj), (void *) obj, data,
				MX__ATOM(obj)->_lock);
#ifdef MX_PLATFORM_DEGFX
	 mx__logevent();
#endif
#endif

	 /* Let the theme wrap the event, or send it directly */
	 if (mx__theme->event)
		  mx__theme->event();
	 else
		  mx__event_default();

#ifdef DEBUG
	 fprintf(stderr, "Exit event %s to %s[%p] with %p level %i\n", mx__eventname[mx.event], MXNAME(obj), (void *) obj, mx.data,
				MX__ATOM(obj)->_lock);
#endif

	 ret = mx._answer;
	 mx = prev;

  done:
	 if (event != MX_DESTRUCT) {
		  mx_unlock(obj);
		  mx_unlock(win);
	 }

	 return ret;
}

void *mx_emit(MX_EVENT event, const void *data)
{
	 MXASSERT(OBJ->_parent);

	 return mx_obj_event(OBJ->_parent, event, data);
}

void *mx_inform(MX_EVENT event, const void *data)
{
	 MXASSERT(OBJ->_win);

	 if (OBJ->_win->_parent)
		  return mx_event(OBJ->_win->_parent, event, data);

	 return 0;
}

void mx_answer(void *answer)
{
	 mx._answer = answer;
}

static void mx__theme_inform(MX_OBJ * obj)
{
	 MX_OBJ *ptr = obj->_last;

	 while (ptr) {
		  mx__theme_inform(ptr);
		  ptr = ptr->_prev;
	 }

	 mx_obj_event(obj, MX_THEME_CHANGE, 0);
}

void mx_theme_set(MX_THEME * theme)
{
	 if (theme == mx__theme)
		  return;

	 if (theme->start()) {
		  const MX_THEME *old = mx__theme;

		  old->stop();
		  mx__theme = theme;

		  mx__theme_inform(ROOTOBJ);
	 }
}

const MX_POINTER_INFO *mx_pointer_info(void)
{
	 return &mx_._pointer;
}

unsigned mx_pointer_hold(void)
{
	 if (OBJ == mx_._pointed) {
		  mx_._pointerhold = mx_._pointed;
		  return true;
	 }
	 return false;
}

unsigned mx_pointer_release(void)
{
	 if (OBJ == mx_._pointerhold) {
		  mx_._pointerhold = 0;
		  return true;
	 }
	 return false;
}

const MX_KEY_INFO *mx_key_info(void)
{
	 if ((mx.event == MX_KEY) || (mx.event == MX_KEY_UNUSED))
		  return (const MX_KEY_INFO *) mx.data;

	 return 0;
}

int mx_obj_x(MX_OBJ * obj)
{
	 if (!obj)
		  obj = OBJ;

	 MXINVARIANT(obj);

	 if (obj->_parent)
		  return mx_x1(obj) - mx_x1(obj->_parent);

	 return mx_x1(obj);
}

int mx_obj_y(MX_OBJ * obj)
{
	 if (!obj)
		  obj = OBJ;

	 MXINVARIANT(obj);

	 if (obj->_parent)
		  return mx_y1(obj) - mx_y1(obj->_parent);

	 return mx_y1(obj);
}

static void mx__move(MX_OBJ * obj, const int dx, const int dy)
{
	 MX_RECT rect;
	 rect = *MXRECT(obj);

	 rect.x1 -= dx;
	 rect.y1 -= dy;
	 rect.x2 -= dx;
	 rect.y2 -= dy;
	 mx_rectatom_place(MX__RECTATOM(obj), &rect);

	 obj = obj->_last;
	 while (obj) {
		  mx__move(obj, dx, dy);
		  obj = obj->_prev;
	 }
}

void mx_obj_place(MX_OBJ * obj, const MX_RECT * rect)
{
	 MX_OBJ *ptr;
	 int dx, dy;

	 if (!obj)
		  obj = OBJ;

	 ptr = obj->_last;
	 dx = mx_x1(obj);
	 dy = mx_y1(obj);

	 MXASSERT(rect);
	 MXINVARIANT(obj);

	 mx_rectatom_place(MX__RECTATOM(obj), rect);

	 dx -= mx_x1(obj);
	 dy -= mx_y1(obj);

	 while (ptr) {
		  mx__move(ptr, dx, dy);
		  ptr = ptr->_prev;
	 }
}

void mx_obj_position(MX_OBJ * obj, int x, int y, int w, int h)
{
	 MX_RECT rect;

	 if (!obj)
		  obj = OBJ;

	 MXINVARIANT(obj);
	 MXINVARIANT(obj->_parent);
	 MXASSERT(obj != ROOTOBJ);

	 rect = *MXRECT(obj);
	 if (x != MXDEF)
		  rect.x1 = x + mx_x1(obj->_parent);
	 if (y != MXDEF)
		  rect.y1 = y + mx_y1(obj->_parent);
	 if (w == MXDEF)
		  w = mx_w(obj);
	 if (h == MXDEF)
		  h = mx_h(obj);
	 rect.x2 = rect.x1 + w;
	 rect.y2 = rect.y1 + h;

	 mx_obj_place(obj, &rect);
}

void mx_obj_move(MX_OBJ * obj, int x, int y)
{
	 if (!obj)
		  obj = OBJ;

	 mx_obj_position(obj, x, y, mx_w(obj), mx_h(obj));
}

void mx_obj_resize(MX_OBJ * obj, int w, int h)
{
	 if (!obj)
		  obj = OBJ;

	 mx_obj_position(obj, mx_obj_x(obj), mx_obj_y(obj), w, h);
}

void mx_obj_geometry(MX_OBJ * obj)
{
	 if (!obj)
		  obj = OBJ;

	 MXINVARIANT(obj);
	 MXASSERT(obj != ROOTOBJ);

	 mx_obj_event(obj, MX_GEOMETRY, 0);
}

MX_RECT *mx_defaultrect_data(void)
{
	 MXINVARIANT(OBJ);

	 if (mx.event == MX_DEFAULTRECT)
		  return (MX_RECT *) mx.data;

	 return 0;
}

void mx_obj_defaultrect(MX_OBJ * obj, MX_RECT * rect)
{
	 MX_RECT data;

	 if (!obj)
		  obj = OBJ;

	 MXINVARIANT(obj);
	 MXASSERT(obj != ROOTOBJ);

	 data = *MXRECT(obj);

	 mx_obj_event(obj, MX_DEFAULTRECT, &data);

	 if (rect)
		  *rect = data;
	 else
		  mx_obj_place(obj, &data);
}

void mx_obj_layout(MX_OBJ * obj, MX_LAYOUT flags, const MX_OBJ * other, int x, int y)
{
	 int w, h;
	 MX_RECT rect, objrect;

	 if (!obj)
		  obj = OBJ;

	 if (!other)
		  other = ROOTOBJ;

	 MXINVARIANT(obj);
	 MXINVARIANT(other);
	 MXASSERT(obj != ROOTOBJ);

	 objrect = *MXRECT(obj);
	 rect = *MXRECT(other);

	 w = objrect.x2 - objrect.x1;
	 h = objrect.y2 - objrect.y1;

	 if (flags & MX_LAYOUT_W)
		  w = rect.x2 - rect.x1;

	 if (flags & MX_LAYOUT_H)
		  h = rect.y2 - rect.y1;

	 if (flags & MX_LAYOUT_LEFT)
		  objrect.x1 = rect.x1 - w - x;

	 else if (flags & MX_LAYOUT_RIGHT)
		  objrect.x1 = rect.x2 + x;

	 else if (flags & MX_LAYOUT_X1)
		  objrect.x1 = rect.x1 + x;

	 else if (flags & MX_LAYOUT_X2)
		  objrect.x1 = rect.x2 - w + x;

	 else if (flags & MX_LAYOUT_HCENTER)
		  objrect.x1 = (rect.x2 - rect.x1 - w) / 2 + x;

	 if (flags & MX_LAYOUT_TOP)
		  objrect.y1 = rect.y1 - h - y;

	 else if (flags & MX_LAYOUT_BOTTOM)
		  objrect.y1 = rect.y2 + y;

	 else if (flags & MX_LAYOUT_Y1)
		  objrect.y1 = rect.y1 + y;

	 else if (flags & MX_LAYOUT_Y2)
		  objrect.y1 = rect.y2 - h + y;

	 else if (flags & MX_LAYOUT_VCENTER)
		  objrect.y1 = (rect.y2 - rect.y1 - h) / 2 + y;

	 objrect.x2 = objrect.x1 + w;
	 objrect.y2 = objrect.y1 + h;

	 mx_obj_place(obj, &objrect);
}

void mx_obj_wantmove(MX_OBJ * obj, unsigned wantmove)
{
	 if (!obj)
		  obj = OBJ;

	 MXINVARIANT(obj);

	 obj->_wantmove = (wantmove) ? true : false;
}

unsigned mx_obj_armed(const MX_OBJ * obj)
{
	 if (!obj)
		  obj = OBJ;

	 MXINVARIANT(obj);

	 return (obj->_armed) ? true : false;
}

void *mx_obj_arm(MX_OBJ * obj, unsigned arm)
{
	 if (!obj)
		  obj = OBJ;

	 MXINVARIANT(obj);

    if (!obj->_armable)
        return 0;

    if (obj->_disabled)
        return 0;

    if ((obj->_armed) && (arm))
        return 0;
        
    if ((!obj->_armed) && (!arm))
        return 0;

    return mx_obj_event(obj, MX_ARM, (arm) ? (obj) : 0);
}

void mx_obj_armable(MX_OBJ * obj, unsigned armable)
{
	 if (!obj)
		  obj = OBJ;

	 MXINVARIANT(obj);

	 obj->_armable = (armable) ? true : false;
}

unsigned mx_obj_is_armable(const MX_OBJ * obj)
{
	 if (!obj)
		  obj = OBJ;

	 MXINVARIANT(obj);

	 return (obj->_armable) ? true : false;
}

unsigned mx_obj_selected(const MX_OBJ * obj)
{
	 if (!obj)
		  obj = OBJ;

	 MXINVARIANT(obj);

	 return (obj->_selected) ? true : false;
}

void *mx_obj_select(MX_OBJ * obj, unsigned select)
{
	 if (!obj)
		  obj = OBJ;

	 MXINVARIANT(obj);

    if (!obj->_selectable)
        return 0;

    if (obj->_disabled)
        return 0;

    if ((obj->_selected) && (select))
        return 0;
        
    if ((!obj->_selected) && (!select))
        return 0;

    return mx_obj_event(obj, MX_SELECT, (select) ? (obj) : 0);
}

void mx_obj_selectable(MX_OBJ * obj, unsigned selectable)
{
	 if (!obj)
		  obj = OBJ;

	 MXINVARIANT(obj);

	 obj->_selectable = (selectable) ? true : false;
}

unsigned mx_obj_is_selectable(const MX_OBJ * obj)
{
	 if (!obj)
		  obj = OBJ;

	 MXINVARIANT(obj);

	 return (obj->_selectable) ? true : false;
}

void mx_obj_disable(MX_OBJ * obj, unsigned disable)
{
	 if (!obj)
		  obj = OBJ;

	 MXINVARIANT(obj);

	 obj->_disabled = (disable) ? true : false;
}

unsigned mx_obj_disabled(const MX_OBJ * obj)
{
	 if (!obj)
		  obj = OBJ;

	 MXINVARIANT(obj);

	 /* The object might be blocked because of a modal window */
	 if (obj->_win->_modallock)
		  return true;

	 /* The object might just be disabled */
	 return (obj->_disabled) ? true : false;
}

void *mx_obj_top(MX_OBJ * obj)
{
	 MX_OBJ *parent;

	 if (!obj)
		  obj = OBJ;

	 parent = obj->_parent;
	 if (!parent)
		  return obj;

	 if (!obj->_next)
		  return obj;

	 MXINVARIANT(obj);
	 MXINVARIANT(parent);

	 mx_node_remove(obj);
	 mx_node_insert(obj, parent);

	 return mx_obj_event(obj, MX_TOP, 0);
}

static void mx__focus(MX_OBJ * obj)
{
	 if (obj == mx_._focus)
		  return;

	 if (mx_obj_event(obj, MX_FOCUS_WANT, 0)) {

		  if (mx_._focus)
				mx_obj_event(mx_._focus, MX_FOCUS_LOST, 0);

		  mx_._focus = obj;

		  if (mx_._focus)
				mx_obj_event(mx_._focus, MX_FOCUS_GOT, 0);
	 }
}

void mx_obj_focus(MX_OBJ * obj)
{
	 if (!obj)
		  obj = OBJ;

	 MXINVARIANT(obj);

	 mx__focus(obj);
}

void mx_obj_unfocus(MX_OBJ * obj)
{
	 if (obj == mx_._focus)
		  mx__focus(0);
}

unsigned mx_win_active(const MX_WIN * win)
{
	 if (win == mx_._active)
		  return true;

	 return false;
}

unsigned mx_win_activate(MX_WIN * win)
{
	 MX_WIN *oldactive = mx_._active;

	 if (win == oldactive)
		  return false;

	 mx_._active = win;

	 if (oldactive)
		  mx_event(oldactive, MX_ACTIVE, 0);

	 if (win)
		  mx_event(win, MX_ACTIVE, win);

	 return true;
}

void mx_obj_class(void)
{
	 MX_OBJ *obj = OBJ;

	 MXINVARIANT(obj);

	 switch (mx.event) {

	 case MX_DESTRUCT:
		  while (obj->_last) {
				MX_OBJ *ptr = obj->_last;

				mx_node_remove(ptr);
				mx_delete(ptr);
		  }
		  return;

	 case MX_EXPOSE:
		  mx__theme->obj(obj);
		  return;

	 case MX_THEME_CHANGE:
		  mx_obj_geometry(obj);
		  return;

	 case MX_ARM:
		  if (obj->_armable)
				obj->_armed = (mx.data) ? true : false;
		  return;

	 case MX_SELECT:
		  if (obj->_selectable)
				obj->_selected = (mx.data) ? true : false;
		  return;

	 case MX_POINTER_PRESS:
		  mx_arm(mx.obj, true);
		  mx_focus(mx.obj);
		  return;

	 case MX_POINTER_RELEASE:
		  if (obj->_armed) {
				mx_event(mx.obj, MX_POINTER_CLICK, 0);
				mx_arm(mx.obj, false);
		  }
		  return;

	 case MX_POINTER_LEAVE:
		  if (obj->_armed)
				mx_arm(mx.obj, false);
		  return;

	 default:
		  return;
	 }
}

static void mx__destroy(void *atom)
{
	 MX_OBJ *obj = (MX_OBJ *) atom;

	 MXINVARIANT(obj);

#ifdef DEBUG
	 fprintf(stderr, "@@ Destroy %s[%p]\n", MXNAME(obj), (void *) obj);
#endif

	 if (obj->_parent)
		  mx_platform_dirty(MXRECT(obj));

	 mx_obj_event(obj, MX_DESTRUCT, 0);

	 mx_node_remove(obj);

	 if (obj == mx_._pointed) {
		  mx_._pointed = 0;
		  mx_._pointer.x = -1;
	 }

	 if (obj == mx_._pointerhold) {
		  mx_._pointerhold = 0;
		  mx_._pointer.x = -1;
	 }

	 if (obj == MXOBJ(mx_._active))
		  mx_._active = 0;

	 if (obj == mx_._focus)
		  mx_._focus = 0;
}

void *mx_obj(MX_OBJ * obj, MX_CLASS _class, size_t size, MX_OBJ * parent, int theid)
{
	 MX_RECT rect;

    if (!parent)
        parent = ROOTOBJ;

    if (obj != ROOTOBJ) {
        MXINVARIANT(parent);
        assert(obj != parent);
    }

	 MXMINSIZE(size, MX_OBJ);
	 obj = (MX_OBJ *) mx_rectatom(MX__RECTATOM(obj), mx__destroy, size);

	 obj->_class = (_class) ? (_class) : mx_obj_class;
	 obj->_win = (obj == ROOTOBJ) ? (ROOTWIN) : (parent->_win);
	 obj->_armed = false;
	 obj->_selected = false;
	 obj->_id = theid;
	 MXNAMESET(obj, "obj");
#ifdef DEBUG
	 obj->_magic = MXMAGIC;
#endif

	 rect.x1 = -1;
	 rect.y1 = -1;
	 rect.x2 = -1;
	 rect.y2 = -1;
	 mx_rectatom_place(MX__RECTATOM(obj), &rect);

    if (obj != parent)
        mx_node_insert(obj, parent);

	 MXINVARIANT(obj);
	 return obj;
}

void mx_textual_set(MX_TEXTUAL * text, const char *str, long len, MX_FREE free)
{
	 mx_string_set(&text->_text, str, len, free);

	 mx__theme->textsize(str, len, &text->_textwidth, &text->_textheight);
}

const char *mx_textual_text(const MX_TEXTUAL * text, long *len)
{
	 return mx_string_text(&text->_text, len);
}

int mx_textual_width(const MX_TEXTUAL * text)
{
	 return text->_textwidth;
}

int mx_textual_height(const MX_TEXTUAL * text)
{
	 return text->_textheight;
}

void mx_textual_align(MX_TEXTUAL * text, MX_ALIGN align)
{
	 text->_align = align;
}

MX_ALIGN mx_textual_align_get(const MX_TEXTUAL * text)
{
	 return text->_align;
}

void mx_textual_class(void)
{
	 MX_TEXTUAL *textual = (MX_TEXTUAL *) mx.obj;

	 MXINVARIANT(OBJ);

	 switch (mx.event) {

	 case MX_DESTRUCT:
		  mx_string_free(&textual->_text);
		  break;

	 case MX_EXPOSE:
		  mx__theme->textual(textual);
		  return;

	 case MX_DEFAULTRECT:{
				MX_RECT *rect = mx_defaultrect_data();

				rect->x2 = rect->x1 + textual->_textwidth;
				rect->y2 = rect->y1 + textual->_textheight;
				return;
		  }

	 case MX_THEME_CHANGE:{
				long len = 0;
				const char *text = mx_string_text(&textual->_text, &len);

				mx__theme->textsize(text, len, &textual->_textwidth, &textual->_textheight);
				break;
		  }

	 default:
		  break;
	 }
	 mx_obj_class();
}

MX_TEXTUAL *mx_obj_textual(MX_TEXTUAL * text, size_t size, MX_OBJ * parent, int theid)
{
	 MXMINSIZE(size, MX_TEXTUAL);

	 text = (MX_TEXTUAL *) mx_obj(MXOBJ(text), mx_textual_class, size, parent, theid);
	 if (text) {
		  MXNAMESET(text, "textual");

		  mx_string(&text->_text);
		  mx_textual_set(text, 0, -1, 0);
	 }
	 MXINVARIANT(MXOBJ(text));
	 return text;
}

void mx__textual_align(const MX_TEXTUAL * textual, int *x1, int *y1, int x2, int y2)
{
	 if (textual->_align & MX_ALIGN_RIGHT)
		  *x1 = x2 - textual->_textwidth;

	 else if (textual->_align & MX_ALIGN_HCENTER)
		  *x1 += (x2 - *x1) / 2 - (textual->_textwidth) / 2;

	 if (textual->_align & MX_ALIGN_BOTTOM)
		  *y1 = y2 - textual->_textheight;

	 else if (textual->_align & MX_ALIGN_VCENTER)
		  *y1 += (y2 - (*y1)) / 2 - (textual->_textheight) / 2;
}

void mx_button_class(void)
{
	 MX_BUTTON *button = (MX_BUTTON *) mx.obj;

	 MXINVARIANT(OBJ);

	 switch (mx.event) {

	 case MX_EXPOSE:
		  mx__theme->button(button);
		  return;

	 case MX_ARM:
	 case MX_SELECT:
		  mx_dirty(button, true);
		  break;

	 case MX_POINTER_CLICK:
		  mx_select(button, !mx_selected(button));
		  break;

	 case MX_DEFAULTRECT:{
				MX_RECT *rect = mx_defaultrect_data();

				rect->x2 = rect->x1 + mx_text_width(button) + 8;
				rect->y2 = rect->y1 + mx_text_height(button) + 4;
				return;
		  }

	 default:
		  break;
	 }
	 mx_textual_class();
}

MX_BUTTON *mx_obj_button(MX_BUTTON * button, size_t size, MX_OBJ * parent, int theid)
{
	 MXMINSIZE(size, MX_BUTTON);

	 button = (MX_BUTTON *) mx_obj_textual(MXTEXTUAL(button), size, parent, theid);
	 if (button) {
		  MXOBJ(button)->_class = mx_button_class;
		  MXNAMESET(button, "button");

		  mx_armable(button, true);
		  mx_selectable(button, true);
	 }
	 MXINVARIANT(MXOBJ(button));
	 return button;
}

#ifdef DEBUG
#ifdef MX_PLATFORM_DEGFX
#include "degfx/degfx.h"

static void mx__drawtree(MX_OBJ * obj, int *x, int *y)
{
	 char temp[1024];

	 sprintf(temp, "%s[%p]", MXNAME(obj), (void *) obj);
	 if (mx_obj_armed(obj))
		  strcat(temp, " Arm");
	 if (mx_obj_selected(obj))
		  strcat(temp, " Select");
	 if (obj == mx_._pointed)
		  strcat(temp, " Pointed");
	 if (obj == mx_._pointerhold)
		  strcat(temp, " PointerHold");
	 if (obj == mx_._focus)
		  strcat(temp, " Focus");

	 mx_font_draw(0, temp, -1, *x, *y, MXRGB(0, 0, 0), MXRGB(0, 0, 0));
	 *x += 20;
	 *y += mx_font_height(0);
	 obj = obj->_last;
	 while (obj) {
		  mx__drawtree(obj, x, y);
		  obj = obj->_prev;
	 }
	 *x -= 20;
}
#endif
#endif

static void mx__root_class(void)
{
	 MXINVARIANT(OBJ);

	 switch (mx.event) {

	 case MX_EXPOSE:{
				mx__theme->root(&mx_._root);

#ifdef DEBUG
#ifdef MX_PLATFORM_DEGFX
				{
					 int i;
					 int x = mx_x1(&mx_._root);
					 int y = mx_y1(&mx_._root);
					 char temp[1024];

					 sprintf(temp, "Frame rate %i", mx_._framerate);
					 mx_font_draw(0, temp, -1, 0, y, MXRGB(0, 0, 0), MXRGB(0, 0, 0));
					 y += mx_font_height(0);

					 sprintf(temp, "Pointer %i %i %i", mx_._pointer.x, mx_._pointer.y, mx_._pointer.b);
					 mx_font_draw(0, temp, -1, 0, y, MXRGB(0, 0, 0), MXRGB(0, 0, 0));
					 y += mx_font_height(0);

					 mx__drawtree(ROOTOBJ, &x, &y);

					 x = mx_w(&mx_._root) / 2;
					 y = mx_y1(&mx_._root);

					 for (i = 0; i < mx_vector_size(&mx__eventlog); i++) {
						  long len = -1;
						  const char *t = mx_string_text(&mx__eventlog.data[i], &len);

						  mx_font_draw(0, t, len, x, y, MXRGB(0, 0, 0), MXRGB(0, 0, 0));
						  y += mx_font_height(0);
					 }
				}
#endif
#endif
				return;
		  }

	 case MX_THEME_CHANGE:
		  return;

	 default:
		  break;
	 }
	 mx_obj_class();
}

void mx_winborder_class(void)
{
	 MX_WINBORDER *border = (MX_WINBORDER *) mx.obj;
	 MX_WIN *owner = MXOBJ(border)->_win;

	 MXINVARIANT(OBJ);
	 MXINVARIANT(MXOBJ(owner));

	 switch (mx.event) {

	 case MX_DESTRUCT:
		  if (owner)
				owner->border = 0;
		  break;

	 case MX_EXPOSE:
		  mx__theme->winborder(border);
		  return;

	 case MX_ARM:
		  mx_obj_class();
		  mx_wantmove(border, mx_armed(border));
		  return;

	 case MX_POINTER_MOVE:
		  if (mx_armed(border)) {
				const MX_POINTER_INFO *info = mx_pointer_info();

				if ((info->dx) || (info->dy)) {
					 mx_dirty(border, true);
					 mx_move(border, mx_x(border) + info->dx, mx_y(border) + info->dy);
					 mx_dirty(border, true);

					 if (owner) {
						  mx_dirty(owner, true);
						  mx_move(owner, mx_x(owner) + info->dx, mx_y(owner) + info->dy);
						  mx_dirty(owner, true);
					 }
				}
		  }
		  break;

	 case MX_THEME_CHANGE:
		  mx_defaultrect(&border->_close, 0);
		  mx_defaultrect(&border->_resize, 0);
		  mx_defaultrect(border, 0);
		  break;

	 case MX_GEOMETRY:
		  mx_move(&border->_close, mx_w(border) - mx_w(&border->_close) - 1, 1);
		  mx_move(&border->_resize, mx_w(border) - mx_w(&border->_close) - 1, mx_h(border) - mx_h(&border->_close) - 1);
		  break;

	 case MX_DEFAULTRECT:{
				int sh;
				int th = mx_text_height(owner);
				MX_RECT *rect = mx_defaultrect_data();

				mx__theme->textsize("", -1, 0, &sh);

				th = MXMAX(th, mx_h(&border->_close));
				sh = MXMAX(sh, mx_h(&border->_resize));

				if (owner) {
					 const MX_RECT *ownerrect = MXRECT(owner);

					 rect->x1 = ownerrect->x1 - 1;
					 rect->y1 = ownerrect->y1 - th - 3;
					 rect->x2 = ownerrect->x2 + 1;
					 rect->y2 = ownerrect->y2 + sh + 2;
				}
				return;
		  }

	 default:
		  break;
	 }
	 mx_obj_class();
}

void mx_winborder_callback(MX_WIN * win)
{
	 MX_WINBORDER *border = win->border;

	 MXINVARIANT(MXOBJ(win));
	 MXINVARIANT(MXOBJ(border));
	 MXINVARIANT(MXOBJ(&border->_close));
	 MXINVARIANT(MXOBJ(&border->_resize));
	 MXINVARIANT(OBJ);

	 /* Resize window if necessary */
	 if ((OBJ == MXOBJ(&border->_resize)) && (mx.event == MX_POINTER_MOVE) && (mx_armed(&border->_resize))) {
		  const MX_POINTER_INFO *info = mx_pointer_info();

		  if ((info->dx) || (info->dy)) {
				if (win) {
					 mx_win_dirty(win);

					 mx_resize(win, mx_w(win) + info->dx, mx_h(win) + info->dy);
					 mx_geometry(win);

					 mx_win_dirty(win);

				} else {
					 mx_dirty(border, true);
					 mx_resize(border, mx_w(border) + info->dx, mx_h(border) + info->dy);
					 mx_geometry(border);
					 mx_dirty(border, true);
				}

		  }
	 }

	 /* Destroy window if close button is selected */
	 if (mx_selected(&border->_close))
		  mx_delete(win);
}

MX_WINBORDER *mx_winborder(MX_WINBORDER * border, size_t size, MX_WIN * owner, int theid)
{
	 MXINVARIANT(MXOBJ(owner));
	 MXINVARIANT(MXOBJ(owner)->_parent);

	 MXMINSIZE(size, MX_WINBORDER);

	 border = (MX_WINBORDER *) mx_obj(MXOBJ(border), mx_winborder_class, size, MXOBJ(owner)->_parent, theid);
	 if (border) {
		  border->_callback = mx_winborder_callback;
		  MXOBJ(border)->_win = owner;
		  MXNAMESET(border, "winborder");

		  mx_armable(border, true);

		  mx_button(&border->_close, 0, border, MXID_WINCLOSE);
		  MXNAMESET(&border->_close, "winborder_close");

		  mx_button(&border->_resize, 0, border, MXID_WINRESIZE);
		  MXNAMESET(&border->_resize, "winborder_resize");
		  mx_selectable(&border->_resize, false);
		  mx_wantmove(&border->_resize, true);

		  mx_defaultrect(&border->_close, 0);
		  mx_defaultrect(&border->_resize, 0);
	 }
	 MXINVARIANT(MXOBJ(border));
	 return border;
}

void mx_win_dirty(MX_WIN * win)
{
	 MXINVARIANT(MXOBJ(win));

	 mx_dirty(win, true);

	 if (win->border)
		  mx_dirty(win->border, true);
}

void mx_win_class(void)
{
	 MX_WIN *win = (MX_WIN *) mx.obj;

	 MXINVARIANT(OBJ);

	 switch (mx.event) {

	 case MX_DESTRUCT:
		  if ((win->_ismodal) && (win->_parent)) {
				--win->_parent->_modallock;
				mx_win_dirty(win->_parent);
		  }

		  if (win->border)
				mx_delete(win->border);

		  while (win->_last) {
				MX_WIN *ptr = win->_last;

				mx_node_remove(ptr);
				mx_delete(ptr);
		  }

		  mx_node_remove(win);
		  break;

	 case MX_EXPOSE:
		  mx__theme->win(win);
		  return;

	 case MX_TOP:
		  if (win->border) {
				MX_OBJ *parent = OBJ->_parent;

				mx_node_remove(MXOBJ(win->border));
				mx_node_insert(MXOBJ(win->border), parent);

				mx_node_remove(OBJ);
				mx_node_insert(OBJ, parent);
		  }

		  mx_win_dirty(win);
		  break;

	 case MX_ACTIVE:
		  if (win->border)
				mx_dirty(win->border, true);

		  return;

	 case MX_GEOMETRY:
		  if (win->border) {
				mx_defaultrect(win->border, 0);
				mx_geometry(win->border);
		  }
		  return;

	 default:
		  break;
	 }
	 mx_textual_class();
}

void mx_win_handler(MX_WIN * win)
{
	 MXINVARIANT(MXOBJ(win));
	 MXINVARIANT(OBJ);

	 if (mx.event == MX_POINTER_PRESS) {
		  mx_top(win);
		  mx_win_activate(win);
	 }

	 mx_handler_default();

	 if ((win->border) && (win->border->_callback))
		  win->border->_callback(win);
}

MX_WIN *mx_win(MX_WIN * win, size_t size, MX_HANDLER handler, int theid)
{
	 MXMINSIZE(size, MX_WIN);

	 if (!handler)
		  handler = mx_win_handler;

	 win = (MX_WIN *) mx_textual(MXTEXTUAL(win), size, &mx_._root, theid);
	 if (win) {
		  MXOBJ(win)->_class = mx_win_class;
		  MXOBJ(win)->_win = win;
		  win->_handler = handler;
		  MXNAMESET(win, "win");

		  mx_armable(win, true);

		  win->border = mx_winborder(0, 0, win, MXID_WINBORDER);

		  mx_node_remove(MXOBJ(win));
		  mx_node_insert(MXOBJ(win), ROOTOBJ);
	 }

	 MXINVARIANT(MXOBJ(win));
	 return win;
}

void mx_win_child(MX_WIN * win, MX_WIN * target)
{
	 MXINVARIANT(MXOBJ(win));
	 MXINVARIANT(MXOBJ(target));

	 mx_node_remove(win);
	 mx_node_insert(win, target);
}

void mx_win_modal(MX_WIN * win, MX_WIN * target)
{
	 mx_win_child(win, target);

	 MXINVARIANT(MXOBJ(win));
	 MXINVARIANT(MXOBJ(target));
	 MXASSERT(win->_parent == target);

	 if (target) {
		  win->_ismodal = true;
		  ++target->_modallock;

		  mx_win_dirty(target);
	 }
}

const MX_RECT *mx_expose_rect(void)
{
	 MXINVARIANT(OBJ);
	 if (mx.event == MX_EXPOSE)
		  return (const MX_RECT *) mx.data;

	 return 0;
}

typedef struct MX__EXPOSEDATA {
	 MX_OBJ *target;
	 unsigned children;
} MX__EXPOSEDATA;

static MX__EXPOSEDATA mx__exposedata = { 0, false };

unsigned mx_exposing(void)
{
	 MXINVARIANT(OBJ);
	 MXASSERT(mx.event == MX_EXPOSE);

	 return ((mx.event == MX_EXPOSE) && (mx__exposedata.target)) ? false : true;
}

static void mx__expose(MX_OBJ * obj, const MX_RECT * rect)
{
	 const MX_EVENTSTACK prev = mx;

	 if (!MXRECT_VALID(*rect))
		  return;

	 MXASSERT(mx__theme);
	 MXINVARIANT(obj);
	 MXINVARIANT(MXOBJ(obj->_win));

	 /* A (little) dirty hack to make the mx.obj a derived class of MX_OBJ
	    which makes the nice macros usable even for mx.obj.  The cast is safe
	    becasue MX_DERIVED is only a wrapper of MX_OBJ and has (must have!) no 
	    data of its own */
	 mx.obj = (MX_DERIVED *) obj;
	 mx.event = MX_EXPOSE;
	 mx.data = rect;
	 mx._answer = 0;

	 if (mx__exposedata.target) {
		  static MX_RECT dummy = { -1, -1, -2, -2 };

		  if (mx__exposedata.target == obj)
				mx_platform_dirty(rect);

		  mx_._clip = dummy;
		  mx_platform_clip(&dummy);
		  OBJ->_class();

	 } else {
		  mx_._clip = *rect;

		  if (mx_platform_clip(rect))
				OBJ->_class();
	 }
	 mx = prev;
}

static void mx__drawrecurse(MX_OBJ * obj, MX_OBJ * parent, const MX_RECT * rect)
{
	 MXINVARIANT(parent);

	 if (!MXRECT_VALID(*rect))
		  return;

	 while (obj) {
		  MX_RECT subrect;

		  MXINVARIANT(obj);

		  if (MXRECTS_OVERLAP(*rect, *MXRECT(obj))) {
				MXRECT_INTERSECT(*rect, *MXRECT(obj), subrect);

				if ((mx__exposedata.target == obj) && (mx__exposedata.children)) {
					 mx__expose(obj, &subrect);
					 return;

				} else
					 mx__drawrecurse(obj->_last, obj, &subrect);

				MX__TOP_RECTS(*rect, *MXRECT(obj), subrect);
				mx__drawrecurse(obj->_prev, parent, &subrect);

				MX__LEFT_RECTS(*rect, *MXRECT(obj), subrect);
				mx__drawrecurse(obj->_prev, parent, &subrect);

				MX__RIGHT_RECTS(*rect, *MXRECT(obj), subrect);
				mx__drawrecurse(obj->_prev, parent, &subrect);

				MX__BOT_RECTS(*rect, *MXRECT(obj), subrect);
				mx__drawrecurse(obj->_prev, parent, &subrect);
				return;
		  }
		  obj = obj->_prev;
	 }
	 mx__expose(parent, rect);
}

void mx__gui_redraw(const MX_RECT * rect)
{
	 MX__EXPOSEDATA old = mx__exposedata;

#ifndef NDEBUG
	 unsigned oldexposing = mx_._exposing;

	 mx_._exposing = true;
#endif

	 MXASSERT(MXRECT_VALID(*rect));

	 MXINVARIANT(ROOTOBJ);

	 mx__exposedata.target = 0;
	 mx__exposedata.children = false;
	 mx__drawrecurse(ROOTOBJ->_last, ROOTOBJ, rect);
	 mx__exposedata = old;

#ifndef NDEBUG
	 mx_._exposing = oldexposing;
#endif
}

void mx_obj_dirty(MX_OBJ * obj, const unsigned children)
{
	 MX__EXPOSEDATA old = mx__exposedata;

#ifndef NDEBUG
	 unsigned oldexposing = mx_._exposing;

	 mx_._exposing = true;
#endif

	 if (!obj)
		  obj = OBJ;

	 MXINVARIANT(obj);
	 MXINVARIANT(ROOTOBJ);

	 mx__exposedata.target = obj;
	 mx__exposedata.children = children;
	 mx__drawrecurse(ROOTOBJ->_last, ROOTOBJ, MXRECT(obj));
	 mx__exposedata = old;

#ifndef NDEBUG
	 mx_._exposing = oldexposing;
#endif
}

void mx_expose_background(const MX_RECT * rect)
{
	 MX_RECT area;

	 MXINVARIANT(OBJ);
	 MXASSERT(mx.event == MX_EXPOSE);
	 MXASSERT(OBJ != ROOTOBJ);
	 MXASSERT(mx_._exposing);

	 if (mx.event != MX_EXPOSE)
		  return;

	 if (!rect)
		  rect = mx_expose_rect();

	 MXRECT_INTERSECT(*mx_expose_rect(), *rect, area);

	 if (!MXRECT_VALID(area))
		  return;

	 if (OBJ->_parent) {
		  MX_RECT oldclip = mx_._clip;

		  MXINVARIANT(OBJ->_parent);

		  mx__drawrecurse(OBJ->_prev, OBJ->_parent, &area);
		  mx_platform_clip(&oldclip);

	 } else {
		  MXASSERT(0);
	 }
}

static void mx__pointer_event(MX_EVENT event)
{
	 MX_OBJ *target = (mx_._pointerhold) ? mx_._pointerhold : mx_._pointed;

	 if (!target)
		  return;

	 if ((event == MX_POINTER_MOVE) && (!target->_wantmove))
		  return;

	 mx_obj_event(target, event, 0);
}

static MX_OBJ *mx__pointed(MX_OBJ * obj)
{
	 MX_OBJ *child;

	 MXINVARIANT(obj);

	 if (!MXRECT_CONTAINS(*MXRECT(obj), mx_._pointer.x, mx_._pointer.y))
		  return 0;

	 child = obj->_last;

	 while (child) {
		  if (MXRECT_CONTAINS(*MXRECT(child), mx_._pointer.x, mx_._pointer.y))
				return mx__pointed(child);

		  child = child->_prev;
	 }
	 return obj;
}

static MX_OBJ *mx__pointer_refuse(MX_OBJ * obj)
{
	 MX_OBJ *ptr;

	 if (!obj)
		  return 0;

	 MXINVARIANT(obj);

	 if (mx_obj_event(obj, MX_POINTER_WANT, 0) == 0)
		  return obj;

	 ptr = obj->_prev;
	 while (ptr) {
		  if (MXRECT_CONTAINS(*MXRECT(ptr), mx_._pointer.x, mx_._pointer.y))
				return mx__pointer_refuse(mx__pointed(ptr));

		  ptr = ptr->_prev;
	 }

	 return mx__pointer_refuse(obj->_parent);
}

unsigned mx_start(void)
{
	 if (MXCLASS(&mx_._root) != mx__root_class) {
		  int i = 0;
		  MX_PLATFORM_RESOLUTION *r = 0;
		  MX_PLATFORM_DEPTH *c = 0;
		  MX_PLATFORM_DRIVER *d = 0;
		  MX_PLATFORM_THEME *t = 0;

		  memset(&mx_, 0, sizeof(mx_));
		  mx__theme = 0;

		  mx_obj(ROOTOBJ, mx__root_class, sizeof(mx_._root), 0, 0);
		  ROOTOBJ->_win = &mx_._root;
		  MXNAMESET(&mx_._root, "root");

		  if (!mx_platform_start(0, 0, 0, 0))
				return false;

		  mx_platform_modes(&d, &r, &c, &t);

		  MXASSERT(t);
		  do {
				mx__theme = &t->theme[i++];
		  } while ((mx__theme) && (!mx__theme->start()));

		  if (!mx__theme)
				return false;

#ifndef NDEBUG
		  mx_._framenext = clock() + CLOCKS_PER_SEC;
#endif
	 }
	 return true;
}

int mx_execute(void)
{
	 if (!mx_start())
		  return EXIT_FAILURE;

	 mx_._running = true;
	 while (mx_._running) {
		  int px, py, pb;
		  MX_KEY_INFO key;
      /*
		  const MX_RECT *rootrect = MXRECT(&mx_._root);
		  const MX_RECT gfxrect = *mx_platform_rect();
      */
      MX_RECT *rootrect;
      MX_RECT gfxrect;

      /* FIX ME: rootrect not const, avoid qualifier mismatch */
      rootrect = (MX_RECT *) MXRECT(&mx_._root);
      gfxrect = *mx_platform_rect();

		  MXINVARIANT(ROOTOBJ);

		  mx_lock(&mx_._root);

		  if (!mx_platform_poll())
				mx_delete(&mx_._root);

		  if (!ROOTOBJ->_last)
				mx_delete(&mx_._root);

		  if ((gfxrect.x1 != rootrect->x1) || (gfxrect.y1 != rootrect->y1) || (gfxrect.x2 != rootrect->x2)
				|| (gfxrect.y2 != rootrect->y2)) {
				mx_place(&mx_._root, &gfxrect);
				mx_platform_dirty(&gfxrect);
#ifdef DEBUG
#ifdef MX_PLATFORM_DEGFX
				mx__eventlogsize = mx_h(&mx_._root) / mx_font_height(0);
#endif
#endif
		  }

		  if (mx_platform_pointer(&px, &py, &pb)) {
				MX_OBJ *pointed = mx_._pointed;
				const unsigned moved = ((px != mx_._pointer.x) || (py != mx_._pointer.y)) ? true : false;
				const unsigned pressed = ((pb) && (!mx_._pointer.b)) ? true : false;
				const unsigned release = ((!pb) && (mx_._pointer.b)) ? true : false;

				if ((moved) || (pressed) || (release)) {
					 mx_._pointer.dx = px - mx_._pointer.x;
					 mx_._pointer.dy = py - mx_._pointer.y;
					 mx_._pointer.x = px;
					 mx_._pointer.y = py;
					 mx_._pointer.b = pb;
				}

				if (moved)
					 mx__pointer_event(MX_POINTER_MOVE);

				if ((!pointed) || (moved)) {
					 pointed = mx__pointed(ROOTOBJ);

					 if ((pointed) && (pointed != mx_._pointed) && (!mx_._pointerhold))
						  pointed = mx__pointer_refuse(pointed);
				}

				if ((pointed != mx_._pointed) && (!mx_._pointerhold)) {
					 mx__pointer_event(MX_POINTER_LEAVE);

					 mx_._pointed = pointed;
					 mx__pointer_event(MX_POINTER_ENTER);
				}

				if (pressed)
					 mx__pointer_event(MX_POINTER_PRESS);

				if (release)
					 mx__pointer_event(MX_POINTER_RELEASE);
		  }

		  if (mx_platform_key(&key.code, &key.ascii)) {
				if (mx_._focus) {
					 const void *ret = mx_obj_event(mx_._focus, MX_KEY, &key);

					 if ((ret == &key) && (mx_._focus) && (mx_._focus->_win))
						  mx_obj_event(MXOBJ(mx_._focus->_win), MX_KEY_UNUSED, &key);
				}

				mx_delete(&mx_._root);
		  }
#ifdef DEBUG
#ifdef MX_PLATFORM_DEGFX
		  mx_obj_dirty(ROOTOBJ, false);

		  ++mx_._framecount;

		  if (clock() > mx_._framenext) {
				mx_._framenext = clock() + CLOCKS_PER_SEC;

				mx_._framerate = mx_._framecount;
				mx_._framecount = 0;
		  }
#endif
#endif
		  if (mx_unlock(&mx_._root))
				mx_._running = false;
	 }

	 mx__theme->stop();
	 mx_platform_stop();

	 memset(&mx_, 0, sizeof(mx_));
	 mx__theme = 0;

#ifdef DEBUG
#ifdef MX_PLATFORM_DEGFX
	 {
		  int i;

		  for (i = 0; i < mx_vector_size(&mx__eventlog); i++)
				mx_string_free(&mx__eventlog.data[i]);

		  mx_vector_free(&mx__eventlog);
	 }
#endif
#endif

	 return EXIT_SUCCESS;
}

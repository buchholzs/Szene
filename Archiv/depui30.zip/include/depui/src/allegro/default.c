/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#ifdef MX_PLATFORM_ALLEGRO
#if defined(MX_LIB) || defined(MX_THEME_DEFAULT)
#ifndef MX_HAVE_THEME_DEFAULT
#define MX_HAVE_THEME_DEFAULT
#define MX_THEME_EXISTS

#include "depui/depui.h"
#include <allegro.h>

static void mx__allegro_textsize(const char *text, int len, int *tw, int *th);
static void mx__allegro_drawblock(const FONT * font, const char *text, int len, int x, int y, const int fore);
static void mx__allegro_box(BITMAP * bitmap, int x1, int y1, int x2, int y2, int width, int light, int dark);
static void mx__allegro_frame(BITMAP * bitmap, int x1, int y1, int x2, int y2, int width, int light, int dark, int fill);

static unsigned mx_theme_default_start(void)
{
	 return true;
}

static void mx_theme_default_stop(void)
{
}

static void mx_theme_default_event(void)
{
	 mx__event_default();
}

static void mx_theme_default_obj(MX_OBJ * obj)
{
	 if (mx_exposing()) {
		  const MX_RECT *objrect = MXRECT(obj);

		  rectfill(screen, objrect->x1, objrect->y1, objrect->x2, objrect->y2, makecol(255, 255, 255));
	 }
}

static void mx_theme_default_vslider(MX_SLIDER * slider)
{
	 if (mx_exposing()) {
		  const MX_RECT *objrect = MXRECT(slider);
		  int fill = makecol(192, 192, 192);
		  int edge1 = makecol(64, 64, 64);
		  int edge2 = makecol(164, 164, 164);

		  mx__allegro_frame(screen, objrect->x1, objrect->y1, objrect->x2, objrect->y2, 1, makecol(64, 64, 64), makecol(64, 64, 64),
								  makecol(128, 128, 128));

		  if (mx_armed(slider))
				fill = makecol(255, 255, 255);

		  mx__allegro_frame(screen, objrect->x1 + 1, objrect->y1 + slider->_upper, objrect->x2 - 1, objrect->y1 + slider->_lower, 1,
								  edge2, edge1, fill);
	 }
}

static void mx_theme_default_hslider(MX_SLIDER * slider)
{
	 if (mx_exposing()) {
		  const MX_RECT *objrect = MXRECT(slider);
		  int fill = makecol(192, 192, 192);
		  int edge1 = makecol(64, 64, 64);
		  int edge2 = makecol(164, 164, 164);

		  mx__allegro_frame(screen, objrect->x1, objrect->y1, objrect->x2, objrect->y2, 1, makecol(64, 64, 64), makecol(64, 64, 64),
								  makecol(128, 128, 128));

		  if (mx_armed(slider))
				fill = makecol(255, 255, 255);

		  mx__allegro_frame(screen, objrect->x1 + slider->_upper, objrect->y1 + 1, objrect->x1 + slider->_lower, objrect->y2 - 1, 1,
								  edge2, edge1, fill);
	 }
}

static void mx_theme_default_textual_draw(const MX_TEXTUAL * textual, int x1, int y1, int x2, int y2, int offsetx, int offsety)
{
	 long len = 0;
	 const char *text = mx_string_text(&textual->_text, &len);
	 int fore = makecol(0, 0, 0);
	 int back = makecol(255, 255, 255);

	 if (mx_selected(textual))
		  back = makecol(164, 164, 215);

	 if (mx_disabled(textual))
		  fore = makecol(127, 127, 127);

	 if ((mx_is_armable(textual)) && (mx_armed(textual)))
		  back = makecol(127, 127, 127);

	 rectfill(screen, x1, y1, x2, y2, back);

	 if (text) {
		  mx__textual_align(textual, &x1, &y1, x2, y2);

		  mx__allegro_drawblock(font, text, len, x1 + offsetx, y1 + offsety, fore);
	 }
}

static void mx_theme_default_textual(MX_TEXTUAL * text)
{
	 if (mx_exposing()) {
		  const MX_RECT *objrect = MXRECT(text);

		  mx_theme_default_textual_draw(text, objrect->x1, objrect->y1, objrect->x2, objrect->y2, 0, 0);
	 }
}

static void mx_theme_default_scrollcorner(MX_OBJ * scrollcorner)
{
	 if (mx_exposing()) {
		  const MX_RECT *objrect = MXRECT(scrollcorner);

		  rectfill(screen, objrect->x1, objrect->y1, objrect->x2, objrect->y2, makecol(192, 192, 192));
	 }
}

static void mx_theme_default_scrolltitle(MX_TEXTUAL * scrolltitle)
{
	 if (mx_exposing()) {
		  long len = 0;
		  const char *text = mx_textual_text(scrolltitle, &len);
		  const MX_RECT *objrect = MXRECT(scrolltitle);
		  int x1 = objrect->x1;
		  int y1 = objrect->y1;
		  int x2 = objrect->x2;
		  int y2 = objrect->y2;

		  rectfill(screen, x1, y1, x2, y2, makecol(192, 192, 192));

		  if (text) {
				mx__textual_align(scrolltitle, &x1, &y1, x2, y2);
				mx__allegro_drawblock(font, text, len, x1, y1, makecol(0, 0, 0));
		  }
	 }
}

static void mx_theme_default_scroll(MX_SCROLL * scroll)
{
	 if (mx_exposing()) {
		  const MX_RECT *objrect = MXRECT(scroll);

		  rectfill(screen, objrect->x1, objrect->y1, objrect->x2, objrect->y2, makecol(255, 255, 255));
	 }
}

static void mx_theme_default_button(MX_BUTTON * button)
{
	 if (mx_exposing()) {
		  const MX_RECT *objrect = MXRECT(button);
		  int offset = 0;

		  if (mx_selected(button))
				offset = 1;

		  if (mx_armed(button))
				mx__allegro_box(screen, objrect->x1, objrect->y1, objrect->x2, objrect->y2, 1, makecol(64, 64, 64), makecol(64, 64, 64));
		  else if (mx_selected(button))
				mx__allegro_box(screen, objrect->x1, objrect->y1, objrect->x2, objrect->y2, 1, makecol(64, 64, 64),
									 makecol(255, 255, 255));
		  else
				mx__allegro_box(screen, objrect->x1, objrect->y1, objrect->x2, objrect->y2, 1, makecol(185, 185, 185),
									 makecol(64, 64, 64));

		  mx_theme_default_textual_draw(MXTEXTUAL(button), objrect->x1 + 1, objrect->y1 + 1, objrect->x2 - 1, objrect->y2 - 1,
												  1 + offset, 1 + offset);
	 }
}

void mx_theme_default_listelem(MX_LISTELEM * listelem)
{
	 if (mx_exposing()) {
		  const MX_RECT *objrect = MXRECT(listelem);

		  mx_theme_default_textual_draw(MXTEXTUAL(listelem), objrect->x1, objrect->y1, objrect->x2, objrect->y2, 0, 0);
	 }
}

static void mx_theme_default_root(MX_WIN * root)
{
	 if (mx_exposing()) {
		  const MX_RECT *objrect = MXRECT(root);

		  rectfill(screen, objrect->x1, objrect->y1, objrect->x2, objrect->y2, makecol(192, 192, 192));
	 }
}

static void mx_theme_default_winborder(MX_WINBORDER * border)
{
	 if (mx_exposing()) {
		  MX_WIN *owner = MXOBJ(border)->_win;
		  const MX_RECT *objrect = MXRECT(border);
		  int x1 = objrect->x1;
		  int y1 = objrect->y1;
		  const int x2 = objrect->x2;
		  const int y2 = objrect->y2;
		  int fill = makecol(192, 192, 192);

		  if (mx_win_active(owner))
				fill = makecol(164, 164, 215);

		  mx__allegro_box(screen, x1, y1, x2, y2, 1, makecol(64, 64, 64), makecol(64, 64, 64));

		  rectfill(screen, x1 + 1, y1 + 1, x2 - 1, mx_y1(owner) - 2, fill);
		  hline(screen, x1 + 1, mx_y1(owner) - 1, x2 - 1, makecol(192, 192, 192));

		  hline(screen, x1 + 1, mx_y2(owner) + 1, x2 - 1, makecol(192, 192, 192));
		  rectfill(screen, x1 + 1, mx_y2(owner) + 2, x2 - 1, y2 - 1, fill);

		  if (owner) {
				long len = 0;
				const char *text = mx_text(owner, &len);

				if (text) {
					 mx__textual_align(MXTEXTUAL(owner), &x1, &y1, x2, y2);

					 mx__allegro_drawblock(font, text, len, x1 + 2, y1 + 2, makecol(0, 0, 0));
				}
		  }
	 }
}

static void mx_theme_default_win(MX_WIN * win)
{
	 if (mx_exposing()) {
		  const MX_RECT *objrect = MXRECT(win);

		  rectfill(screen, objrect->x1, objrect->y1, objrect->x2, objrect->y2, makecol(192, 192, 192));
	 }
}

static MX_THEME mx_theme_default = {
	 mx_theme_default_start,
	 mx_theme_default_stop,
	 mx_theme_default_event,
	 mx_theme_default_obj,
	 mx_theme_default_vslider,
	 mx_theme_default_hslider,
	 mx_theme_default_textual,
	 mx_theme_default_scrollcorner,
	 mx_theme_default_scrolltitle,
	 mx_theme_default_scroll,
	 mx_theme_default_button,
	 mx_theme_default_listelem,
	 mx_theme_default_root,
	 mx_theme_default_winborder,
	 mx_theme_default_win,
	 mx__allegro_textsize
};

#endif
#endif
#endif

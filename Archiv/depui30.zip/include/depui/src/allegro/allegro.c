/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#if defined(MX_LIB) || defined(MX_PLATFORM_ALLEGRO)
#ifndef MX_HAVE_PLATFORM_ALLEGRO
#define MX_HAVE_PLATFORM_ALLEGRO
#define MX_PLATFORM_EXISTS

#define MX_DETK_DRS

#include "depui/depui.h"
#include "allegro.h"

void mx__allegro_decorate(BITMAP * src, BITMAP * dest, int x, int y, int x1, int y1, int x2, int y2)
{
	 int i, r, b;
	 int c;
	 const int w = src->w;
	 const int h = src->h;

	 if (x == -1)
		  x = (w + 1) / 2;
	 if (y == -1)
		  y = (h + 1) / 2;

	 r = x2 - w + x;
	 b = y2 - h + y;

	 blit(src, dest, 0, 0, x1, y1, x, y);
	 blit(src, dest, x, 0, r + 1, y1, w - x, y);

	 blit(src, dest, 0, y, x1, b + 1, x, h - y);
	 blit(src, dest, x, y, r + 1, b + 1, w - x, h - y);

	 if (r > x1 + x) {
		  for (i = 0; i < y - 1; i++) {
				c = getpixel(src, x - 1, i);
				hline(dest, x1 + x, y1 + i, r, c);
		  }

		  for (i = y; i < h; i++) {
				c = getpixel(src, x - 1, i);
				hline(dest, x1 + x, y2 - h + i + 1, r, c);
		  }
	 }

	 if (b > y1 + y) {
		  for (i = 0; i < x - 1; i++) {
				c = getpixel(src, i, y - 1);
				vline(dest, x1 + i, y1 + y, b, c);
		  }

		  for (i = x; i < w; i++) {
				c = getpixel(src, i, y - 1);
				vline(dest, x2 - w + i + 1, y1 + y, b, c);
		  }
	 }

	 if ((r > x1 + x) && (b > y1 + y)) {
		  c = getpixel(src, x - 1, y - 1);
		  rectfill(dest, x1 + x - 1, y1 + y - 1, r, b, c);
	 }
}

void mx__allegro_drawblock(const FONT * font, const char *text, int len, int x, int y, const int fore)
{
	 int n = 0;
	 const int lineheight = text_height(font) + 1;

	 if (len < 0)
		  len = 0xffff;

	 while ((text) && (*text) && (n < len)) {
		  int i = 0;
		  char *p = (char *) text;
		  char temp;

		  while ((*p) && (*p != '\r') && (*p != '\n') && (n < len)) {
				++p;
				++i;
				++n;
		  }

		  temp = *p;
		  *p = 0;
		  textout_ex(screen, font, text, x, y + 1, fore, -1);
		  *p = temp;

		  if (*p == '\r') {
				++p;
				++n;
		  }

		  if (*p == '\n') {
				++p;
				++n;
		  }

		  y += lineheight;
		  text = p;
	 }
}

void mx__allegro_textsize(const char *text, int len, int *tw, int *th)
{
	 int n = 0;
	 const int lineheight = text_height(font) + 1;

	 if (len < 0)
		  len = 0xffff;

	 if (tw)
		  *tw = 0;

	 if (th)
		  *th = lineheight;

	 while ((text) && (*text) && (n < len)) {
		  int sw, i = 0;
		  char *p = (char *) text;
		  unsigned newline = false;
		  char temp;

		  while ((*p) && (*p != '\r') && (*p != '\n') && (n < len)) {
				++p;
				++i;
				++n;
		  }

		  temp = *p;
		  *p = 0;
		  sw = text_length(font, text);
		  *p = temp;

		  if ((tw) && (*tw < sw))
				*tw = sw;

		  if (*p == '\r') {
				++p;
				++n;
				newline = true;
		  }

		  if (*p == '\n') {
				++p;
				++n;
				newline = true;
		  }

		  if ((newline) && (th))
				*th += lineheight;

		  text = p;
	 }
}

void mx__allegro_box(BITMAP * bitmap, int x1, int y1, int x2, int y2, int width, int light, int dark)
{
	 int i;

	 if (width < 0) {
		  int temp = light;

		  light = dark;
		  dark = temp;

		  width *= -1;
	 }

	 for (i = 0; i < width; i++) {
		  vline(bitmap, x1, y1, y2, light);
		  hline(bitmap, x1 + 1, y1, x2, light);

		  vline(bitmap, x2, y1 + 1, y2, dark);
		  hline(bitmap, x1 + 1, y2, x2 - 1, dark);

		  x1++, y1++, x2--, y2--;
	 }
}

void mx__allegro_frame(BITMAP * bitmap, int x1, int y1, int x2, int y2, int width, int light, int dark, int fill)
{
	 mx__allegro_box(bitmap, x1, y1, x2, y2, width, light, dark);
	 rectfill(bitmap, x1 + abs(width), y1 + abs(width), x2 - abs(width), y2 - abs(width), fill);
}

static MX_PLATFORM_RESOLUTION mx__allegro_resolutions[] = {
	 {320, 200, "320 x 200"},
	 {640, 480, "640 x 480"},
	 {800, 600, "800 x 600"},
	 {1024, 768, "1024 x 768"},
	 {1280, 1024, "1280 x 1024"},
	 {0, 0, 0}
};

static MX_PLATFORM_DEPTH mx__allegro_depths[] = {
	 {8, "8"},
	 {15, "15"},
	 {16, "16"},
	 {24, "24"},
	 {32, "32"},
	 {0, 0}
};

static int mx___allegro_drivers[] = {
	 GFX_AUTODETECT,
	 GFX_AUTODETECT_FULLSCREEN,
	 GFX_AUTODETECT_WINDOWED
};

struct MX_PLATFORM_DRIVER mx__allegro_drivers[] = {
	 {&mx___allegro_drivers[0], "auto"},
	 {&mx___allegro_drivers[1], "fullscreen"},
	 {&mx___allegro_drivers[2], "windowed"},
	 {0, 0}
};

struct MX_PLATFORM_THEME mx__allegro_themes[] = {
#ifdef MX_HAVE_THEME_DEFAULT
	 {&mx_theme_default, "Default"},
#endif
#ifdef MX_HAVE_THEME_WIN95
	 {&mx_theme_win95, "Win95"},
#endif
#ifdef MX_HAVE_THEME_MONO
	 {&mx_theme_mono, "Monochrome"},
#endif
#ifdef MX_HAVE_THEME_ROUNDED
	 {&mx_theme_rounded, "Rounded"},
#endif
	 {0, 0}
};

void mx_platform_modes(MX_PLATFORM_DRIVER * d[], MX_PLATFORM_RESOLUTION * r[], MX_PLATFORM_DEPTH * c[], MX_PLATFORM_THEME * t[])
{
	 *d = mx__allegro_drivers;
	 *r = mx__allegro_resolutions;
	 *c = mx__allegro_depths;
	 *t = mx__allegro_themes;
}

static int mx__allegro_started = 0;

unsigned mx_platform_start(int w, int h, int c, void *driver)
{
	 int card = GFX_AUTODETECT;
	 int oldw = 640, oldh = 480, oldc = 16;

	 if (driver)
		  card = *(int *) driver;

	 if (!mx__allegro_started) {
		  if (allegro_init() != 0)
				return false;

		  install_keyboard();
		  install_timer();
		  install_mouse();

		  mx__allegro_started = 1;
	 } else {
		  oldw = SCREEN_W;
		  oldh = SCREEN_H;
		  oldc = get_color_depth();

		  show_mouse(NULL);
	 }

	 if (w == 0)
		  w = 640;
	 if (h == 0)
		  h = 480;
	 if (c == 0)
		  c = 16;

	 set_color_depth(c);
	 if (set_gfx_mode(card, w, h, 0, 0) != 0) {

		  set_color_depth(oldc);
		  if (set_gfx_mode(GFX_AUTODETECT, oldw, oldh, 0, 0) != 0)
				return false;
	 }

	 mx_drs_area(w - 1, h - 1);

	 show_mouse(screen);

	 return true;
}

void mx_platform_stop(void)
{
	 allegro_exit();
}

unsigned mx_platform_clip(const MX_RECT * r)
{
	 set_clip_rect(screen, r->x1, r->y1, r->x2, r->y2);
	 return true;
}

const MX_RECT *mx_platform_rect(void)
{
	 static MX_RECT rect;

	 rect.x1 = 0;
	 rect.y1 = 0;
	 rect.x2 = SCREEN_W;
	 rect.y2 = SCREEN_H;

	 return &rect;
}

unsigned mx_platform_pointer(int *px, int *py, int *pb)
{
	 *px = mouse_x;
	 *py = mouse_y;
	 *pb = mouse_b;

	 return true;
}

unsigned mx_platform_key(int *scan, long *ascii)
{
	 int val;

	 if (!keypressed())
		  return false;

	 val = readkey();
	 *scan = (val >> 8) & 0xff;
	 *ascii = scancode_to_ascii(*scan);

	 return true;
}

static void _flush(MX_RECT * rect)
{
	 scare_mouse();
	 acquire_screen();

	 mx__gui_redraw(rect);

	 unscare_mouse();
	 release_screen();
}

unsigned mx_platform_poll(void)
{
	 mx_drs_update(_flush);

	 poll_mouse();
	 poll_keyboard();

	 return true;
}

void mx_platform_dirty(const MX_RECT * rect)
{
	 mx_drs_dirty(rect, true);
}

int main(int argc, char *argv[])
{
	 return mx_guimain(argc, argv);
}
END_OF_MAIN();

#endif
#endif

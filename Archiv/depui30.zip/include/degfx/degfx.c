/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

/* The core DEGFX files */
#include "degfx/src/core.c"
#include "degfx/src/font.c"
#include "degfx/src/bitmap.c"

/* Figure out which font to use */
#ifdef MX_FONT_ALL
#define MX_FONT_8X8
#define MX_FONT_8X14
#define MX_FONT_8X16
#endif

#ifdef MX_FONT_8X8
#define MX_DEGFX_FONT8X8
#endif

#ifdef MX_FONT_8X14
#define MX_DEGFX_FONT8X14
#endif

#ifdef MX_FONT_8X16
#define MX_DEGFX_FONT8X16
#endif

/* Bring in the optional DEGFX files */
#include "degfx/src/font8x8.c"
#include "degfx/src/font8x16.c"
#include "degfx/src/font8x14.c"
#include "degfx/src/fontdraw.c"
#include "degfx/src/loadfont.c"
#include "degfx/src/loadtga.c"
#include "degfx/src/loadpcx.c"
#include "degfx/src/loadgif.c"
#include "degfx/src/bitdraw.c"
#include "degfx/src/bitline.c"
#include "degfx/src/bitpixel.c"
#include "degfx/src/decorate.c"
#include "degfx/src/fgetw.c"

/* Figure out which drivers to include -------------------------------------*/
#ifdef MX_DRIVER_ALL
#define MX_DRIVER_FULLSCREEN
#define MX_DRIVER_WINDOWED
#define MX_DRIVER_VGA
#define MX_DRIVER_13H
#endif

#ifdef MX_DRIVER_FULLSCREEN
#define MX_DEGFX_DJGPP_VESA
#define MX_DEGFX_WIN32_GDI
#define MX_DEGFX_TURBOC_VGA
#define MX_DEGFX_LINUX_SVGALIB
#define MX_DEGFX_QDOS_GFXLIB
#define MX_HAVE_DRIVER_FULLSCREEN
#define MX_DRIVER_CHOSEN
#endif

#ifdef MX_DRIVER_WINDOWED
#define MX_DEGFX_DJGPP_VESA
#define MX_DEGFX_WIN32_GDI
#define MX_DEGFX_TURBOC_VGA
#define MX_DEGFX_LINUX_SVGALIB
#define MX_DEGFX_QDOS_GFXLIB
#define MX_HAVE_DRIVER_WINDOWED
#define MX_DRIVER_CHOSEN
#endif

#ifdef MX_DRIVER_VGA
#define MX_DEGFX_DJGPP_VGA
#define MX_DEGFX_WIN32_GDI
#define MX_DEGFX_TURBOC_VGA
#define MX_DEGFX_LINUX_SVGALIB
#define MX_DEGFX_QDOS_GFXLIB
#define MX_HAVE_DRIVER_VGA
#define MX_DRIVER_CHOSEN
#endif

#ifdef MX_DRIVER_13H
#define MX_DEGFX_DJGPP_13H
#define MX_DEGFX_WIN32_GDI
#define MX_DEGFX_TURBOC_VGA
#define MX_DEGFX_LINUX_SVGALIB
#define MX_DEGFX_QDOS_GFXLIB
#define MX_HAVE_DRIVER_13H
#define MX_DRIVER_CHOSEN
#endif

/* No driver has been chosen, set the default driver */
#ifndef MX_DRIVER_CHOSEN
#define MX_DEGFX_DJGPP_VESA
#define MX_DEGFX_WIN32_GDI
#define MX_DEGFX_TURBOC_VGA
#define MX_DEGFX_LINUX_SVGALIB
#define MX_DEGFX_QDOS_GFXLIB
#endif

/* Now bring in the drivers ------------------------------------------------*/
#include "degfx/src/djgpp/djvesa.c"
#include "degfx/src/djgpp/djvga.c"
#include "degfx/src/djgpp/dj13h.c"
#include "degfx/src/win32/wingdi.c"
#include "degfx/src/dos16/turbovga.c"
#include "degfx/src/linux/svgalib.c"
/*#include "degfx/src/qdos/gfxlib.c"*/

/* Check to see that we actually included at least one driver */
#ifndef MX_DRIVER_EXISTS
#error Sorry no suitable driver could be found
#endif

/* Bring in stuff we need from the DETK library */
#define MX_DETK_RECTATOM
#define MX_DETK_UTF8
#include "detk/detk.c"

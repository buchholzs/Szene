/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#if defined(__MSDOS__) && defined(__TURBOC__)
#if defined(MX_LIB) || defined(MX_DEGFX_TURBOC_VGA)
#ifndef MX_HAVE_DEGFX_TURBOC_VGA
#define MX_HAVE_DEGFX_TURBOC_VGA
#define MX_DRIVER_EXISTS

#define MX_DETK_DRS

#include "degfx/degfx.h"
#include <dos.h>
#include <conio.h>
#include <assert.h>
#include <graphics.h>

/* Mouse variables */
static unsigned mx__turboc_mousevalid = false;
static int mx__turboc_mousex = 0;	/* internal position, in mickeys */
static int mx__turboc_mousey = 0;

/* Scratch row for RGB888 to 4 bit color conversion */
static unsigned char mx__turboc_scratch[480];

static unsigned mx__turboc_start(MX_GFX_ARGS * args)
{
	 union REGS r;

	 /* request auto detection */
	 int gdriver = DETECT, gmode, errorcode;
	 int midx, midy;

	 /* initialize graphics and local variables */
	 initgraph(&gdriver, &gmode, "");

	 /* read result of initialization */
	 errorcode = graphresult();
	 if (errorcode != grOk) {
		  printf("Graphics error: %s\n", grapherrormsg(errorcode));
		  printf("Press any key to halt:");
		  getch();
		  exit(1);					  /* terminate with an error code */
	 }

	 /* Reset the mouse driver */
	 r.x.ax = 0x0000;
	 int86(0x33, &r, &r);
	 if (r.x.ax)
		  mx__turboc_mousevalid = true;
	 else
		  mx__turboc_mousevalid = false;

	 /* Inform the user of the results */
	 args->w = 640;
	 args->h = 480;
	 args->c = 4;
	 args->title = "turboc_vga";
	 args->pointer = false;

	 mx_drs_area(args->w - 1, args->h - 1);

	 return true;
}

static void mx__turboc_stop(void)
{
	 closegraph();
}

static void mx__turboc__flush(const MX_RECT * rect, const MX_PIXEL * array, const int stride)
{
	 int x, y;

	 /* Push the buffer to the visible screen */
	 y = rect->y1;
	 while (y <= rect->y2) {

		  /* Convert the line to 4 bit color in some temp space */
		  const MX_PIXEL *src = array;
		  unsigned char *ptr = mx__turboc_scratch;

		  x = rect->x1;
		  while (x <= rect->x2) {
				const unsigned int r = MXR(*src);
				const unsigned int g = MXG(*src);
				const unsigned int b = MXB(*src);

				*ptr = 0;
				if (r + b + g > 384)
					 *ptr |= 8;
				if (-r + b + g > 127)
					 *ptr |= 4;
				if (r - b + g > 127)
					 *ptr |= 2;
				if (r + b - g > 127)
					 *ptr |= 1;

				++src;
				++ptr;
				++x;
		  }

		  ptr = mx__turboc_scratch;

		  x = rect->x1;
		  while (x <= rect->x2) {
				putpixel(x, y, *ptr);
				++ptr;
				++x;
		  }

		  /* Next row to flush */
		  array += stride;
		  ++y;
	 }
}

static void mx__turboc_flush(MX_RECT * rect)
{
	 mx__gfx_flush(mx__turboc__flush, rect);
}

static unsigned mx__turboc_poll(void)
{
	 mx_drs_update(mx__turboc_flush);
	 return true;
}

static void mx__turboc_dirty(const MX_RECT * rect)
{
	 mx_drs_dirty(rect, true);
}

/* Some of the mouse code here has been taken from Allegro */
#define MX__MID(x,y,z)   MXMAX((x), MXMIN((y), (z)))

#define MX__MICKEY_TO_COORD(n)        ((n) / 2)
#define MX__COORD_TO_MICKEY(n)        ((n) * 2)

static unsigned mx__turboc_mouse(void)
{
	 int x, y;
	 union REGS regs;

	 if (!mx__turboc_mousevalid)
		  return false;

	 /* Get mouse button data */
	 regs.x.ax = 0x0003;
	 int86(0x33, &regs, &regs);
	 mx__mouseb = regs.x.bx;

	 /* Get mouse mickey data */
	 regs.x.ax = 0x000b;
	 int86(0x33, &regs, &regs);

	 x = (signed short) regs.x.cx;
	 y = (signed short) regs.x.dx;

	 /* Get the mouse coordinates */
	 mx__mousex = MX__MICKEY_TO_COORD(mx__turboc_mousex + x);
	 mx__mousey = MX__MICKEY_TO_COORD(mx__turboc_mousey + y);

	 /* Limit the mouse coordinates to on screen */
	 mx__mousex = MX__MID(mx__args.screen.x1, mx__mousex, mx__args.screen.x2);
	 mx__mousey = MX__MID(mx__args.screen.y1, mx__mousey, mx__args.screen.y2);
	 mx__turboc_mousex = MX__COORD_TO_MICKEY(mx__mousex);
	 mx__turboc_mousey = MX__COORD_TO_MICKEY(mx__mousey);

	 return true;
}

static unsigned mx__turboc_key(int *scan, long *ascii)
{
	 if (!kbhit())
		  return false;

	 *scan = 0;
	 *ascii = getch();

	 if (*ascii == 0)
		  *scan = getch();

	 return true;
}

MX_DRIVER mx__turboc_vga = {
	 mx__turboc_start,
	 mx__turboc_stop,

	 mx__turboc_poll,
	 mx__turboc_dirty,

	 mx__turboc_mouse,
	 mx__turboc_key
};

int main(int argc, char *argv[])
{
	 return mx_gfxmain(argc, argv);
}

#if !defined(MX_LIB) && !defined(MX__DRIVER_DEFAULT)
#define MX__DRIVER_DEFAULT
MX_DRIVER *mx__driver_default = &mx__turboc_vga;
#endif

#endif
#endif
#endif

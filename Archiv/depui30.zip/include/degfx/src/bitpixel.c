/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#if defined(MX_LIB) || defined(MX_DEGFX_BITPIXEL)
#ifndef MX_HAVE_DEGFX_BITPIXEL
#define MX_HAVE_DEGFX_BITPIXEL

#include "degfx/degfx.h"

MX_PIXEL mx_bitmap_getpixel(const MX_BITMAP * bitmap, int x1, int y1)
{
	 const MX_RECT *area = MXRECT(bitmap);

	 if (MX__CLIP_PIXEL(*area, x1, y1))
		  return 0;

	 MXASSERT(x1 >= area->x1);
	 MXASSERT(y1 >= area->y1);
	 MXASSERT(x1 <= area->x2);
	 MXASSERT(y1 <= area->y2);

	 return bitmap->_array[(y1 - area->y1) * bitmap->_pitch + (x1 - area->x1)];
}

void mx_bitmap_pixel(MX_BITMAP * bitmap, int x1, int y1, MX_PIXEL color)
{
	 if (MX__CLIP_PIXEL(bitmap->_clip, x1, y1))
		  return;

	 else {
		  const MX_RECT *area = MXRECT(bitmap);
		  MX_PIXEL *pixel = &bitmap->_array[(y1 - area->y1) * bitmap->_pitch + (x1 - area->x1)];

		  MXASSERT(x1 >= area->x1);
		  MXASSERT(y1 >= area->y1);
		  MXASSERT(x1 <= area->x2);
		  MXASSERT(y1 <= area->y2);

		  *pixel = MXBLEND(color, *pixel);
	 }
}

#endif
#endif

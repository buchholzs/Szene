/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#ifndef MX_HAVE_DEGFX_FONT
#define MX_HAVE_DEGFX_FONT

#include "degfx/degfx.h"

MX_FONT *mx__current_font = 0;

void mx_font_default(MX_FONT * font)
{
	 if (mx__current_font) {
		  mx_unlock(mx__current_font);
		  mx_delete(mx__current_font);
	 }

	 mx__current_font = font;

	 if (font)
		  mx_lock(font);
}

#endif

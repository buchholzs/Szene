/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#if defined(MX_LIB) || defined(MX_DEGFX_BITLINE)
#ifndef MX_HAVE_DEGFX_BITLINE
#define MX_HAVE_DEGFX_BITLINE

#include "degfx/degfx.h"
#include <string.h>

#define MX__CLIP_VLINE(rect, xa, ya, yb)                                       \
   (((xa) < (rect).x1) ||                                                    \
    ((xa) > (rect).x2) ||                                                    \
    (((yb) = MXMIN((yb), ((rect).y2))) < ((ya) = MXMAX((ya), ((rect).y1)))))

#define MX__CLIP_HLINE(rect, xa, ya, xb)                                       \
   (((ya) < (rect).y1) ||                                                    \
    ((ya) > (rect).y2) ||                                                    \
    (((xb) = MXMIN((xb), ((rect).x2))) < ((xa) = MXMAX((xa), ((rect).x1)))))

#define MX__CLIP_RECT(rect, x1, y1, x2, y2)                                      \
   ((((x2) = MXMIN((x2), ((rect).x2))) < ((x1) = MXMAX((x1), ((rect).x1)))) || \
    (((y2) = MXMIN((y2), ((rect).y2))) < ((y1) = MXMAX((y1), ((rect).y1)))))

void mx_bitmap_vline(MX_BITMAP * bitmap, int x1, int y1, int y2, MX_PIXEL color)
{
	 MX_PIXEL *start;
	 const MX_RECT *area;
	 const unsigned int trans = MXT(color);

	 if (MX__CLIP_VLINE(bitmap->_clip, x1, y1, y2))
		  return;

	 if (trans == 0xFF)
		  return;

	 area = MXRECT(bitmap);
	 MXASSERT(x1 >= area->x1);
	 MXASSERT(y1 >= area->y1);
	 MXASSERT(y2 >= area->y1);
	 MXASSERT(x1 <= area->x2);
	 MXASSERT(y1 <= area->y2);
	 MXASSERT(y2 <= area->y2);

	 y1 -= area->y1;
	 y2 -= area->y1;
	 start = &bitmap->_array[y1 * bitmap->_pitch + (x1 - area->x1)];

	 if (trans) {
		  while (y1 <= y2) {
				*start = MXBLENDT(color, *start, trans);
				start += bitmap->_pitch;
				++y1;
		  }
	 } else {
		  while (y1 <= y2) {
				*start = color;
				start += bitmap->_pitch;
				++y1;
		  }
	 }
}

static void fasthline(MX_BITMAP * bitmap, int x1, int y1, int x2, MX_PIXEL color)
{
	 const unsigned int trans = MXT(color);

	 if (trans == 0xFF)
		  return;

	 else {
		  const MX_RECT *area = MXRECT(bitmap);
		  MX_PIXEL *start = &bitmap->_array[(y1 - area->y1) * bitmap->_pitch + (x1 - area->x1)];
		  const MX_PIXEL *end = start + (x2 - x1);

		  if (trans) {
				while (start <= end) {
					 *start = MXBLENDT(color, *start, trans);
					 ++start;
				}
		  } else {
				while (start <= end) {
					 *start = color;
					 ++start;
				}
		  }
	 }
}

void mx_bitmap_hline(MX_BITMAP * bitmap, int x1, int y1, int x2, MX_PIXEL color)
{
#ifndef NDEBUG
	 const MX_RECT *area;
#endif

	 if (MX__CLIP_HLINE(bitmap->_clip, x1, y1, x2))
		  return;

#ifndef NDEBUG
	 area = MXRECT(bitmap);
	 MXASSERT(x1 >= area->x1);
	 MXASSERT(y1 >= area->y1);
	 MXASSERT(x2 >= area->x1);
	 MXASSERT(x1 <= area->x2);
	 MXASSERT(y1 <= area->y2);
	 MXASSERT(x2 <= area->x2);
#endif

	 fasthline(bitmap, x1, y1, x2, color);
}

void mx_bitmap_rectfill(MX_BITMAP * bitmap, int x1, int y1, int x2, int y2, MX_PIXEL color)
{
#ifndef NDEBUG
	 const MX_RECT *area;
#endif

	 if (MX__CLIP_RECT(bitmap->_clip, x1, y1, x2, y2))
		  return;

#ifndef NDEBUG
	 area = MXRECT(bitmap);
	 MXASSERT(x1 >= area->x1);
	 MXASSERT(y1 >= area->y1);
	 MXASSERT(x2 >= area->x1);
	 MXASSERT(x1 <= area->x2);
	 MXASSERT(y1 <= area->y2);
	 MXASSERT(x2 <= area->x2);
#endif

	 while (y1 <= y2) {
		  fasthline(bitmap, x1, y1, x2, color);
		  ++y1;
	 }
}

void mx_bitmap_clear(MX_BITMAP * bitmap, MX_PIXEL color)
{
	 int x1 = mx_x1(bitmap);
	 int y1 = mx_y1(bitmap);
	 int x2 = mx_x2(bitmap);
	 int y2 = mx_y2(bitmap);

	 if (MX__CLIP_RECT(bitmap->_clip, x1, y1, x2, y2))
		  return;

	 mx_bitmap_rectfill(bitmap, x1, y1, x2, y2, color);
}

#define SWAP(a,b)           \
    do {                    \
        const int temp = a; \
        a = b;              \
        b = temp;           \
    } while (0)

#define GETCODE(x,y,code)         \
    do {                          \
        if (x < bitmap->_clip.x1) \
            code |= 1;            \
        if (x > bitmap->_clip.x2) \
            code |= 2;            \
        if (y < bitmap->_clip.y1) \
            code |= 4;            \
        if (y > bitmap->_clip.y2) \
            code |= 8;            \
    } while (0)

void mx_bitmap_line(MX_BITMAP * bitmap, int x1, int y1, int x2, int y2, MX_PIXEL color)
{
	 int code1 = 0, code2 = 0;
	 int dy = abs(y2 - y1) << 1;
	 int dx = abs(x2 - x1) << 1;
	 MX_PIXEL *iter;

	 const unsigned int trans = MXT(color);

	 if (trans == 0xFF)
		  return;

	 GETCODE(x1, y1, code1);
	 GETCODE(x2, y2, code2);

	 if (code1 & code2)
		  return;

	 if (!MXRECT_VALID(bitmap->_clip))
		  return;

	 if (dx == 0) {
		  if (y2 < y1) {
				SWAP(x1, x2);
				SWAP(y1, y2);
		  }

		  mx_bitmap_vline(bitmap, x1, y1, y2, color);

	 } else if (dy == 0) {
		  if (x2 < x1) {
				SWAP(x1, x2);
				SWAP(y1, y2);
		  }

		  mx_bitmap_hline(bitmap, x1, y1, x2, color);

	 } else if (dx > dy) {
		  int stepy, stopy;
		  int fraction = dy - (dx >> 1);

		  if (x2 < x1) {
				SWAP(x1, x2);
				SWAP(y1, y2);
		  }

		  if (y2 > y1) {
				stepy = 1;
				stopy = bitmap->_clip.y2 + 1;
		  } else {
				stepy = -1;
				stopy = bitmap->_clip.y1 - 1;
		  }

		  if (x1 < bitmap->_clip.x1) {
				const int xn = bitmap->_clip.x1 - x1;
				const int cy = (fraction + xn * dy - dy + dx) / dx;

				x1 = bitmap->_clip.x1;
				y1 = y1 + cy * stepy;
				fraction = fraction - cy * dx + xn * dy;
		  }

		  x2 = MXMIN(x2, bitmap->_clip.x2);
		  if (x1 > x2)
				return;

		  if (((stepy == 1) && (y1 > bitmap->_clip.y2)) || ((stepy == -1) && (y1 < bitmap->_clip.y1)))
				return;

		  if (y2 == y1) {
				mx_bitmap_hline(bitmap, x1, y1, x2, color);
				return;

		  } else if ((stepy == 1) && (y1 < bitmap->_clip.y1)) {
				const int yn = bitmap->_clip.y1 - y1;
				const int cx = (dy - dx - fraction + yn * dx + dy - 1) / dy;

				x1 = x1 + cx;
				y1 = bitmap->_clip.y1;
				fraction = fraction - yn * dx + cx * dy;

		  } else if ((stepy == -1) && (y1 > bitmap->_clip.y2)) {
				const int yn = y1 - bitmap->_clip.y2;
				const int cx = (dy - dx - fraction + yn * dx + dy - 1) / dy;

				x1 = x1 + cx;
				y1 = bitmap->_clip.y2;
				fraction = fraction - yn * dx + cx * dy;
		  }

		  iter = mx_bitmap_iter(bitmap, x1, y1);

		  if (trans) {
				while ((x1 <= x2) && (y1 != stopy)) {
					 *iter = MXBLENDT(color, *iter, trans);

					 if (fraction >= 0) {
						  y1 += stepy;
						  iter += bitmap->_pitch * stepy;
						  fraction -= dx;
					 }
					 ++x1;
					 ++iter;
					 fraction += dy;
				}
		  } else {
				while ((x1 <= x2) && (y1 != stopy)) {
					 *iter = color;

					 if (fraction >= 0) {
						  y1 += stepy;
						  iter += bitmap->_pitch * stepy;
						  fraction -= dx;
					 }
					 ++x1;
					 ++iter;
					 fraction += dy;
				}
		  }
	 } else {
		  int stepx, stopx;
		  int fraction = dx - (dy >> 1);

		  if (y2 < y1) {
				SWAP(y1, y2);
				SWAP(x1, x2);
		  }

		  if (x2 > x1) {
				stepx = 1;
				stopx = bitmap->_clip.x2 + 1;
		  } else {
				stepx = -1;
				stopx = bitmap->_clip.x1 - 1;
		  }

		  if (y1 < bitmap->_clip.y1) {
				const int yn = bitmap->_clip.y1 - y1;
				const int cx = (fraction + yn * dx - dx + dy) / dy;

				y1 = bitmap->_clip.y1;
				x1 = x1 + cx * stepx;
				fraction = fraction - cx * dy + yn * dx;
		  }

		  y2 = MXMIN(y2, bitmap->_clip.y2);
		  if (y1 > y2)
				return;

		  if (((stepx == 1) && (x1 > bitmap->_clip.x2)) || ((stepx == -1) && (x1 < bitmap->_clip.x1)))
				return;

		  if (x2 == x1) {
				mx_bitmap_vline(bitmap, x1, y1, y2, color);
				return;

		  } else if ((stepx == 1) && (x1 < bitmap->_clip.x1)) {
				const int xn = bitmap->_clip.x1 - x1;
				const int cy = (dx - dy - fraction + xn * dy + dx - 1) / dx;

				y1 = y1 + cy;
				x1 = bitmap->_clip.x1;
				fraction = fraction - xn * dy + cy * dx;

		  } else if ((stepx == -1) && (x1 > bitmap->_clip.x2)) {
				const int xn = x1 - bitmap->_clip.x2;
				const int cy = (dx - dy - fraction + xn * dy + dx - 1) / dx;

				y1 = y1 + cy;
				x1 = bitmap->_clip.x2;
				fraction = fraction - xn * dy + cy * dx;
		  }

		  iter = mx_bitmap_iter(bitmap, x1, y1);

		  if (trans) {
				while ((y1 <= y2) && (x1 != stopx)) {
					 *iter = MXBLENDT(color, *iter, trans);

					 if (fraction >= 0) {
						  x1 += stepx;
						  iter += stepx;
						  fraction -= dy;
					 }
					 ++y1;
					 iter += bitmap->_pitch;
					 fraction += dx;
				}
		  } else {
				while ((y1 <= y2) && (x1 != stopx)) {
					 *iter = color;

					 if (fraction >= 0) {
						  x1 += stepx;
						  iter += stepx;
						  fraction -= dy;
					 }
					 ++y1;
					 iter += bitmap->_pitch;
					 fraction += dx;
				}
		  }
	 }
}

void mx_bitmap_box(MX_BITMAP * bitmap, int x1, int y1, int x2, int y2, int width, MX_PIXEL light, MX_PIXEL dark)
{
	 int i;

	 if (width < 0) {
		  int temp = light;

		  light = dark;
		  dark = temp;

		  width *= -1;
	 }

	 for (i = 0; i < width; i++) {
		  mx_bitmap_vline(bitmap, x1, y1, y2, light);
		  mx_bitmap_hline(bitmap, x1 + 1, y1, x2, light);

		  mx_bitmap_vline(bitmap, x2, y1 + 1, y2, dark);
		  mx_bitmap_hline(bitmap, x1 + 1, y2, x2 - 1, dark);

		  x1++, y1++, x2--, y2--;
	 }
}

void mx_bitmap_frame(MX_BITMAP * bitmap, int x1, int y1, int x2, int y2, int width, MX_PIXEL light, MX_PIXEL dark, MX_PIXEL fill)
{
	 mx_bitmap_box(bitmap, x1, y1, x2, y2, width, light, dark);
	 mx_bitmap_rectfill(bitmap, x1 + abs(width), y1 + abs(width), x2 - abs(width), y2 - abs(width), fill);
}

#endif
#endif

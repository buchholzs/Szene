/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#if defined(MX_LIB) || defined(MX_DEGFX_FONTDRAW)
#ifndef MX_HAVE_DEGFX_FONTDRAW
#define MX_HAVE_DEGFX_FONTDRAW

/* If no font has been included yet then choose the default font */
#ifndef MX_FONT_DEFAULT
#define MX_DEGFX_FONT8X8
#include "degfx/src/font8x8.c"
#endif

#include "degfx/degfx.h"

static MX__FONT_INDEX *mx__font_range(const MX_FONT * font, const long c)
{
	 unsigned int i;
	 MX__FONT_INDEX *index = font->_index;

	 /* Look in all the font sections */
	 for (i = 0; i < font->_sections; i++) {

		  /* Is the character in the range of the font */
		  if ((c >= index->_start) && (c < (index->_start + 128)))
				return index;

		  /* The sections are in ascending order, are we past it? */
		  else if (c < index->_start)
				return 0;

		  ++index;
	 }
	 return 0;
}

void mx__font_bitchar(MX_BITMAP * bitmap, const MX_RECT * charrect, const MX_RECT * drawrect, const unsigned char *data,
							 unsigned int width, MX_PIXEL color, MX_PIXEL back)
{
	 int r;
	 unsigned int bpix;
	 unsigned int xoff, yoff, x2off;
	 const int fill = (color == back) ? 0 : 1;

	 xoff = drawrect->x1 - charrect->x1;
	 yoff = drawrect->y1 - charrect->y1;
	 x2off = charrect->x2 - drawrect->x2;

	 /* Move the data over to correct to the mx_clipping on the top and the
	    width of the character */
	 data += ((yoff * width) / 8) - 1;

	 for (r = drawrect->y1; r <= drawrect->y2; r++) {

		  MX_BITMAP_ITER iter = mx_bitmap_iter(bitmap, drawrect->x1, r);
		  const MX_BITMAP_ITER end = mx_bitmap_iter(bitmap, drawrect->x2, r);

		  /* Move the data over to correct for the clipping on the left */
		  bpix = 0x100 >> (xoff % 8);
		  data += (xoff / 8) + 1;

		  while (iter <= end) {

				/* Go one pixel to right, and maybe to the next data byte */
				bpix >>= 1;
				if (!bpix) {
					 bpix = 0x80;
					 ++data;
				}

				/* Foreground pixel */
				if ((*data) & bpix)
					 *iter = MXBLEND(color, *iter);

				/* Background pixel */
				else if (fill)
					 *iter = MXBLEND(back, *iter);

				++iter;
		  }

		  /* Skip data to the right if the right side is clipped */
		  data += (x2off / 8);
	 }
}

void mx__font_bytechar(MX_BITMAP * bitmap, const MX_RECT * charrect, const MX_RECT * drawrect, const unsigned char *data,
							  unsigned int width, MX_PIXEL color, MX_PIXEL back)
{
	 int r;
	 unsigned int xoff, yoff, x2off;

	 xoff = drawrect->x1 - charrect->x1;
	 yoff = drawrect->y1 - charrect->y1;
	 x2off = charrect->x2 - drawrect->x2;

	 data += yoff * width;

	 for (r = drawrect->y1; r <= drawrect->y2; r++) {

		  MX_BITMAP_ITER iter = mx_bitmap_iter(bitmap, drawrect->x1, r);
		  const MX_BITMAP_ITER end = mx_bitmap_iter(bitmap, drawrect->x2, r);

		  data += xoff;

		  if (color != back) {
				while (iter <= end) {
					 *iter = MXBLENDT(back, color, *data);
					 ++iter;
					 ++data;
				}
		  } else {
				while (iter <= end) {
					 *iter = MXBLENDT(*iter, color, *data);
					 ++iter;
					 ++data;
				}
		  }

		  /* Skip data to the right if the right side is clipped */
		  data += x2off;
	 }
}

void mx__font_bytechar_mono(MX_BITMAP * bitmap, const MX_RECT * charrect, const MX_RECT * drawrect, const unsigned char *data,
									 unsigned int width, MX_PIXEL color, MX_PIXEL back)
{
	 int r;
	 unsigned int xoff, yoff, x2off;

	 xoff = drawrect->x1 - charrect->x1;
	 yoff = drawrect->y1 - charrect->y1;
	 x2off = charrect->x2 - drawrect->x2;

	 data += yoff * width;

	 for (r = drawrect->y1; r <= drawrect->y2; r++) {

		  MX_BITMAP_ITER iter = mx_bitmap_iter(bitmap, drawrect->x1, r);
		  const MX_BITMAP_ITER end = mx_bitmap_iter(bitmap, drawrect->x2, r);

		  data += xoff;

		  while (iter <= end) {
				if (*data++)
					 *iter = color;
				else if (color != back)
					 *iter = back;

				++iter;
		  }

		  /* Skip data to the right if the right side is clipped */
		  data += x2off;
	 }
}

static unsigned mx__font_clipped(const MX_RECT * clip, const MX_FONT * font, int x, const int y)
{
	 MXASSERT(font);

	 /* Is it under or over or too far to the right of the clipping rect then
	    we can assume the whole string is clipped */
	 if ((y + (int) font->_height < clip->y1) || (y > clip->y2) || (x > clip->x2))
		  return true;

	 return false;
}

void mx_font_bitmap_draw(const MX_FONT * font, MX_BITMAP * bitmap, const char *text, int len, int x, int y, MX_PIXEL fore,
                         MX_PIXEL back)
{
	 int n = 0;
	 const MX__FONT_INDEX *range = 0;

	 MX_RECT charrect, clip;

	 if (!font)
		  font = mx__current_font;
	 if (!font)
		  font = &MX_FONT_DEFAULT;

	 MXASSERT(font);

	 charrect.y1 = y;
	 clip = *mx_bitmap_clip_get(bitmap);

	 /* Make sure we know about text length for zero terminated */
	 if (len < 0)
		  len = 0x7fff;

	 /* Skip easy clipping conditions */
	 if (mx__font_clipped(&clip, font, x, y))
		  return;

	 /* Write each character of the string */
	 while ((*text) && (n < len)) {
		  const unsigned int clen = mx_utf8_len(text);
		  const long c = mx_utf8_char(text, clen);

		  /* If left side of char farther than right side of clipping, we are
		     done */
		  if (x > clip.x2)
				return;

		  /* Find the character in the range */
		  if ((!range) || (c < range->_start) || (c >= (range->_start + 128)))
				range = mx__font_range(font, c);

		  if (range) {
				MX_RECT drawrect;
				const unsigned int width = range->_width[c - range->_start];
				const unsigned char *cdata = &font->_data[range->_index[c - range->_start]];

				charrect.x1 = x;
				charrect.x2 = x + width - 1;
				charrect.y2 = y + font->_height - 1;

				/* Only draw characters that are not completely clipped */
				MXRECT_INTERSECT(charrect, clip, drawrect);
				if (MXRECT_VALID(drawrect))
					 font->_drawchar(bitmap, &charrect, &drawrect, cdata, width, fore, back);

				x = charrect.x2 + 1;
		  }

		  text += clen;
		  ++n;
	 }
}

unsigned int mx_font_height(const MX_FONT * font)
{
	 if (!font)
		  font = mx__current_font;
	 if (!font)
		  font = &MX_FONT_DEFAULT;

	 return font->_height;
}

unsigned int mx_font_width(const MX_FONT * font, const char *text, int num)
{
	 int count = 0;
	 unsigned int len = 0;
	 const MX__FONT_INDEX *range = 0;

	 if (!font)
		  font = mx__current_font;
	 if (!font)
		  font = &MX_FONT_DEFAULT;

	 MXASSERT(font);
	 MXASSERT(font->_sections != 0);

	 if (num < 0)
		  num = 0x7fff;

	 while ((text) && (*text) && (count < num)) {
		  const unsigned int clen = mx_utf8_len(text);
		  const long c = mx_utf8_char(text, clen);

		  /* Find the new range for the mx_font if we need */
		  if ((!range) || (c < range->_start) || (c >= (range->_start + 128)))
				range = mx__font_range(font, c);

		  if (range)
				len += range->_width[c - range->_start];

		  text += clen;
		  ++count;
	 }
	 return len;
}

void mx_font_bitmap_drawblock(const MX_FONT * font, MX_BITMAP * bitmap, const char *text, int len, int x, int y, MX_PIXEL fore,
                              MX_PIXEL back)
{
	 int n = 0;
	 const int lineheight = mx_font_height(font);

	 if (!font)
		  font = mx__current_font;
	 if (!font)
		  font = &MX_FONT_DEFAULT;

	 if (len < 0)
		  len = 0xffff;

	 while ((text) && (*text) && (n < len)) {
		  int i = 0;
		  const char *p = text;

		  while ((*p) && (*p != '\r') && (*p != '\n') && (n < len)) {
				p += mx_utf8_len(p);
				++i;
				++n;
		  }

		  mx_font_bitmap_draw(font, bitmap, text, i, x, y, fore, back);

		  if (*p == '\r') {
				p += mx_utf8_len(p);
				++n;
		  }

		  if (*p == '\n') {
				p += mx_utf8_len(p);
				++n;
		  }

		  y += lineheight;
		  text = p;
	 }
}

void mx_font_blocksize(const MX_FONT * font, const char *text, int len, int *tw, int *th)
{
	 int n = 0;
	 const int lineheight = mx_font_height(font);

	 if (!font)
		  font = mx__current_font;
	 if (!font)
		  font = &MX_FONT_DEFAULT;

	 if (len < 0)
		  len = 0xffff;

	 if (tw)
		  *tw = 0;

	 if (th)
		  *th = lineheight;

	 while ((text) && (*text) && (n < len)) {
		  int sw, i = 0;
		  const char *p = text;
		  unsigned newline = false;

		  while ((*p) && (*p != '\r') && (*p != '\n') && (n < len)) {
				p += mx_utf8_len(p);
				++i;
				++n;
		  }

		  sw = mx_font_width(font, text, i);

		  if ((tw) && (*tw < sw))
				*tw = sw;

		  if (*p == '\r') {
				p += mx_utf8_len(p);
				++n;
				newline = true;
		  }

		  if (*p == '\n') {
				p += mx_utf8_len(p);
				++n;
				newline = true;
		  }

		  if ((newline) && (th))
				*th += lineheight;

		  text = p;
	 }
}

#endif
#endif

/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#ifdef __DJGPP__
#if defined(MX_LIB) || defined(MX_DEGFX_DJGPP_13H)
#ifndef MX_HAVE_DEGFX_DJGPP_13H
#define MX_HAVE_DEGFX_DJGPP_13H
#define MX_DRIVER_EXISTS

#define MX_DETK_DRS

#include "degfx/degfx.h"
#include <pc.h>
#include <dpmi.h>
#include <go32.h>
#include <conio.h>
#include <sys/farptr.h>

#define MX_DEGFX_DJGPP
#include "degfx/src/djgpp/djgpp.c"

static unsigned mx__djgpp_13h_start(MX_GFX_ARGS * args)
{
	 int x;
	 __dpmi_regs r;

	 /* Set graphics mode */
	 r.x.ax = 0x13;
	 __dpmi_int(0x10, &r);

	 /* Setup 332 palette for 8 bit modes */
	 for (x = 0; x < 256; x++) {
		  const unsigned char r = x & 224;
		  const unsigned char g = (x & 28) << 3;
		  const unsigned char b = (x & 3) << 6;

		  outportb(0x3c8, (unsigned char) x);
		  outportb(0x3c9, (unsigned char) r >> 2);
		  outportb(0x3c9, (unsigned char) g >> 2);
		  outportb(0x3c9, (unsigned char) b >> 2);
	 }

	 /* Reset the mouse driver */
	 r.x.ax = 0x0000;
	 __dpmi_int(0x33, &r);
	 if (r.x.ax)
		  mx__djgpp_mouse_valid = true;
	 else
		  mx__djgpp_mouse_valid = false;

	 /* Inform the user of the results */
	 args->w = 320;
	 args->h = 200;
	 args->c = 8;
	 args->title = "djgpp_13h";
	 args->pointer = false;

	 mx_drs_area(args->w - 1, args->h - 1);

	 return true;
}

static void mx__djgpp_13h_stop(void)
{
	 __dpmi_regs reg;

	 reg.x.ax = 0x0003;
	 __dpmi_int(0x10, &reg);

	 textmode(C80);
}

static void mx__djgpp_13h__flush(const MX_RECT * rect, MX_PIXEL * array, const int stride)
{
	 int y = rect->y1;

	 /* Set the selector for fast acces to the screen */
	 _farsetsel(_dos_ds);

	 /* Push the buffer to the visible screen */
	 while (y <= rect->y2) {

		  unsigned int start = 0xA0000 + (y * 320) + rect->x1;
		  unsigned int end = start + (rect->x2 - rect->x1);
		  const MX_PIXEL *color = array;

		  while (start <= end) {
				_farnspokeb(start++, MXRGB332(*color));
				++color;
		  }

		  array += stride;
		  ++y;
	 }
}

static void mx__djgpp_13h_flush(MX_RECT * rect)
{
	 mx__gfx_flush(mx__djgpp_13h__flush, rect);
}

static unsigned mx__djgpp_13h_poll(void)
{
	 mx_drs_update(mx__djgpp_13h_flush);
	 return true;
}

static void mx__djgpp_13h_dirty(const MX_RECT * rect)
{
	 mx_drs_dirty(rect, true);
}

MX_DRIVER mx__djgpp_13h = {
	 mx__djgpp_13h_start,
	 mx__djgpp_13h_stop,

	 mx__djgpp_13h_poll,
	 mx__djgpp_13h_dirty,

	 mx__djgpp_pointer,
	 mx__djgpp_key
};

#if !defined(MX_LIB) && !defined(MX__DRIVER_DEFAULT)
#define MX__DRIVER_DEFAULT
MX_DRIVER *mx__driver_default = &mx__djgpp_13h;
#endif

#endif
#endif
#endif

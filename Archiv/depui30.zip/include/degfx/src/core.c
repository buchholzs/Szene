/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#ifndef MX_HAVE_DEGFX_CORE
#define MX_HAVE_DEGFX_CORE

#define MX_DETK_REGION
#define MX_DETK_VECTOR

#include "degfx/degfx.h"

/* Does draw clip setting sometimes set invalid rects? */

#include <string.h>

typedef void (*MX_DRAW_FUNC) (const MX_RECT * rect, MX_PIXEL * array, const int stride);

MX_GFX_ARGS mx__args;

static int mx__mousex, mx__mousey, mx__mouseb;
static unsigned int mx__stopsession = 0;

static void mx__exit(void)
{
	 mx_font_default(0);
	 mx_gfx_stop();
}

unsigned mx_gfx_start(MX_GFX_ARGS * userargs)
{
	 MX_GFX_ARGS args = mx__args;
	 const MX_GFX_ARGS old = mx__args;

	 /* Get the users args if there */
	 if (userargs) {
		  args = *userargs;

		  /* The new mode might be the same as the old mode */
		  if ((old.session) && (args.w == old.w) && (args.h == old.h) && (args.c == old.c) && (args.title == old.title)
				&& (((args.driver) && (args.driver == old.driver)) || (!args.driver)))
				goto done_mode_change;

		  /* If no user args and we are stopped, get default args */
	 } else if (old.session == mx__stopsession)
		  memset(&args, 0, sizeof(args));

	 /* NULL driver means use the current driver or if there is none, then use 
	    the default driver */
	 if (!args.driver)
		  args.driver = mx__args.driver;
	 if (!args.driver)
		  args.driver = mx__driver_default;

	 /* Will the driver been changed, then stop the old one */
	 if ((old.driver) && (old.driver->_stop) && (args.driver != old.driver))
		  old.driver->_stop();

	 /* Try to set the video mode */
	 if (!args.driver->_start(&args))
		  return false;

  done_mode_change:

	 /* Setup some helper data */
	 args.screen.x1 = 0;
	 args.screen.y1 = 0;
	 args.screen.x2 = args.w - 1;
	 args.screen.y2 = args.h - 1;

	 /* Allocate a buffer bitmap */
	 if ((old.buffer) && (old.buffer != args.buffer)) {
		  mx_unlock(old.buffer);
		  mx_delete(old.buffer);
	 }

	 if (!args.buffer) {
		  args.buffer = mx_bitmap(MX_GFX_BUFFER_W, MX_GFX_BUFFER_H);
		  MXNAMESET(args.buffer, "buffer_default");
	 }
	 MXASSERT(args.buffer);
	 mx_lock(args.buffer);

	 if (mx__args.session == 0)
		  atexit(mx__exit);

	 /* Get the info for the user */
	 mx__args = args;
	 mx__args.session = mx__stopsession + 1;

	 if (userargs)
		  *userargs = *mx_gfx_info();

	 return true;
}

void mx_gfx_stop(void)
{
	 if (mx__args.buffer) {
		  mx_unlock(mx__args.buffer);
		  mx_delete(mx__args.buffer);
	 }

	 if ((mx__args.driver) && (mx__args.driver->_stop))
		  mx__args.driver->_stop();

	 if (mx__args.session)
		  mx__stopsession = mx__args.session;

	 memset(&mx__args, 0, sizeof(MX_GFX_ARGS));
}

const MX_GFX_ARGS *mx_gfx_info(void)
{
	 return &mx__args;
}

void mx_gfx_redraw(MX_REDRAW_FUNC redraw)
{
	 mx__args.redraw = redraw;

	 mx_gfx_dirty(&mx__args.screen);
}

#define MOUSE_W   10
#define MOUSE_H   16

#define P0 MXRGBT(0, 0, 0, 255)
#define P1 MXRGBT(0, 0, 0, 0)
#define P2 MXRGBT(255, 255, 255, 0)

static MX_PIXEL pointer[MOUSE_W * MOUSE_H] = {
	 P1, P1, P0, P0, P0, P0, P0, P0, P0, P0,
	 P1, P2, P1, P0, P0, P0, P0, P0, P0, P0,
	 P1, P2, P2, P1, P0, P0, P0, P0, P0, P0,
	 P1, P2, P2, P2, P1, P0, P0, P0, P0, P0,
	 P1, P2, P2, P2, P2, P1, P0, P0, P0, P0,
	 P1, P2, P2, P2, P2, P2, P1, P0, P0, P0,
	 P1, P2, P2, P2, P2, P2, P2, P1, P0, P0,
	 P1, P2, P2, P2, P2, P2, P2, P2, P1, P0,
	 P1, P2, P2, P2, P2, P2, P2, P2, P2, P1,
	 P1, P2, P2, P2, P2, P2, P1, P1, P1, P0,
	 P1, P2, P2, P1, P2, P2, P1, P0, P0, P0,
	 P1, P2, P1, P0, P1, P2, P2, P1, P0, P0,
	 P0, P1, P0, P0, P1, P2, P2, P1, P0, P0,
	 P0, P0, P0, P0, P0, P1, P2, P2, P1, P0,
	 P0, P0, P0, P0, P0, P1, P2, P2, P1, P0,
	 P0, P0, P0, P0, P0, P0, P1, P1, P0, P0
};

#undef P0
#undef P1
#undef P2

static MX_BITMAP mx__pointer = MXBITMAP_DECLARE(pointer, MOUSE_W, MOUSE_H);

void mx__gfx_flush(MX_DRAW_FUNC draw, MX_RECT * rect)
{
	 MXASSERT(rect);

	 MXASSERT(MXRECT_VALID(*rect));
	 MXASSERT(mx__args.buffer);
	 MXASSERT(mx__args.driver);
	 MXASSERT(mx__args.redraw);
	 MXASSERT(draw);

	 mx_lock(mx__args.buffer);

	 /* Make sure the area isnt too large and has the correct alignment */
	 mx_bitmap_offset(mx__args.buffer, rect->x1, rect->y1);
	 MXRECT_INTERSECT(*MXRECT(mx__args.buffer), *rect, *rect);

	 /* Actually get the bitmap to be updated */
	 mx_bitmap_clip(mx__args.buffer, rect);
	 mx__args.redraw(rect);

	 /* Draw the pointer */
	 mx_bitmap_clip(mx__args.buffer, rect);
	 if ((!mx__args.pointer) && (!mx__args._hidepointer))
		  mx_blit(&mx__pointer, 0, 0, mx__mousex, mx__mousey, MXDEF, MXDEF);

	 /* Push the buffer to the visible buffer */
	 draw(rect, mx__args.buffer->_array, mx_w(mx__args.buffer) + 1);

	 mx_unlock(mx__args.buffer);
}

void mx__gfx_update(MX_DRAW_FUNC draw, const MX_RECT * rect)
{
	 int size;
	 MX_REGION region;
	 MX_RECT temp;

	 MXASSERT(rect);

	 temp = *rect;
	 MXRECT_INTERSECT(mx__args.screen, temp, temp);
	 if (!MXRECT_VALID(temp))
		  return;

	 mx_vector(&region);
	 mx_vector_reserve(&region, 64);
	 mx_vector_append(&region, &temp, 1);

	 while ((size = mx_vector_size(&region)) != 0) {
		  temp = region.data[size - 1];

		  mx__gfx_flush(draw, &temp);

		  mx_region_clip(&region, &temp);
	 }

	 mx_vector_free(&region);
}

unsigned mx_gfx_poll(void)
{
	 return mx__args.driver->_poll();
}

void mx_gfx_dirty(const MX_RECT * rect)
{
	 if (!rect)
		  rect = &mx__args.screen;

	 mx__args.driver->_dirty(rect);
}

unsigned mx_gfx_pointer(int *x, int *y, int *b)
{
	 unsigned ret = 0;
	 const int oldx = mx__mousex;
	 const int oldy = mx__mousey;

	 if (mx__args.session == mx__stopsession)
		  return false;

	 /* Pass the request to the pointer driver */
	 if (mx__args.driver->_pointer)
		  ret = mx__args.driver->_pointer();
	 if (!ret)
		  return false;

	 /* Update the users values */
	 if (x)
		  *x = mx__mousex;
	 if (y)
		  *y = mx__mousey;
	 if (b)
		  *b = mx__mouseb;

	 if ((!mx__args.pointer) && ((mx__mousex != oldx) || (mx__mousey != oldy))) {
		  MX_RECT prev, rect;

		  prev.x1 = oldx;
		  prev.y1 = oldy;
		  prev.x2 = oldx + mx_w(&mx__pointer);
		  prev.y2 = oldy + mx_h(&mx__pointer);

		  rect.x1 = mx__mousex;
		  rect.y1 = mx__mousey;
		  rect.x2 = mx__mousex + mx_w(&mx__pointer);
		  rect.y2 = mx__mousey + mx_h(&mx__pointer);

		  /* If mouse positions overlap, draw them together */
		  if (MXRECTS_OVERLAP(prev, rect)) {
				MXRECT_UNION(prev, rect, rect);
				mx_gfx_dirty(&rect);

				/* Mouse moved a great distance, draw each position seperately */
		  } else {
				mx_gfx_dirty(&rect);
				mx_gfx_dirty(&prev);
		  }
	 }
	 return true;
}

unsigned mx_gfx_hidepointer(unsigned hide)
{
    const unsigned old = mx__args._hidepointer;

	 mx__args._hidepointer = hide;

    return old;
}

unsigned mx_gfx_key(int *scan, long *ascii)
{
	 int dummy;
	 long ldummy;

	 if (!mx__args.driver->_key)
		  return 0;

	 /* Gracefully handle defaults */
	 if (!scan)
		  scan = &dummy;
	 if (!ascii)
		  ascii = &ldummy;

	 return mx__args.driver->_key(scan, ascii);
}

#endif

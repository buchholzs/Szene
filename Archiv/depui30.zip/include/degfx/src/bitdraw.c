/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#if defined(MX_LIB) || defined(MX_DEGFX_BITDRAW)
#ifndef MX_HAVE_DEGFX_BITDRAW
#define MX_HAVE_DEGFX_BITDRAW

#include "degfx/degfx.h"
#include <string.h>

unsigned mx_bitmap_collision(const MX_BITMAP * src, const MX_BITMAP * dest, int sx, int sy, int dx, int dy, unsigned int thresh)
{
	 int y;
	 MX_RECT d;
	 MX_RECT s;
	 MX_RECT inter;

	 d = *MXRECT(dest);
	 s = *MXRECT(src);

 /* Translate destnation area to source */
	 d.x1 += dx;
	 d.y1 += dy;
	 d.x2 += dx;
	 d.y2 += dy;
	 s.x1 += sx;
	 s.y1 += sy;
	 s.x2 += sx;
	 s.y2 += sy;

	 /* Check for overlap in the areas */
	 MXRECT_INTERSECT(s, d, inter);
	 if (!MXRECT_VALID(inter))
		  return false;

	 /* Check for overlapping pixels */
	 for (y = inter.y1; y <= inter.y2; y++) {

		  MX_BITMAP_ITER srci = mx_bitmap_iter(src, inter.x1 - sx, y - sy);
		  const MX_BITMAP_ITER endi = mx_bitmap_iter(src, inter.x2 - sx, y - sy);

		  MX_BITMAP_ITER dsti = mx_bitmap_iter(dest, inter.x1 - dx, inter.y1 - dy);

		  while (srci <= endi) {
				if ((MXT(*srci) < thresh) && (MXT(*dsti) < thresh))
					 return true;

				++srci;
				++dsti;
		  }
	 }
	 return false;
}

void mx_bitmap_blitstretch(const MX_BITMAP * src, MX_BITMAP * dest, int sx, int sy, int sw, int sh, int dx, int dy, int dw, int dh)
{
	 int x, y;
	 MX_BITMAP_ITER srci, dsti;

	 MXASSERT(src != dest);

	 if (sx == MXDEF)
		  sx = 0;
	 if (sy == MXDEF)
		  sy = 0;
	 if (sw == MXDEF)
		  sw = mx_w(src);
	 if (sh == MXDEF)
		  sh = mx_h(src);
	 if (dx == MXDEF)
		  dx = 0;
	 if (dy == MXDEF)
		  dy = 0;
	 if (dw == MXDEF)
		  dw = sw;
	 if (dh == MXDEF)
		  dh = sh;

	 if ((dw == sw) && (dh == sh)) {
		  mx_bitmap_blit(src, dest, sx, sy, dx, dy, dw, dh);
		  return;
	 }

	 if (dy + dh < dest->_clip.y1)
		  return;

	 if (dx + dw < dest->_clip.x1)
		  return;

	 ++sw;
	 ++sh;
	 ++dw;
	 ++dh;

	 for (y = 0; y < dh; y++) {
		  const int ddy = dy + y;

		  if (ddy > dest->_clip.y2)
				y = dh;

		  else if (ddy >= dest->_clip.y1) {
				dsti = mx_bitmap_iter(dest, dest->_clip.x1, ddy);
				srci = mx_bitmap_iter(src, sx, sy + (y * sh) / dh);

				dsti += dx - dest->_clip.x1;

				for (x = 0; x < dw; x++) {
					 const int ddx = dx + x;

					 if (ddx > dest->_clip.x2)
						  x = dw;

					 else if (ddx >= dest->_clip.x1)
						  *dsti = MXBLEND(srci[(x * sw) / dw], *dsti);

					 ++dsti;
				}
		  }
	 }
}

void mx_bitmap_blittrans(const MX_BITMAP * src, MX_BITMAP * dest, int sx, int sy, int dx, int dy, int w, int h, unsigned long trans)
{
	 int x, y;
	 MX_BITMAP_ITER srci, dsti;
	 const MX_RECT *srcarea = MXRECT(src);

	 /* Fast handling of certian transparency values */
	 if (trans == 0xff) {
		  return;

	 } else if (trans == 0) {
		  mx_bitmap_blit(src, dest, sx, sy, dx, dy, w, h);
		  return;
	 }

	 /* Handle default values */
	 if (w == MXDEF)
		  w = mx_w(src);
	 if (h == MXDEF)
		  h = mx_h(src);

	 MXASSERT(src != dest);
	 MX__CLIP_BLIT(*srcarea, dest->_clip, sx, sy, dx, dy, w, h);

	 for (y = 0; y <= h; y++) {

		  srci = mx_bitmap_iter(src, sx, sy + y);
		  dsti = mx_bitmap_iter(dest, dx, dy + y);

		  for (x = 0; x <= w; x++) {
				*dsti = MXBLENDT(*srci, *dsti, trans);
				++dsti;
				++srci;
		  }
	 }
}

#endif
#endif

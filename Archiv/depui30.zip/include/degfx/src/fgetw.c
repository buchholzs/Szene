/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#if defined(MX_LIB) || defined(MX_DEGFX_FGETW)
#ifndef MX_HAVE_DEGFX_FGETW
#define MX_HAVE_DEGFX_FGETW

#include "degfx/degfx.h"

#include <stdio.h>

int mx_fgetw(FILE * f)
{
	 int b1, b2;

	 if ((b1 = getc(f)) != EOF)
		  if ((b2 = getc(f)) != EOF)
				return ((b2 << 8) | b1);

	 return EOF;
}

#endif
#endif

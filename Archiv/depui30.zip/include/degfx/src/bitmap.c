/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#ifndef MX_HAVE_DEGFX_BITMAP
#define MX_HAVE_DEGFX_BITMAP

#include "degfx/degfx.h"

#define MX__CLIP_PIXEL(rect, xa, ya) \
   (((xa) < ((rect).x1)) ||        \
    ((xa) > ((rect).x2)) ||        \
    ((ya) < ((rect).y1)) ||        \
    ((ya) > ((rect).y2)))          \

#define MX__CLIP_BLIT(src, dest, sx, sy, dx, dy, w, h) \
do {                                                 \
    MX_RECT srca, dsta;                              \
                                                     \
    srca.x1 = (sx);                                  \
    srca.y1 = (sy);                                  \
    srca.x2 = (sx) + (w);                            \
    srca.y2 = (sy) + (h);                            \
                                                     \
    MXRECT_INTERSECT((src), srca, srca);             \
    if (!MXRECT_VALID(srca))                         \
        return;                                      \
                                                     \
    (w) = srca.x2 - srca.x1;                         \
    (h) = srca.y2 - srca.y1;                         \
                                                     \
    dsta.x1 = (dx);                                  \
    dsta.y1 = (dy);                                  \
    dsta.x2 = (dx) + (w);                            \
    dsta.y2 = (dy) + (h);                            \
                                                     \
    MXRECT_INTERSECT((dest), dsta, dsta);            \
    if (!MXRECT_VALID(dsta))                         \
        return;                                      \
                                                     \
    (w) = MXMIN((w), dsta.x2 - dsta.x1);             \
    (h) = MXMIN((h), dsta.y2 - dsta.y1);             \
                                                     \
    (sx) = srca.x1 + dsta.x1 - (dx);                 \
    (sy) = srca.y1 + dsta.y1 - (dy);                 \
    (dx) = dsta.x1;                                  \
    (dy) = dsta.y1;                                  \
                                                     \
    MXASSERT((w) >= 0);                              \
    MXASSERT((h) >= 0);                              \
    MXASSERT((sx) >= 0);                             \
    MXASSERT((sy) >= 0);                             \
    MXASSERT((dx) >= 0);                             \
    MXASSERT((dy) >= 0);                             \
} while (0)

static void mx__bitmap_destroy(void *atom)
{
	 MX_BITMAP *bitmap = (MX_BITMAP *) atom;

	 mx_free(bitmap->_array);
}

MX_BITMAP *mx_bitmap(int x2, int y2)
{
	 MX_RECT area;
	 MX_BITMAP *bitmap = (MX_BITMAP *) mx_rectatom(0, mx__bitmap_destroy, sizeof(MX_BITMAP));

	 MXNAMESET(bitmap, "bitmap");

	 area.x1 = 0;
	 area.y1 = 0;
	 area.x2 = x2;
	 area.y2 = y2;
	 mx_rectatom_place(MX__RECTATOM(bitmap), &area);

	 bitmap->_pitch = x2 + 1;
	 bitmap->_clip = *MXRECT(bitmap);
	 bitmap->_array = (MX_PIXEL *) mx_malloc((x2 + 1) * (y2 + 1) * sizeof(MX_PIXEL));
	 MXASSERT(bitmap->_array);

	 return bitmap;
}

MX_BITMAP *mx_bitmap_copy(const MX_BITMAP * other)
{
	 const int w = mx_w(other);
	 const int h = mx_h(other);
	 MX_BITMAP *bitmap = mx_bitmap(w, h);

	 MXASSERT(other);
	 MXASSERT(bitmap);

	 mx_rectatom_place(MX__RECTATOM(bitmap), MXRECT(other));

	 bitmap->_pitch = other->_pitch;
	 bitmap->_clip = other->_clip;

	 mx_bitmap_blitcopy(other, bitmap, 0, 0, 0, 0, w, h);

	 return bitmap;
}

unsigned mx_bitmap_clip(MX_BITMAP * bitmap, const MX_RECT * newclip)
{
	 if (newclip)
		  MXRECT_INTERSECT(*newclip, *MXRECT(bitmap), bitmap->_clip);
	 else
		  bitmap->_clip = *MXRECT(bitmap);

	 return MXRECT_VALID(bitmap->_clip) ? true : false;
}

const MX_RECT *mx_bitmap_clip_get(const MX_BITMAP * bitmap)
{
	 return &bitmap->_clip;
}

void mx_bitmap_offset(MX_BITMAP * bitmap, int x1, int y1)
{
	 MX_RECT area;
     /* FIX ME: Avoid modification of const values */
     int dx, dy;
   
     area = *MXRECT(bitmap);
     dx = x1 - area.x1;
     dy = y1 - area.y1;

	 area.x1 += dx;
	 area.y1 += dy;
	 area.x2 += dx;
	 area.y2 += dy;
	 mx_rectatom_place(MX__RECTATOM(bitmap), &area);

	 bitmap->_clip.x1 += dx;
	 bitmap->_clip.y1 += dy;
	 bitmap->_clip.x2 += dx;
	 bitmap->_clip.y2 += dy;
}

MX_BITMAP_ITER mx_bitmap_iter(const MX_BITMAP * bitmap, int x1, int y1)
{
	 const MX_RECT *area;

	 if (MX__CLIP_PIXEL(bitmap->_clip, x1, y1))
		  return 0;

	 area = MXRECT(bitmap);

	 return &bitmap->_array[(y1 - area->y1) * bitmap->_pitch + (x1 - area->x1)];
}

MX_BITMAP_ITER mx_bitmap_begin(const MX_BITMAP * bitmap)
{
	 return bitmap->_array;
}

MX_BITMAP_ITER mx_bitmap_end(const MX_BITMAP * bitmap)
{
	 return mx_bitmap_iter(bitmap, mx_w(bitmap), mx_h(bitmap)) + 1;
}

void mx_bitmap_blit(const MX_BITMAP * src, MX_BITMAP * dest, int sx, int sy, int dx, int dy, int w, int h)
{
	 int y;

    /* This is not necessary because the w and h are clipped to the source rect
       in the MX__CLIP_BLIT macro anyway
	 if (w == MXDEF)
		  w = mx_w(src);
	 if (h == MXDEF)
		  h = mx_h(src); */

	 MXASSERT(src != dest);

	 MX__CLIP_BLIT(*MXRECT(src), dest->_clip, sx, sy, dx, dy, w, h);

    if ((h < 0) || (w < 0))
        return;
        
	 /* Copying from one bitmap to another */
	 for (y = 0; y <= h; y++) {
   	  MX_BITMAP_ITER srci = mx_bitmap_iter(src, sx, sy + y);
   	  MX_BITMAP_ITER dsti = mx_bitmap_iter(dest, dx, dy + y);
   	  const MX_BITMAP_ITER endi = dsti + w + 1;

        while (dsti != endi) {
				*dsti = MXBLEND(*srci, *dsti);
				++dsti;
				++srci;
		  }
	 }
}

void mx_bitmap_blitcopy(const MX_BITMAP * src, MX_BITMAP * dest, int sx, int sy, int dx, int dy, int w, int h)
{
	 int y;
	 const MX_RECT *srcarea = MXRECT(src);

	 MXASSERT(src != dest);

	 if (w == MXDEF)
		  w = mx_w(src);
	 if (h == MXDEF)
		  h = mx_h(src);

	 MX__CLIP_BLIT(*srcarea, dest->_clip, sx, sy, dx, dy, w, h);

	 for (y = 0; y <= h; y++)
		  memcpy(mx_bitmap_iter(dest, dx, dy + y), mx_bitmap_iter(src, sx, sy + y), (w + 1) * sizeof(MX_PIXEL));
}

#endif

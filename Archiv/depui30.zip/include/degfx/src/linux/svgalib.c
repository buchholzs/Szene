/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#if defined(__linux__)
#if defined(MX_LIB) || defined(MX_DEGFX_LINUX_SVGALIB)
#ifndef MX_HAVE_DEGFX_LINUX_SVGALIB
#define MX_HAVE_DEGFX_LINUX_SVGALIB
#define MX_DRIVER_EXISTS

#define MX_DETK_DRS

#include "degfx/degfx.h"
#include <assert.h>
#include <vga.h>
#include <vgagl.h>
#include <vgamouse.h>
#include <vgakeyboard.h>

/* A list of the valid video modes */
typedef struct SVGALIB_MODE {
	 int mode;
	 int x, y, c;
} SVGALIB_MODE;

static SVGALIB_MODE mx__linux_svgalib_modelist[] = {
	 {G320x200x16, 320, 200, 4},
	 {G320x200x256, 320, 200, 8},
	 {G320x200x32K, 320, 200, 15},
	 {G320x200x64K, 320, 200, 16},
	 {G320x200x16M, 320, 200, 24},
	 {G320x200x16M32, 320, 200, 32},

	 {G640x480x16, 640, 480, 4},
	 {G640x480x256, 640, 480, 8},
	 {G640x480x32K, 640, 480, 15},
	 {G640x480x64K, 640, 480, 16},
	 {G640x480x16M, 640, 480, 24},
	 {G640x480x16M32, 640, 480, 32},

	 {G800x600x16, 800, 600, 4},
	 {G800x600x256, 800, 600, 8},
	 {G800x600x32K, 800, 600, 15},
	 {G800x600x64K, 800, 600, 16},
	 {G800x600x16M, 800, 600, 24},
	 {G800x600x16M32, 800, 600, 32},

	 {G1024x768x16, 1024, 768, 4},
	 {G1024x768x256, 1024, 768, 8},
	 {G1024x768x32K, 1024, 768, 15},
	 {G1024x768x64K, 1024, 768, 16},
	 {G1024x768x16M, 1024, 768, 24},
	 {G1024x768x16M32, 1024, 768, 32},

	 {0, 0, 0, 0}
};

static unsigned mx__linux_svgalib_started = false;

static unsigned mx__linux_svgalib_start(MX_GFX_ARGS * args)
{
	 int vgamode;
	 int defaultmode;
	 SVGALIB_MODE *ptr = mx__linux_svgalib_modelist;

	 if (!args->w)
		  args->w = 640;
	 if (!args->h)
		  args->h = 480;
	 if (!args->c)
		  args->c = 16;

	 if (!mx__linux_svgalib_started)
		  vga_init();
	 mx__linux_svgalib_started = true;

	 /* Find the default mode */
	 defaultmode = vga_getdefaultmode();
	 if (defaultmode == -1)
		  defaultmode = G320x200x256;

	 /* Walk down the list of modes */
	 vgamode = defaultmode;
	 while ((ptr->mode) && (vgamode == defaultmode)) {

		  /* Does it match */
		  if ((ptr->x == args->w) && (ptr->y == args->h) && (ptr->c == args->c))
				vgamode = ptr->mode;

		  ++ptr;
	 }

	 vga_setmode(vgamode);
	 gl_setcontextvga(vgamode);

	 if (COLORS == 256)
		  gl_setrgbpalette();

	 vga_setpage(0);
	 gl_enableclipping();

	 /* Reset the mouse driver */
	 vga_setmousesupport(1);

	 /* Inform the user of the results */
	 args->w = WIDTH;
	 args->h = HEIGHT;
	 args->c = BYTESPERPIXEL * 8;
	 args->title = "linux_svgalib";
	 args->pointer = false;

	 mx_drs_area(args->w - 1, args->h - 1);

	 return true;
}

static void mx__linux_svgalib_stop(void)
{
	 vga_setmousesupport(0);
	 vga_setmode(TEXT);
}

static void mx__linux_svgalib__flush(const MX_RECT * rect, MX_PIXEL * array, const int stride)
{
	 int y;

	 /* Push the buffer to the visible screen */
	 y = rect->y1;
	 while (y <= rect->y2) {
		  MX_PIXEL *src = array;
		  const MX_PIXEL *end = array + (rect->x2 - rect->x1) + 1;

		  switch (BITSPERPIXEL) {

		  case 8:{
					 unsigned char *dest = (unsigned char *) array;

					 while (src != end) {
						  *dest++ = MXRGB332(*src);
						  ++src;
					 }
					 break;
				}

		  case 24:{
					 unsigned char *dest = (unsigned char *) array;

					 while (src != end) {
						  *dest++ = MXB(*src);
						  *dest++ = MXG(*src);
						  *dest++ = MXR(*src);
						  ++src;
					 }
					 break;
				}

		  case 32:
				if (MODEFLAGS & MODEFLAG_32BPP_SHIFT8) {
					 while (src != end)
						  *src++ <<= 8;
				}
				break;

		  case 15:{
					 unsigned short *dest = (unsigned short *) array;

					 while (src != end) {
						  *dest++ = MXRGB555(*src);
						  ++src;
					 }
					 break;
				}

		  case 16:{
					 unsigned short *dest = (unsigned short *) array;

					 while (src != end) {
						  *dest++ = MXRGB565(*src);
						  ++src;
					 }
					 break;
				}

		  case 4:{
					 unsigned char v;
					 unsigned char *dest = (unsigned char *) array;

					 while (src != end) {
						  const unsigned r = MXR(*src);
						  const unsigned g = MXG(*src);
						  const unsigned b = MXB(*src);

						  v = 0;
						  if (b >= 64)
								v += 1;
						  if (g >= 64)
								v += 2;
						  if (r >= 64)
								v += 4;
						  if (b >= 192 || g >= 192 || r >= 192)
								v += 8;

						  *dest++ = v;
						  ++src;
					 }
					 break;
				}

		  default:
				break;
		  }

		  /* Flush the row */
		  vga_drawscansegment((unsigned char *) array, rect->x1, y, (rect->x2 - rect->x1 + 1) * BYTESPERPIXEL);

		  /* Next row to flush */
		  array += stride;
		  ++y;
	 }
}

static void mx__linux_svgalib_flush(MX_RECT * rect)
{
	 const int w = mx_w(mx__args.buffer);

	 /* Make the area smaller than the buffer and align the X value to 8
	    pixels so that the flush function can be simpler */
	 rect->x1 -= (rect->x1 % 8);
	 rect->x2 += 7 - (rect->x2 % 8);

	 if ((rect->x2 - rect->x1) > w) {
		  rect->x2 = rect->x1 + w;
		  rect->x2 -= ((rect->x2 + 1) % 8);
	 }

	 mx__gfx_flush(mx__linux_svgalib__flush, rect);
}

static unsigned mx__linux_svgalib_poll(void)
{
	 mx_drs_update(mx__linux_svgalib_flush);
	 return true;
}

static void mx__linux_svgalib_dirty(const MX_RECT * rect)
{
	 mx_drs_dirty(rect, true);
}

/* Some of the mouse code here has been taken from Allegro */
#define MX__MID(x,y,z)   MXMAX((x), MXMIN((y), (z)))

static unsigned mx__linux_svgalib_mouse(void)
{
	 int button;

	 /* Poll the mouse */
	 mouse_update();
	 mx__mousex = mouse_getx();
	 mx__mousey = mouse_gety();
	 button = mouse_getbutton();

	 mx__mouseb = 0;
	 if (button & MOUSE_LEFTBUTTON)
		  mx__mouseb |= 0x01;

	 /* Limit the mouse coordinates to on screen */
	 mx__mousex = MX__MID(mx__args.screen.x1, mx__mousex, mx__args.screen.x2);
	 mx__mousey = MX__MID(mx__args.screen.y1, mx__mousey, mx__args.screen.y2);
	 return true;
}

static unsigned mx__linux_svgalib_key(int *scan, long *ascii)
{
	 int lastkey;

	 /* Poll the keyboard */
	 keyboard_update();

	 lastkey = vga_getkey();
	 if (!lastkey)
		  return false;

	 *scan = 0;
	 *ascii = lastkey;
}

MX_DRIVER mx__linux_svgalib = {
	 mx__linux_svgalib_start,
	 mx__linux_svgalib_stop,

	 mx__linux_svgalib_poll,
	 mx__linux_svgalib_dirty,

	 mx__linux_svgalib_mouse,
	 mx__linux_svgalib_key
};

int main(int argc, char *argv[])
{
	 return mx_gfxmain(argc, argv);
}

#if !defined(MX_LIB) && !defined(MX__DRIVER_DEFAULT)
#define MX__DRIVER_DEFAULT
MX_DRIVER *mx__driver_default = &mx__linux_svgalib;
#endif

#endif
#endif
#endif

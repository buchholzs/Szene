/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#if defined(MX_LIB) || defined(MX_DEGFX_LOADPCX)
#ifndef MX_HAVE_DEGFX_LOADPCX
#define MX_HAVE_DEGFX_LOADPCX

#include "degfx/degfx.h"

#define MX_DEGFX_FGETW
#define MX_DEGFX_BITPIXEL

#include <stdio.h>

/* Taken from the Allegro source and extensively modified */

static MX_BITMAP *mx__bitmap_pcx(const char *filename, unsigned convert)
{
	 FILE *f;
	 MX_BITMAP *b = 0;
	 int c;
	 int width, height;
	 int bpp, bytes_per_line;
	 int x, y;
	 unsigned char pal[256][3];

	 MXASSERT(filename);

	 f = fopen(filename, "rb");
	 if (!f)
		  return 0;

	 fgetc(f);						  /* skip manufacturer ID */
	 fgetc(f);						  /* skip version flag */
	 fgetc(f);						  /* skip encoding flag */

	 if (fgetc(f) != 8)			  /* we like 8 bit color planes */
		  goto done;

	 width = -(mx_fgetw(f));	  /* xmin */
	 height = -(mx_fgetw(f));	  /* ymin */
	 width += mx_fgetw(f) + 1;	  /* xmax */
	 height += mx_fgetw(f) + 1;  /* ymax */

	 mx_fgetw(f);					  /* skip DPI values */
	 mx_fgetw(f);

	 for (c = 0; c < 16; c++) {  /* read the 16 color palette */
		  pal[c][0] = fgetc(f);
		  pal[c][1] = fgetc(f);
		  pal[c][2] = fgetc(f);
	 }

	 fgetc(f);

	 bpp = fgetc(f) * 8;			  /* how many color planes? */
	 if ((bpp != 8) && (bpp != 24))
		  goto done;

	 bytes_per_line = mx_fgetw(f);

	 for (c = 0; c < 60; c++)	  /* skip some more junk */
		  fgetc(f);

	 b = mx_bitmap(width - 1, height - 1);
	 if (!b)
		  goto done;

	 mx_bitmap_clear(b, 0);

	 for (y = 0; y < height; y++) {	/* read RLE encoded PCX data */
		  x = 0;

		  while (x < bytes_per_line * bpp / 8) {

				unsigned char ch = fgetc(f);

				if ((ch & 0xC0) == 0xC0) {
					 c = (ch & 0x3F);
					 ch = fgetc(f);

				} else
					 c = 1;

				if (bpp == 8) {
					 while (c--) {
						  if (x < width)
								mx_bitmap_pixel(b, x, y, ch);

						  x++;
					 }

				} else {
					 while (c--) {
						  const int xx = x % bytes_per_line;

						  if (xx < width) {
								const MX_PIXEL p = mx_bitmap_getpixel(b, xx, y);
								unsigned int rc = MXR(p);
								unsigned int gc = MXG(p);
								unsigned int bc = MXB(p);
								const int plane = x / bytes_per_line;

								if (plane == 0)
									 rc = ch;

								else if (plane == 1)
									 gc = ch;

								else if (plane == 2)
									 bc = ch;

								mx_bitmap_pixel(b, xx, y, MXRGB(rc, gc, bc));
						  }
						  ++x;
					 }
				}
		  }
	 }

	 /* look for a 256 color palette */
	 if (bpp == 8) {
		  while ((c = fgetc(f)) != EOF) {
				if (c == 12) {
					 for (c = 0; c < 256; c++) {
						  pal[c][0] = fgetc(f);
						  pal[c][1] = fgetc(f);
						  pal[c][2] = fgetc(f);
					 }
					 break;
				}
		  }
	 }

	 if ((bpp == 8) && (convert)) {
		  MX_BITMAP_ITER start = mx_bitmap_begin(b);
		  const MX_BITMAP_ITER end = mx_bitmap_end(b);

		  while (start != end) {
				const unsigned r = pal[*start][0];
				const unsigned g = pal[*start][1];
				const unsigned b = pal[*start][2];

				*start++ = MXRGB(r, g, b);
		  }
	 }

  done:
	 fclose(f);
	 return b;
}

MX_BITMAP *mx_bitmap_pcx(const char *filename)
{
	 return mx__bitmap_pcx(filename, true);
}

MX_BITMAP *mx_bitmap_pcx_greyscale(const char *filename)
{
	 MX_BITMAP *b = mx__bitmap_pcx(filename, false);

	 if (b) {
		  MX_BITMAP_ITER start = mx_bitmap_begin(b);
		  const MX_BITMAP_ITER end = mx_bitmap_end(b);

		  while (start != end) {
				*start = MXRGB(*start, *start, *start);
				++start;
		  }
	 }
	 return b;
}

#endif
#endif

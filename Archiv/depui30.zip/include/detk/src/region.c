/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#if defined(MX_LIB) || defined(MX_DETK_REGION)
#ifndef MX_HAVE_DETK_REGION
#define MX_HAVE_DETK_REGION

#define MX_DETK_VECTOR

#include "detk/detk.h"

void mx_region_clip(MX_REGION * region, const MX_RECT * therect)
{
	 unsigned int i;
	 unsigned int num = mx_vector_size(region);
     /* FIX ME: Avoid modification of const */
	 MX_RECT rect;

     rect = *therect;
	 MXASSERT(region);
	 MXASSERT(therect);

	 if (!MXRECT_VALID(rect))
		  return;

	 /* Make a list of intersecting rectangles */
	 for (i = 0; i < num; i++) {
		  MX_RECT s = region->data[i];
		  MX_RECT trial;

		  MXRECT_INTERSECT(s, rect, trial);
		  if (MXRECT_VALID(trial)) {

				/* Remove the intersecting rectangles */
				mx_vector_remove(region, i, 1);
				--i, --num;

				/* Add to a temp list of the clipped rectangles */
				MX__TOP_RECTS(s, rect, trial);
				if (MXRECT_VALID(trial))
					 mx_vector_append(region, &trial, 1);

				MX__LEFT_RECTS(s, rect, trial);
				if (MXRECT_VALID(trial))
					 mx_vector_append(region, &trial, 1);

				MX__RIGHT_RECTS(s, rect, trial);
				if (MXRECT_VALID(trial))
					 mx_vector_append(region, &trial, 1);

				MX__BOT_RECTS(s, rect, trial);
				if (MXRECT_VALID(trial))
					 mx_vector_append(region, &trial, 1);
		  }
	 }
}

#endif
#endif

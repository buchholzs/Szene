/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#if defined(MX_LIB) || defined(MX_DETK_BASENAME)
#ifndef MX_HAVE_DETK_BASENAME
#define MX_HAVE_DETK_BASENAME

#include "detk/detk.h"

/* Taken from the DJGPP sources since not all platforms have this */

const char *mx_basename(const char *fname)
{
	 const char *base = fname;

	 if (fname && *fname) {
		  if (fname[1] == ':') {
				fname += 2;
				base = fname;
		  }

		  while (*fname) {
				if (*fname == '\\' || *fname == '/')
					 base = fname + 1;
				fname++;
		  }
	 }
	 return base;
}

#endif
#endif

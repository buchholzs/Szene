/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#if defined(MX_LIB) || defined(MX_DETK_VECTOR)
#ifndef MX_HAVE_DETK_VECTOR
#define MX_HAVE_DETK_VECTOR

#include "detk/detk.h"

#include <stdlib.h>
#include <string.h>

void mx__vector(MX_VECTOR * ptr)
{
	 MXASSERT(ptr);

	 ptr->_data = 0;
	 ptr->_size = 0;
	 ptr->_capacity = 0;
}

void mx__vector_set(MX_VECTOR * ptr, void *data, const unsigned int n, unsigned int owns)
{
	 MXASSERT(ptr);
	 MXASSERT((data) ? n : 1);
	 MXASSERT((n) ? (int) data : 1);

	 if ((ptr->_data) && (ptr->_data != data))
		  mx__vector_free(ptr);

	 ptr->_data = data;
	 ptr->_size = n;
	 ptr->_capacity = n;

	 if (!owns)
		  ptr->_capacity *= -1;
}

void mx__vector_free(MX_VECTOR * ptr)
{
	 MXASSERT(ptr);

	 if ((ptr->_capacity > 0) && (ptr->_data))
		  mx_free(ptr->_data);

	 ptr->_data = 0;
	 ptr->_size = 0;
	 ptr->_capacity = 0;
}

void mx__vector_reserve(MX_VECTOR * ptr, const unsigned int newsize, const size_t sizeofdata)
{
	 MXASSERT(ptr);
	 MXASSERT(sizeofdata);

	 /* Do we need more room */
	 if (newsize > (unsigned int) ptr->_capacity) {

		  /* Reallocate to make enough room */
		  if (ptr->_capacity > 0) {
				ptr->_data = mx_realloc(ptr->_data, newsize * sizeofdata);
				ptr->_capacity = newsize;

				/* We don't own the data, we must make a copy to make room */
		  } else {
				void *olddata = ptr->_data;

				ptr->_data = mx_malloc(newsize * sizeofdata);
				ptr->_capacity = newsize;
				memcpy(ptr->_data, olddata, ptr->_size * sizeofdata);
		  }
	 }
}

void mx__vector_resize(MX_VECTOR * ptr, const unsigned int newsize, const size_t sizeofdata)
{
	 MXASSERT(ptr);
	 MXASSERT(sizeofdata);

	 mx__vector_reserve(ptr, newsize, sizeofdata);
	 ptr->_size = newsize;
}

void mx__vector_contract(MX_VECTOR * ptr, const size_t sizeofdata)
{
	 MXASSERT(ptr);
	 MXASSERT(sizeofdata);

	 /* We do nothing if we don't own the buffer */
	 if (ptr->_capacity <= 0)
		  return;

	 /* Contract the memory just to fit the real data */
	 if (ptr->_size) {
		  ptr->_data = mx_realloc(ptr->_data, ptr->_size * sizeofdata);

		  /* We have no real data, only allocated room, so free everything */
	 } else {
		  mx_free(ptr->_data);
		  ptr->_data = 0;
	 }
	 ptr->_capacity = ptr->_size;
}

void *mx__vector_append(MX_VECTOR * ptr, const void *data, const unsigned int num, const size_t sizeofdata)
{
	 char *ret;
	 const unsigned int size = ptr->_size + num;

	 MXASSERT(ptr);
	 MXASSERT(num);
	 MXASSERT(sizeofdata);

	 /* Do we need to make more room */
	 if (size > (unsigned int) abs(ptr->_capacity))
		  mx__vector_reserve(ptr, 2 * size, sizeofdata);

	 ret = (char *) (ptr->_data) + ptr->_size * sizeofdata;

	 /* Copy the data over and update the size */
	 memcpy(ret, data, num * sizeofdata);
	 ptr->_size = size;

	 return ret;
}

void *mx__vector_insert(MX_VECTOR * ptr, const void *data, const unsigned int num, const unsigned int place, const size_t sizeofdata)
{
	 char *ret;
	 const unsigned int size = ptr->_size + num;
	 const unsigned int index = (place < ptr->_size) ? place : ptr->_size - 1;
	 const unsigned int offset = index * sizeofdata;
	 const unsigned int databytes = num * sizeofdata;

	 MXASSERT(ptr);
	 MXASSERT(sizeofdata);

	 /* Do we need to make more room */
	 if (size > (unsigned int) ptr->_capacity)
		  mx__vector_reserve(ptr, 2 * size, sizeofdata);

	 ret = (char *) (ptr->_data) + offset;

	 /* Copy the data over and update the size */
	 memmove(ret + databytes, ret, ptr->_size * sizeofdata - offset);
	 memcpy(ret, data, databytes);
	 ptr->_size = size;

	 return ret;
}

void mx__vector_remove(MX_VECTOR * ptr, const unsigned int index, /* const */ unsigned int num, const size_t sizeofdata)
{
	 MXASSERT(ptr);
	 MXASSERT(sizeofdata);

	 if (index < ptr->_size) {
		  char *begin = (char *) ptr->_data + index * sizeofdata;
		  char *end = (char *) ptr->_data + ptr->_size * sizeofdata;
		  const size_t bytes = end - begin - num * sizeofdata;

		  /* Put limits on the number of elements to be removed */
		  if ((index + num) > ptr->_size)
                /* FIX ME: Don't modify const */
				num = ptr->_size - index;

		  /* Copy remaining values down */
		  if (bytes)
				memmove(begin, begin + num * sizeofdata, bytes);

		  /* Adjust the size */
		  ptr->_size -= num;
	 }
}

#endif
#endif

/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#if defined(MX_LIB) || defined(MX_DETK_DRS)
#ifndef MX_HAVE_DETK_DRS
#define MX_HAVE_DETK_DRS

#define MX_DETK_REGION

#include "detk/detk.h"

#define REGION_CHUNK 64

static MX_RECT mx__drs_area;
static unsigned mx__drs_started = false;
static unsigned mx__drs_dirtychanged = false;
static MX_REGION mx__drs_dirtyinverse = { {0, 0, 0} };
static MX_REGION mx__drs_dirty = { {0, 0, 0} };

static void mx__drs_stop(void)
{
	 if (mx__drs_dirtyinverse.data)
		  mx_vector_free(&mx__drs_dirtyinverse);

	 if (mx__drs_dirty.data)
		  mx_vector_free(&mx__drs_dirty);

	 mx__drs_started = false;
}

static void mx__drs_start(void)
{
	 MXASSERT(!mx__drs_started);

	 mx_vector(&mx__drs_dirtyinverse);
	 mx_vector_reserve(&mx__drs_dirtyinverse, REGION_CHUNK);

	 mx_vector(&mx__drs_dirty);
	 mx_vector_reserve(&mx__drs_dirty, REGION_CHUNK);

	 atexit(mx__drs_stop);
	 mx__drs_started = true;
}

void mx_drs_area(int w, int h)
{
	 if (!mx__drs_started)
		  mx__drs_start();

	 mx__drs_area.x1 = 0;
	 mx__drs_area.y1 = 0;
	 mx__drs_area.x2 = w;
	 mx__drs_area.y2 = h;

	 mx_vector_resize(&mx__drs_dirtyinverse, 0);
	 mx__drs_dirtychanged = true;
}

unsigned mx_drs_update(MX_FLUSH_FUNC flush)
{
	 unsigned int i;
	 unsigned drawn = false;
	 unsigned int size;

	 if (!mx__drs_started)
		  mx__drs_start();

	 if (!mx__drs_dirtychanged)
		  return false;

	 /* Invert the dirty area before display */
	 mx_vector_resize(&mx__drs_dirty, 0);
	 mx_vector_reserve(&mx__drs_dirty, REGION_CHUNK);
	 mx_vector_append(&mx__drs_dirty, &mx__drs_area, 1);

	 size = mx_vector_size(&mx__drs_dirtyinverse);
	 for (i = 0; i < size; i++) {
		  const MX_RECT *rect = &mx__drs_dirtyinverse.data[i];

		  mx_region_clip(&mx__drs_dirty, rect);
	 }

	 /* Keep at least some places allocated so updating goes fast. If this is
	    done before the actual redraw/flush call then we can call mx_drs_dirty 
	    inside an expose event without causing the update to get lost or
	    create an infinite loop. */
	 mx_vector_resize(&mx__drs_dirtyinverse, REGION_CHUNK);
	 mx_vector_contract(&mx__drs_dirtyinverse);
	 mx_vector_resize(&mx__drs_dirtyinverse, 0);
	 mx_vector_append(&mx__drs_dirtyinverse, &mx__drs_area, 1);
	 mx__drs_dirtychanged = false;

	 /* Update the areas one by one */
	 while ((size = mx_vector_size(&mx__drs_dirty)) != 0) {
		  MX_RECT rect = mx__drs_dirty.data[size - 1];

		  if (flush)
				flush(&rect);

		  /* We have to clip here instead of just remove because the buffer
		     might have been smaller than the rect to update */
		  mx_region_clip(&mx__drs_dirty, &rect);
		  drawn = true;
	 }

	 return drawn;
}

void mx_drs_dirty(const MX_RECT * rect, unsigned mark)
{
	 if (!mx__drs_started)
		  mx__drs_start();

	 MXASSERT(rect);

	 /* Clip from the inverse means to mark as dirty */
	 if (mark)
		  mx_region_clip(&mx__drs_dirtyinverse, rect);

	 /* Add to inverse means mark as clean */
	 else
		  mx_vector_append(&mx__drs_dirtyinverse, rect, 1);

	 mx__drs_dirtychanged = true;
}

#endif
#endif

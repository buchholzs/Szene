/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#if defined(MX_LIB) || defined(MX_DETK_RECTATOM)
#ifndef MX_HAVE_DETK_RECTATOM
#define MX_HAVE_DETK_RECTATOM

#define MX_DETK_ATOM

#include "detk/detk.h"

void *mx_rectatom(MX_RECTATOM * rectatom, MX__ATOM_DESTRUCT destruct, size_t size)
{
	 if (size < sizeof(MX_RECTATOM))
		  size = sizeof(MX_RECTATOM);

	 return mx_atom(MX__ATOM(rectatom), destruct, size);
}

void mx_rectatom_place(MX_RECTATOM * rectatom, const MX_RECT * rect)
{
	 rectatom->_rect = *rect;
}

#endif
#endif

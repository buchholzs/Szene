/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#if defined(MX_LIB) || defined(MX_DETK_ATOM)
#ifndef MX_HAVE_DETK_ATOM
#define MX_HAVE_DETK_ATOM

#include "detk/detk.h"

#include <string.h>

void *mx__atom(MX_ATOM * atom, MX__ATOM_DESTRUCT destruct, size_t datasize)
{
	 unsigned allocated = false;

	 if (datasize < sizeof(MX_ATOM))
		  datasize = sizeof(MX_ATOM);

	 if (!atom) {
		  atom = (MX_ATOM *) mx_malloc(datasize);
		  allocated = true;
	 }

	 memset(atom, 0, datasize);
	 atom->_destruct = destruct;
	 atom->_allocated = allocated;

#ifdef MX_DETK_ATOM_DEBUG
	 fprintf(stderr, "Atom is %p\n", atom);
	 atom->name = "atom";
#endif

	 return atom;
}

void mx__atom_delete(MX_ATOM * atom)
{
	 if (!atom)
		  return;

	 MXASSERT(atom);

	 if (atom->_flag)
		  return;

	 atom->_flag = true;

	 if (atom->_lock)
		  return;

#ifdef MX_DETK_ATOM_DEBUG
	 fprintf(stderr, "delete atom %s\n", atom->name);
#endif

	 if (atom->_destruct) {
		  MX__ATOM_DESTRUCT destruct = atom->_destruct;

		  atom->_destruct = 0;

		  destruct(atom);
	 }

	 if (atom->_allocated)
		  mx_free(atom);
}

void mx__atom_lock(MX_ATOM * atom)
{
	 MXASSERT(atom);

	 ++atom->_lock;
}

unsigned mx__atom_unlock(MX_ATOM * atom)
{
	 unsigned didit = false;

	 MXASSERT(atom);

	 if (atom->_lock)
		  --atom->_lock;

	 if ((atom->_lock == 0) && (atom->_flag)) {
		  if (atom->_destruct) {
				MX__ATOM_DESTRUCT destruct = atom->_destruct;

				atom->_destruct = 0;

				destruct(atom);
		  }

		  if (atom->_allocated)
				mx_free(atom);

		  didit = true;
	 }
	 return didit;
}

#endif
#endif

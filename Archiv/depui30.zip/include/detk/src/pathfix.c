/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#if defined(MX_LIB) || defined(MX_DETK_PATHFIX)
#ifndef MX_HAVE_DETK_PATHFIX
#define MX_HAVE_DETK_PATHFIX

#include "detk/detk.h"

#include <string.h>

void mx_path_fix(char *ptr)
{
	 char *next;
    unsigned start = true;

	 MXASSERT(ptr);

#ifdef __MSDOS__
	 /* Ignore leading drive specs   */
	 if (ptr[1] == ':') {
		  ptr += 2;
		  if (*ptr == '/')
				++ptr;
	 }
#endif

	 /* Find slashes */
	 next = strchr(ptr, '/');
	 if (next)
		  ++next;

	 /* Look for updirs */
	 while ((ptr) && (next)) {

		  /* Is the following dir an updir, and the previous one not  */
		  if ((next[0] == '.') && (next[1] == '.') && (ptr[0] != '.') && (ptr[1] != '.'))
				strcpy(ptr, next + 3);

		  /* Remove /./ combinations except at the start */
		  else if ((ptr[0] == '.') && (ptr[1] == '/') && (ptr + 2 == next) && (!start))
				strcpy(ptr, ptr + 2);

		  /* Look at the next slashes */
		  else
				ptr = next;

		  next = strchr(ptr, '/');
		  if (next)
				++next;

        start = false;
	 }
}

#endif
#endif

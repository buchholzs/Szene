/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#if defined(MX_LIB) || defined(MX_DETK_STRING)
#ifndef MX_HAVE_DETK_STRING
#define MX_HAVE_DETK_STRING

#include "detk/detk.h"

#include <string.h>

void mx_string(MX_STRING * string)
{
	 memset(string, 0, sizeof(*string));
}

void mx_string_free(MX_STRING * string)
{
	 if ((string->_text) && (string->_free))
		  string->_free((void *) string->_text);

	 memset(string, 0, sizeof(*string));
}

void mx_string_set(MX_STRING * string, const char *text, long len, MX_FREE free)
{
	 if ((string->_text) && (string->_free) && (string->_text != text))
		  string->_free((void *) string->_text);

	 string->_text = text;
	 string->_len = len;
	 string->_free = free;
}

const char *mx_string_text(const MX_STRING * string, long *len)
{
	 if (len)
		  *len = string->_len;

	 return string->_text;
}

#endif
#endif

/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#if defined(MX_LIB) || defined(MX_DETK_RECT)
#ifndef MX_HAVE_DETK_RECT
#define MX_HAVE_DETK_RECT

#include "detk/detk.h"

void mx_rect_move(MX_RECT * rect, int x, int y)
{
	 const int w = rect->x2 - rect->x1;
	 const int h = rect->y2 - rect->y1;

	 rect->x1 = x;
	 rect->y1 = y;
	 rect->x2 = x + w;
	 rect->y2 = y + h;
}

void mx_rect_resize(MX_RECT * rect, int w, int h)
{
	 rect->x2 = rect->x1 + w;
	 rect->y2 = rect->y1 + h;
}

#endif
#endif

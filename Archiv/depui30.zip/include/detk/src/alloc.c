/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#if defined(MX_LIB) || defined(MX_DETK_ALLOC)
#ifndef MX_HAVE_DETK_ALLOC
#define MX_HAVE_DETK_ALLOC

#include "detk/detk.h"
#include <stdio.h>

typedef union align {
	 char a;
	 unsigned char b;
	 short c;
	 unsigned short d;
	 int e;
	 unsigned int f;
	 long g;
	 unsigned long h;
	 float i;
	 double j;
	 char dat[2];
} align;

#define FENCE_SIZE 32

typedef struct fencet {
	 unsigned char data[FENCE_SIZE];
} fencet;

typedef struct memory {
	 align _aligned;

	 size_t bytes;

	 struct memory *next;
	 struct memory *prev;

	 fencet fence;
} memory;

/* Memory list */
static unsigned int started = 0;
static memory *last = 0;

unsigned int mx__toolkit_bytes = 0;
unsigned int mx__toolkit_allocs = 0;

#define memoryCast(ptr)     (((memory*)(ptr)) - 1)

void memory_print(void)
{
	 memory *ptr = last;

	 if (last)
		  fprintf(stderr, "---Memory---\n");

	 while (ptr) {
		  fprintf(stderr, "   %i bytes at %p\n", (int) ptr->bytes, (void *) (ptr + 1));
		  ptr = ptr->prev;
	 }

	 if (last)
		  fprintf(stderr, "---Done---\n");
}

static memory *memory_find(memory * mem)
{
	 memory *ptr = last;

	 while (ptr) {
		  if (ptr == mem)
				return ptr;

		  ptr = ptr->prev;
	 }

	 /* No match in memory */
	 fprintf(stderr, "!!! Gah! Invalid memory %p\n", (void *) (mem + 1));
	 abort();

	 /* Never get here */
	 return 0;
}

static void memory_add(memory * mem)
{
	 mem->prev = last;
	 mem->next = 0;
	 if (last)
		  last->next = mem;
	 last = mem;
}

static void memory_remove(memory * mem)
{
	 memory_find(mem);

	 if (last == mem)
		  last = mem->prev;

	 if (mem->next)
		  mem->next->prev = mem->prev;
	 if (mem->prev)
		  mem->prev->next = mem->next;

	 mem->prev = 0;
	 mem->next = 0;
}

/* Filling with fences with random data and then checking that the random
   data doesnt change.  We need our own RNG or we would screwup others use
   of rand() becuase of frequent seed changes */
static unsigned long SEED = 93186752;
static unsigned char RANDOM(void)
{
	 SEED = 1588635695 * (SEED % 2) - 1117695901 * (SEED / 2);
	 return SEED & 0xff;
}

static void memory_rand(void *mem, size_t bytes)
{
	 unsigned int i = 0;
	 unsigned char *ptr = (unsigned char *) mem;

	 while (i < bytes)
		  ptr[i++] = RANDOM();
}

static void fence_init(memory * mem)
{
	 int i;
	 fencet *myfence = &mem->fence;

	 /* Fence at the beginning */
	 SEED = (unsigned long) myfence;

	 for (i = 0; i < FENCE_SIZE; i++)
		  myfence->data[i] = RANDOM();

	 /* Fence at the end */
	 myfence = (fencet *) ((unsigned char *) (mem + 1) + mem->bytes);
	 SEED = (unsigned long) myfence;
	 for (i = 0; i < FENCE_SIZE; i++)
		  myfence->data[i] = RANDOM();
}

static void fence_check(memory * mem)
{
	 int i;
	 fencet *myfence = &mem->fence;

	 /* Fence at the beginning */
	 SEED = (unsigned long) myfence;
	 for (i = 0; i < FENCE_SIZE; i++) {
		  if (myfence->data[i] != RANDOM()) {
				fprintf(stderr, "!!! Fence (lower) damaged %p\n", (void *) (mem + 1));
				MXASSERT(0);
		  }
	 }

	 /* Fence at the end */
	 myfence = (fencet *) ((unsigned char *) (mem + 1) + mem->bytes);
	 SEED = (unsigned long) myfence;
	 for (i = 0; i < FENCE_SIZE; i++) {
		  if (myfence->data[i] != RANDOM()) {
				fprintf(stderr, "!!! Fence (upper) damaged %p\n", (void *) (mem + 1));
				MXASSERT(0);
		  }
	 }
}

void mx__fencecheck(void)
{
	 memory *ptr = last;

	 while (ptr) {
		  fence_check(ptr);
		  ptr = ptr->prev;
	 }
}

void *mx__malloc(size_t bytes)
{
	 memory *mem = (memory *) malloc(sizeof(memory) + bytes + sizeof(fencet));

	 MXASSERT(mem);
	 MXASSERT(bytes);

	 if (started == 0) {
		  atexit(memory_print);
		  started = 1;
	 }
	 mx__toolkit_bytes += bytes;
	 ++mx__toolkit_allocs;

	 mem->bytes = bytes;
	 memory_add(mem);
	 fence_init(mem);
	 memory_rand(mem + 1, bytes);

#ifdef MX_DETK_ALLOC_LOG
	 fprintf(stderr, "malloc  %i at %p\n", (int) bytes, (void *) (mem + 1));
#endif

	 mx__fencecheck();

	 return mem + 1;
}

void *mx__realloc(void *themem, size_t bytes)
{
	 memory *newmem;

	 memory *oldmem = memoryCast(themem);

	 fence_check(oldmem);
	 memory_remove(oldmem);
	 mx__toolkit_bytes -= oldmem->bytes;
	 --mx__toolkit_allocs;

	 MXASSERT(themem);
	 MXASSERT(bytes);

	 newmem = (memory *) realloc(oldmem, sizeof(memory) + bytes + sizeof(fencet));
	 newmem->bytes = bytes;

	 MXASSERT(newmem);

	 memory_add(newmem);
	 fence_init(newmem);
	 mx__toolkit_bytes += bytes;
	 ++mx__toolkit_allocs;

#ifdef MX_DETK_ALLOC_LOG
	 fprintf(stderr, "realloc %i at %p from %p\n", (int) bytes, (void *) (newmem + 1), (void *) (oldmem + 1));
#endif

	 mx__fencecheck();

	 return newmem + 1;
}

void mx__free(void *themem)
{
	 memory *mem = memoryCast(themem);

#ifdef MX_DETK_ALLOC_LOG
	 fprintf(stderr, "free    %i at %p\n", (int) mem->bytes, themem);
#endif

	 mx__fencecheck();

	 MXASSERT(themem);

	 fence_check(mem);
	 memory_remove(mem);
	 mx__toolkit_bytes -= mem->bytes;
	 --mx__toolkit_allocs;

	 /* Randomize all memory, even the header and fences */
	 memory_rand(mem, sizeof(memory) + mem->bytes + sizeof(fencet));

	 free(mem);
}

#endif
#endif

/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

/* Bring in the DETK files */
#include "detk/src/rectatom.c"
#include "detk/src/atom.c"
#include "detk/src/alloc.c"
#include "detk/src/drs.c"
/*#include "detk/src/damage.c"*/
#include "detk/src/rect.c"
#include "detk/src/region.c"
#include "detk/src/string.c"
#include "detk/src/utf8.c"
#include "detk/src/vector.c"
#include "detk/src/basename.c"
#include "detk/src/match.c"
#include "detk/src/pathfix.c"

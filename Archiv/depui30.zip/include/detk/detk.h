/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#ifndef MX_DETK_HEADER
#define MX_DETK_HEADER

#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* General defines ---------------------------------------------------------*/
#define MX_DETK_VERSION 1
#define MX_DETK_SUBVERSION 0

/* Some useful macros for booleans */
#ifndef true
#define false     (0)
#define true      (~(false))
#endif
/* Handly marker for default vaues */
#define MXDEF             (0x7fffffffl)
#if defined(__MSDOS__) && defined(__TURBOC__)
#undef MXDEF
#define MXDEF             (0x7fff)
#endif
/* Make our own max/min to avoid conflicts with other libs */
#define MXMIN(x,y)     (((x) < (y)) ? (x) : (y))
#define MXMAX(x,y)     (((x) > (y)) ? (x) : (y))
/* Debugging defines -------------------------------------------------------*//* If we are debugging, make sure the right modules are included */
#if defined(DEBUG)
#include <assert.h>
#define MXASSERT(a) do { assert(a); } while (0)
#define MX_DETK_ALLOC
#define MX_DETK_ALLOC_LOG
/* #define MX_DETK_VECTOR_DEBUG *//* #define MX_DETK_ATOM_DEBUG *//* If we are not debugging, make sure the debug modules are excluded */
#elif !defined(NDEBUG)
#define MXASSERT(a) { }
#undef  MX_DETK_ALLOC
#undef  MX_DETK_ALLOC_LOG
#undef  MX_DETK_VECTOR_DEBUG
#undef  MX_DETK_ATOM_DEBUG
/* No debugging flags set, so keep assertions, but do no special debugging */
#else
#include <assert.h>
#define MXASSERT(a) do { assert(a); } while (0)
#undef MX_DETK_ALLOC
#undef MX_DETK_ALLOC_LOG
#undef MX_DETK_VECTOR_DEBUG
#undef MX_DETK_ATOM_DEBUG
#endif
/* If we want to log memory allocs, we are debugging */
#ifdef MX_DETK_ALLOC_LOG
#define MX_DETK_ALLOC
#endif
/* Memory allocation -------------------------------------------------------*/ void *mx__malloc(size_t bytes);
	 void *mx__realloc(void *themem, size_t bytes);
	 void mx__free(void *themem);
	 void mx__fencecheck(void);

/* No memory debugging */
#if defined(NDEBUG)
#define mx_malloc          malloc
#define mx_realloc         realloc
#define mx_free            free

/* With memory debugging and logging */
#elif defined(MX_DETK_ALLOC_LOG)
#include <stdio.h>
#define mx_malloc          (fprintf(stderr, "malloc called:  %s %i\n: ", __FILE__, __LINE__), mx__malloc)
#define mx_realloc         (fprintf(stderr, "realloc called: %s %i\n: ", __FILE__, __LINE__), mx__realloc)
#define mx_free            (fprintf(stderr, "free called:    %s %i\n: ", __FILE__, __LINE__), mx__free)

/* With memory debugging */
#elif defined(MX_DETK_ALLOC)
#define mx_malloc          mx__malloc
#define mx_realloc         mx__realloc
#define mx_free            mx__free

/* No memory debugging */
#else
#define mx_malloc          malloc
#define mx_realloc         realloc
#define mx_free            free
#endif

/* ---------------------------------------------------------------------------
   MxVector is a (almost) typesafe C vector object
   To use it you make a struct to contain the type that you want:

typedef union {
   MX_VECTOR vector;
   MYTYPE* data;
} MYVECTOR;

   MX_VECTOR is bit-copy-correct which means that a binary copy retains
   proper functioning and takes over ownership of internal buffers.

   This means that memory containing a vector can be realloc'd.
   Therefore a vector can be used inside another MX_VECTOR.
*/
	 typedef struct MX_VECTOR {
		  void *_data;				  /* Must be first to match with the users data 
										   */
		  unsigned int _size;
		  int _capacity;
	 } MX_VECTOR;

	 void mx__vector(MX_VECTOR * vect);
	 void mx__vector_free(MX_VECTOR * vect);

	 void mx__vector_set(MX_VECTOR * vect, void *data, const unsigned int n, unsigned int owns);

	 void mx__vector_resize(MX_VECTOR * vect, const unsigned int newsize, const size_t sizeofdata);
	 void mx__vector_reserve(MX_VECTOR * vect, const unsigned int newsize, const size_t sizeofdata);
	 void mx__vector_contract(MX_VECTOR * vect, const size_t sizeofdata);

	 void *mx__vector_append(MX_VECTOR * vect, const void *data, const unsigned int num, const size_t sizeofdata);
	 void *mx__vector_insert(MX_VECTOR * vect, const void *data, const unsigned int num, const unsigned int place,
									 const size_t sizeofdata);
     /* FIX ME: num is modified */
	 void mx__vector_remove(MX_VECTOR * vect, const unsigned int index, /* const */ unsigned int num, const size_t sizeofdata);

#define mx_vector_size(v)     ((const int)(v)->vector._size)
#define mx_vector_capacity(v) ((const int)abs((v)->vector._capacity))

/* With vector debugging */
#if defined(MX_DETK_VECTOR_DEBUG) && !defined(NDEBUG)
#define mx_vector(a)                  (fprintf(stderr, "Vec construct at %s, %i    \n", __FILE__, __LINE__), mx__vector(&(a)->vector))
#define mx_vector_free(a)             (fprintf(stderr, "Vec free at %s, %i         \n", __FILE__, __LINE__), mx__vector_free(&(a)->vector))
#define mx_vector_set(a,b,c,d)        (fprintf(stderr, "Vec dataset at %s, %i      \n", __FILE__, __LINE__), mx__vector_set(&(a)->vector,b,c,d,sizeof(*(a)->data)))
#define mx_vector_resize(a,b)         (fprintf(stderr, "Vec resize at %s, %i       \n", __FILE__, __LINE__), mx__vector_resize(&(a)->vector,b,sizeof(*(a)->data)))
#define mx_vector_reserve(a,b)        (fprintf(stderr, "Vec reserve at %s, %i      \n", __FILE__, __LINE__), mx__vector_reserve(&(a)->vector,b,sizeof(*(a)->data)))
#define mx_vector_contract(a)         (fprintf(stderr, "Vec contract at %s, %i     \n", __FILE__, __LINE__), mx__vector_contract(&(a)->vector,sizeof(*(a)->data)))
#define mx_vector_append(a,b,c)       (fprintf(stderr, "Vec append at %s, %i => %i \n", __FILE__, __LINE__, mx_vector_size(a)), mx__vector_append(&(a)->vector,b,c,sizeof(*(a)->data)))
#define mx_vector_insert(a,b,c,d)     (fprintf(stderr, "Vec insert at %s, %i => %i \n", __FILE__, __LINE__, mx_vector_size(a)), mx__vector_insert(&(a)->vector,b,c,d,sizeof(*(a)->data)))
#define mx_vector_remove(a,b,c)       (fprintf(stderr, "Vec remove at %s, %i => %i \n", __FILE__, __LINE__, mx_vector_size(a)), mx__vector_remove(&(a)->vector,b,c,sizeof(*(a)->data)))

/* No vector debugging */
#else
#define mx_vector(a)                  mx__vector(&(a)->vector)
#define mx_vector_free(a)             mx__vector_free(&(a)->vector)
#define mx_vector_set(a,b,c,d)        mx__vector_set(&(a)->vector,b,c,d,sizeof(*(a)->data))
#define mx_vector_resize(a,b)         mx__vector_resize(&(a)->vector,b,sizeof(*(a)->data))
#define mx_vector_reserve(a,b)        mx__vector_reserve(&(a)->vector,b,sizeof(*(a)->data))
#define mx_vector_contract(a)         mx__vector_contract(&(a)->vector,sizeof(*(a)->data))
#define mx_vector_append(a,b,c)       mx__vector_append(&(a)->vector,b,c,sizeof(*(a)->data))
#define mx_vector_insert(a,b,c,d)     mx__vector_insert(&(a)->vector,b,c,d,sizeof(*(a)->data))
#define mx_vector_remove(a,b,c)       mx__vector_remove(&(a)->vector,b,c,sizeof(*(a)->data))
#endif

/*----------------------------------------------------------------------------
  Rectangles and convenience macros
*/
	 typedef struct MX_RECT {
		  int x1;
		  int y1;
		  int x2;
		  int y2;
	 } MX_RECT;

	 void mx_rect_move(MX_RECT * rect, int x, int y);
	 void mx_rect_resize(MX_RECT * rect, int w, int h);

#define MXRECT_VALID(A)  \
   (((A).x2 >= (A).x1)&& \
    ((A).y2 >= (A).y1))

#define MXRECT_INTERSECT(A, B, R)      \
   do {                                \
       (R).x1 = MXMAX((A).x1, (B).x1); \
       (R).y1 = MXMAX((A).y1, (B).y1); \
       (R).x2 = MXMIN((A).x2, (B).x2); \
       (R).y2 = MXMIN((A).y2, (B).y2); \
   } while (0)

#define MXRECT_UNION(A, B, R)          \
   do {                                \
       (R).x1 = MXMIN((A).x1, (B).x1); \
       (R).y1 = MXMIN((A).y1, (B).y1); \
       (R).x2 = MXMAX((A).x2, (B).x2); \
       (R).y2 = MXMAX((A).y2, (B).y2); \
   } while (0)

#define MXRECT_CONTAINS(R, X, Y) \
   ((X >= (R).x1) &&             \
    (X <= (R).x2) &&             \
    (Y >= (R).y1) &&             \
    (Y <= (R).y2))

#define MXRECTS_OVERLAP(A, B) \
   (!(((B).x1 > (A).x2) ||    \
      ((B).y1 > (A).y2) ||    \
      ((B).x2 < (A).x1) ||    \
      ((B).y2 < (A).y1)))

#define MX__TOP_RECTS(A, B, R)        \
   (R).x1 = (A).x1;                   \
   (R).y1 = (A).y1;                   \
   (R).x2 = (A).x2;                   \
   (R).y2 = MXMIN( (B).y1-1, (A).y2 )

#define MX__LEFT_RECTS(A, B, R)        \
   (R).x1 = (A).x1;                    \
   (R).y1 = MXMAX( (B).y1, (A).y1 );   \
   (R).x2 = MXMIN( (B).x1-1, (A).x2 ); \
   (R).y2 = MXMIN( (B).y2, (A).y2 )

#define MX__RIGHT_RECTS(A, B, R)       \
   (R).x1 = MXMAX( (B).x2+1, (A).x1 ); \
   (R).y1 = MXMAX( (B).y1, (A).y1 );   \
   (R).x2 = (A).x2;                    \
   (R).y2 = MXMIN( (B).y2, (A).y2 )

#define MX__BOT_RECTS(A, B, R)         \
   (R).x1 = (A).x1;                    \
   (R).y1 = MXMAX( (B).y2+1, (A).y1 ); \
   (R).x2 = (A).x2;                    \
   (R).y2 = (A).y2

/*----------------------------------------------------------------------------
  Regions are vectors of rectangles
*/

	 typedef union MX_REGION {
		  MX_VECTOR vector;
		  MX_RECT *data;
	 } MX_REGION;

	 void mx_region_clip(MX_REGION * region, const MX_RECT * rect);

/*----------------------------------------------------------------------------
   MX_STRING is bit-copy-correct which means that a binary copy retains
   proper functioning and takes over ownership of internal buffers.

   This means that the memory of a MX_STRING can be realloc'd.
   Therefore it can be used inside a MX_VECTOR.
*/
	 typedef void (*MX_FREE) (void *);

	 typedef struct {
		  const char *_text;
		  long _len;
		  MX_FREE _free;
	 } MX_STRING;

	 void mx_string(MX_STRING * string);
	 void mx_string_free(MX_STRING * string);
	 void mx_string_set(MX_STRING * string, const char *text, long len, MX_FREE free);

	 const char *mx_string_text(const MX_STRING * string, long *len);

/* UTF-8 string handling ---------------------------------------------------*/
	 long mx_utf8_strlen(const char *s);

	 unsigned int mx_utf8_len(const char *s);
	 long mx_utf8_char(const char *s, unsigned int len);

/* Reference counted atom --------------------------------------------------

   MX_ATOM is bit-copy-correct which means that a binary copy retains
   proper functioning and takes over ownership of internal buffers.

   This means that the memory of a MX_ATOM can be realloc'd.
   Therefore it can be used inside a MX_VECTOR.
*/
	 struct MX_ATOM;

#define MX__ATOM(v) (&(v)->base.atom)

	 typedef void (*MX__ATOM_DESTRUCT) (void *atom);

	 typedef struct MX_ATOM {
		  MX__ATOM_DESTRUCT _destruct;
		  unsigned int _lock:16;
		  unsigned _flag:1;
		  unsigned _allocated:1;
#if defined(DEBUG) || defined(MX_DETK_ATOM_DEBUG)
		  const char *name;
#endif
	 } MX_ATOM;

	 void *mx__atom(MX_ATOM * atom, MX__ATOM_DESTRUCT destruct, size_t datasize);

	 void mx__atom_delete(MX_ATOM * atom);
	 void mx__atom_lock(MX_ATOM * atom);
	 unsigned mx__atom_unlock(MX_ATOM * atom);

#ifdef MX_DETK_ATOM_DEBUG
#include <stdio.h>
#define mx_atom(a,d,s) (fprintf(stderr, "AtomCreate %s:%s:%i\n", __PRETTY_FUNCTION__, __FILE__, __LINE__), mx__atom((a),(d),(s)))
#define mx_delete(a)   (fprintf(stderr, "AtomDelete %p (%u) from %s:%s:%i\n", (a), (a)->base.atom._lock, __PRETTY_FUNCTION__, __FILE__, __LINE__), mx__atom_delete(MX__ATOM(a)))
#define mx_lock(a)     mx__atom_lock(MX__ATOM(a))
#define mx_unlock(a)   mx__atom_unlock(MX__ATOM(a))

#else
#define mx_atom(a,d,s) mx__atom((a),(d),(s))
#define mx_delete(a)   mx__atom_delete(MX__ATOM(a))
#define mx_lock(a)     mx__atom_lock(MX__ATOM(a))
#define mx_unlock(a)   mx__atom_unlock(MX__ATOM(a))
#endif

#if defined(DEBUG) || defined(MX_DETK_ATOM_DEBUG)
#include <stdio.h>
#define MXNAME(a)      ((const char *)(MX__ATOM(a)->name))
#define MXNAMESET(a,n) do { MX__ATOM(a)->name = n; fprintf(stderr, "Name %p %s\n", (void*)a, n); } while (0)

#else
#define MXNAME(a)
#define MXNAMESET(a,n) do { } while (0)
#endif

/* Rectangular atoms ---------------------------------------------------------*/
	 typedef struct MX_RECTATOM {
		  union {
				MX_ATOM atom;
		  } base;

		  MX_RECT _rect;
	 } MX_RECTATOM;

#define MX__RECTATOM(b)   (&(b)->base.rectatom)
#define MXRECT(b)         ((const MX_RECT *)(&(b)->base.rectatom._rect))

	 void *mx_rectatom(MX_RECTATOM * rectatom, MX__ATOM_DESTRUCT destruct, size_t size);
	 void mx_rectatom_place(MX_RECTATOM * rectatom, const MX_RECT * rect);

#define mx_rectatom_x1(r) ((r)->_rect.x1)
#define mx_rectatom_y1(r) ((r)->_rect.y1)
#define mx_rectatom_x2(r) ((r)->_rect.x2)
#define mx_rectatom_y2(r) ((r)->_rect.y2)
#define mx_rectatom_w(r)  ((r)->_rect.x2 - (r)->_rect.x1)
#define mx_rectatom_h(r)  ((r)->_rect.y2 - (r)->_rect.y1)

#define mx_w(r)    mx_rectatom_w(MX__RECTATOM(r))
#define mx_h(r)    mx_rectatom_h(MX__RECTATOM(r))
#define mx_x1(r)   mx_rectatom_x1(MX__RECTATOM(r))
#define mx_y1(r)   mx_rectatom_y1(MX__RECTATOM(r))
#define mx_x2(r)   mx_rectatom_x2(MX__RECTATOM(r))
#define mx_y2(r)   mx_rectatom_y2(MX__RECTATOM(r))

/* Macros for Tree ---------------------------------------------------------*/
#define MX_NODE(type) \
    type *_parent;    \
    type *_last;      \
    type *_next;      \
    type *_prev

#define mx_node_insert(o,p)              \
    do {                                 \
        MXASSERT(o);                     \
        MXASSERT(p);                     \
        if (p) {                         \
            (o)->_parent = (p);          \
            if ((p)->_last)              \
                (p)->_last->_next = (o); \
            (o)->_prev = (p)->_last;     \
            (o)->_next = 0;              \
            (p)->_last = (o);            \
        }                                \
    } while (0)

#define mx_node_remove(o)                         \
    do {                                          \
        MXASSERT(o);                              \
        if ((o)->_parent) {                       \
            if ((o)->_parent->_last == (o))       \
                (o)->_parent->_last = (o)->_prev; \
            if ((o)->_prev)                       \
                (o)->_prev->_next = (o)->_next;   \
            if ((o)->_next)                       \
                (o)->_next->_prev = (o)->_prev;   \
            (o)->_next = 0;                       \
            (o)->_prev = 0;                       \
            (o)->_parent = 0;                     \
        }                                         \
    } while (0)

/* Flushing and dirty rectangle system -------------------------------------*/
	 typedef void (*MX_FLUSH_FUNC) (MX_RECT * rect);

	 void mx_drs_area(int w, int h);
	 void mx_drs_dirty(const MX_RECT * rect, unsigned mark);
	 unsigned mx_drs_update(MX_FLUSH_FUNC flush);

/* Damagemap for fast screen damage control --------------------------------*/
	 void mx_damagemap_area(int w, int h);
	 void mx_damagemap_dirty(const MX_RECT * rect, unsigned mark);
	 unsigned mx_damagemap_update(MX_FLUSH_FUNC flush);

/* Some path and filename functiosn ----------------------------------------*/
	 void mx_path_fix(char *ptr);
	 unsigned mx_filename_match(const char *p, const char *t);
	 const char *mx_basename(const char *fname);

#ifdef __cplusplus
}
#endif
#endif

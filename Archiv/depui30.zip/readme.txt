+---------------------------------------------------------------------------+
|                                                                           |
|     DEPUI-DEGFX-DETK: Portable gui, graphics and toolkit libraries        |
|                                                                           |
+---------------------------------------------------------------------------+

DJGPP:
------
Type one or more of the following at the command line:
    make all        <- Make DEPUI, DEGFX and DETK examples
    make depui      <- Make DEPUI (using DEGFX) examples
    make degfx      <- Make DEGFX examples
    make allegro    <- Make DEPUI (using Allegro for gfx) examples
	
Then look in the examples directory for the compiled example programs.

If you use RHIDE then you can use the EXAMPLES/*.GPR project files.


LINUX:
------
Type at the command line:
    make linux      <- Make DEPUI, DEGFX and DETK examples
	
Then look in the examples directory for the compiled example programs.

If you use RHIDE then you can use the EXAMPLES/*.GPR project files.


Borlands free compiler and WIN32 GDI:
-------------------------------------
Take a look at EXAMPLES/BCC.BAT file.  You will probably have to change the 
include and library paths in the batch files.  Once you cave the correct paths
run the batch file which should make the DEGFX and DEPUI examples.


Bloodshed DEV C++ (MINGW) and WIN32 GDI:
--------------------------------
Open the EXAMPLES/DEV_CPP.DEV project file.  Also try choosing a different
program file in the EXAMPLES directory.


Open Watcom and WIN32 GDI:
--------------------------
Open the EXAMPLES/WATCOM.WPJ ide project file.  Also try choosing a different 
program file in EXAMPLES directory.


LCC-32 and WIN32 GDI:
---------------------
I did get at least some of the examples to work with LCC32 but I find the IDE
very confusing so I wont include my LCC project files here.  I am especially
having trouble getting LCC to find the include files.  I solved this by 
copying the include files to the LCC include directory but this really isnt 
the right solution.  Other than that the examples seem to work fine.


/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#include "depui/depui.c"

int mx_guimain(int argc, char *argv[])
{
	 MX_WIN *win;

	 (void) argc;
	 (void) argv;

	 if (!mx_start())
		  return EXIT_FAILURE;

	 win = mx_win(0, 0, 0, 0);
	 mx_position(win, 50, 50, 200, 250);
	 mx_text_set(win, "Hello world", -1, 0);
	 mx_geometry(win);

	 return mx_execute();
}

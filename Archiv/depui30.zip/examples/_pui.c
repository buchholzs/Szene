/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/
  /* Check SVGALIB port.
     Add QL port and patches.

     How can I make clever visual transformations for window drawing

     Make it possible for a window to be double buffered.

     Can I separate the gui-tree from the objects?  This could make the
     system more safe because users could not traverse the tree which could
     be in protected memory space.

     Can I make a generic tree structure that I can use for INI files and
     user lists and the object tree?

     Making objects at 0,0 makes conversion to a text mode/theme easier.

     Transparent windows works ok, but how should trans work wrt layering?

     Should lists be appended to or should create function be used for this?

     Marking window dirty when making new window means border remains not
     updated. - use mx_win_dirty

     Can I use debug flags to make sure that classes dont get called inside
     handlers?

     Make window unresizable.

     Make editable textline and textbox.

     Make video noise window to check frame rates

     Should a font be constant or not?  Const is good for compile time error
     checking, but works bad with atom destroying.  The mx_delete macro needs
     non-const pointers.  Should it?

     Make crashes impossible even from malformed events.  The biggest danger
     comes from incorrect data but I dont know how to fix this.

     Dont try to delete in list iteration.  You might need to remove from tree
     and delete.

     Events break the atomicity of operations.  So operations should
     preferrably be atomic i.e. generate no events.  This makes sure that
     objects dont get deleted while they are bieng iterated through.
*/

#define MX_DEPUI_FILESEL
#define MX_DEPUI_GFXMODE
#define MX_DRIVER_ALL
#define MX_THEME_ALL
#define MX_FONT_8X8
#include "depui/depui.c"

typedef struct APP {
	 union {
		  MX_WIN win;
		  MX_TEXTUAL textual;
		  MX_OBJ obj;
		  MX_RECTATOM rectatom;
		  MX_ATOM atom;
	 } base;
} APP;

#define FILESEL_ID 11
#define GFXMODE_ID 12

void handler(MX_WIN * win)
{
	 if ((mx.event == MX_SELECT) && (mx.data)) {
		  MX_WIN *newwin = 0;

		  if (MXID(mx.obj) == FILESEL_ID) {
				MX_FILESEL *f = mx_fileselwin(0, 0, 0, 0);

				mx_win_child(MXWIN(f), win);
				mx_text_set(f, "File select", -1, 0);
            mx_filesel_path(f, "./*.*", -1);
            mx_filesel_refresh(f);
				newwin = MXWIN(f);

		  } else if (MXID(mx.obj) == GFXMODE_ID) {
				MX_GFXMODE *m = mx_gfxmodewin(0, 0, 0, 0);

				mx_win_modal(MXWIN(m), win);
				mx_text_set(m, "Choose GFX mode", -1, 0);
				newwin = MXWIN(m);
		  }

		  if (newwin) {
				mx_defaultrect(newwin, 0);
				mx_obj_layout(MXOBJ(newwin), MX_LAYOUT_CENTER, 0, 0, 0);
				mx_geometry(newwin);
				mx_win_activate(newwin);

				mx_dirty(newwin, true);
				mx_dirty(newwin->border, true);
				return;
		  }
	 }
	 mx_win_handler(win);
}

int mx_guimain(int argc, char *argv[])
{
	 APP *app;
	 MX_WIN *w;
	 MX_TEXTUAL *text;
	 MX_BUTTON *btn, *btn1, *btn2;
	 MX_LIST *list;
	 MX_SCROLL *scroll;

	 (void) argc;
	 (void) argv;

	 if (!mx_start())
		  return EXIT_FAILURE;

	 w = mx_win(0, 0, 0, 0);
	 mx_position(w, 150, 150, 200, 250);
	 mx_dirty(w, true);
	 MXNAMESET(w, "list_win");
	 mx_text_set(w, "Listg Window", -1, 0);
	 mx_geometry(w);

	 list = mx_list(0, 0, w, 0);
	 mx_position(list, 0, 0, 100, 95);
	 mx_text_set(list, "A list", -1, 0);
	 mx_text_align(list, MX_ALIGN_RIGHT);

	 mx_list_append(list, "Selgect 1 is very wide", -1, 0, 0);
	 mx_list_append(list, "SelTect 2", -1, 0, 0);
	 mx_list_append(list, "SelgTt 3", -1, 0, 0);
	 mx_list_append(list, "SelgTt 4\n   has more\n   than one line", -1, 0, 0);
	 mx_list_append(list, "SelgTt 5", -1, 0, 1);
	 mx_list_append(list, "SelgTt 6", -1, 0, 0);
	 mx_list_append(list, "SelgTt 7", -1, 0, 1);
	 mx_list_append(list, "SelgTt 8", -1, 0, 0);
	 mx_list_append(list, "SelgTt 9", -1, 0, 1);
	 mx_list_append(list, "SelgTt 10", -1, 0, 0);
	 mx_list_append(list, "SelgTt 11", -1, 0, 1);
	 mx_list_append(list, "SelgTt 12", -1, 0, 2);
	 mx_list_append(list, "SelgTt 13", -1, 0, 0);
	 mx_list_append(list, "SelgTt 14", -1, 0, 0);
	 mx_list_select_id(list, 2, true);
/*	 mx_list_select_id(list, 2, false); */
	 mx_geometry(list);

	 app = (APP *) mx_win(0, 0, handler, 0);
	 mx_position(app, 50, 50, 250, 250);
	 mx_dirty(app, true);
	 MXNAMESET(app, "button_app");
	 mx_text_set(app, "Buttong Window\nis what I am", -1, 0);
	 mx_geometry(app);

	 text = mx_textual(0, 0, app, 0);
	 mx_textual_set(text, "Whatg am I\nDoing right\nNow?\n", -1, 0);
	 mx_move(text, 10, 1);
	 mx_defaultrect(text, 0);

	 btn = mx_button(0, 0, app, 0);
	 mx_text_set(btn, "Toggle", -1, 0);
	 mx_defaultrect(btn, 0);
	 mx_text_align(btn, MX_ALIGN_CENTER);
	 mx_layout(btn, (MX_LAYOUT) (MX_LAYOUT_X1 | MX_LAYOUT_BOTTOM), text, 0, 2);

	 btn1 = mx_button(0, 0, app, FILESEL_ID);
	 mx_text_set(btn1, "File select (child)", -1, 0);
	 mx_defaultrect(btn1, 0);
	 mx_text_align(btn1, MX_ALIGN_CENTER);
	 mx_layout(btn1, (MX_LAYOUT) (MX_LAYOUT_X1 | MX_LAYOUT_BOTTOM), btn, 0, 2);

	 btn2 = mx_button(0, 0, app, GFXMODE_ID);
	 mx_text_set(btn2, "Gfxmode/Theme (modal)", -1, 0);
	 mx_text_align(btn2, MX_ALIGN_CENTER);
	 mx_defaultrect(btn2, 0);
	 mx_layout(btn2, (MX_LAYOUT) (MX_LAYOUT_X1 | MX_LAYOUT_BOTTOM), btn1, 0, 2);

	 scroll = mx_scroll(0, 0, app, 1);
	 mx_resize(scroll, 100, 100);
	 mx_layout(scroll, (MX_LAYOUT) (MX_LAYOUT_X1 | MX_LAYOUT_BOTTOM), btn2, 0, 2);

	 btn = mx_button(0, 0, scroll, 0);
	 mx_text_set(btn, "This is disabled", -1, 0);
	 mx_text_align(btn, MX_ALIGN_CENTER);
	 mx_defaultrect(btn, 0);
	 mx_disable(btn, true);
	 mx_move(btn, -10, -10);

	 btn = mx_button(0, 0, scroll, 0);
	 mx_text_set(btn, "another button", -1, 0);
	 mx_text_align(btn, MX_ALIGN_CENTER);
	 mx_defaultrect(btn, 0);
	 mx_position(btn, 70, 150, MXDEF, MXDEF);

	 mx_geometry(scroll);

/*    fprintf(stderr, "MX_ATOM     = %i bytes\n", sizeof(MX_ATOM));
    fprintf(stderr, "MX_RECTATOM = %i bytes\n", sizeof(MX_RECTATOM));
    fprintf(stderr, "MX_OBJ      = %i bytes\n", sizeof(MX_OBJ));
    fprintf(stderr, "MX_BUTTON   = %i bytes\n", sizeof(MX_BUTTON));
    fprintf(stderr, "MX_WIN      = %i bytes\n", sizeof(MX_WIN));
*/

	 return mx_execute();
}

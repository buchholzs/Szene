/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#include "depui/depui.c"

static void handler(MX_WIN * win)
{
	 if ((mx.event == MX_POINTER_CLICK) && (MXOBJ(mx.obj) == MXOBJ(win))) {
		  mx_delete(win);
	 }

	 mx_win_handler(win);
}

int mx_guimain(int argc, char *argv[])
{
	 MX_WIN *win;

	 (void) argc;
	 (void) argv;

	 if (!mx_start())
		  return EXIT_FAILURE;

	 win = mx_win(0, 0, handler, 0);
	 mx_position(win, 50, 50, 200, 250);
	 mx_text_set(win, "Click window to exit", -1, 0);
	 mx_geometry(win);

	 return mx_execute();
}

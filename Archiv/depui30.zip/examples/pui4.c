/*--------------------------------------------------------------------------
 DEPUI-GFX-TK 3.0 - GPL portable source code libraries 
 http://www.deleveld.dds.nl/depui.htm
 See file docs/copying for copyright details
 ---------------------------------------------------------------------------*/

#define MX_THEME_ROUNDED
#define MX_DEPUI_FILESEL
#include "depui/depui.c"

typedef struct APP {
	 union {
		  MX_WIN win;
		  MX_TEXTUAL textual;
		  MX_OBJ obj;
		  MX_RECTATOM rectatom;
		  MX_ATOM atom;
	 } base;
	 MX_BUTTON choose;
	 MX_TEXTUAL filename;
} APP;

static void handler(MX_WIN * win)
{
	 APP *app = (APP *) win;

	 /* Start the file selector to choose a filename */
	 if ((mx.event == MX_SELECT) && (mx.data) && (MXOBJ(mx.obj) == MXOBJ(&app->choose))) {
  		  MX_FILESEL *filesel = mx_fileselwin(0, 0, 0, 0);
        
        mx_win_modal(MXWIN(filesel), win);
        mx_text_set(filesel, "File select", -1, 0);
        mx_filesel_path(filesel, "./*.*", -1);
        mx_filesel_refresh(filesel);

		  mx_defaultrect(filesel, 0);
        mx_obj_layout(MXOBJ(filesel), MX_LAYOUT_CENTER, 0, 0, 0);
		  mx_geometry(filesel);
		  mx_activate(filesel);

        mx_win_dirty(MXWIN(filesel));
		  return;

    /* When a filename has been chosen, copy the text for the button */
	 } else if (mx.event == MX_FILESEL_OK) {
        const char *file = mx_filesel_info();

        /* Make a copy of the filename text */
        if (file) {
            const int len = strlen(file);
            char * text = (char *)mx_malloc(len + 1);

            strcpy(text, file);

            /* Change the text to be displayed */
            mx_textual_set(&app->filename, text, -1, mx_free);
            mx_defaultrect(&app->filename, 0);
            mx_dirty(&app->filename, true);
        }
    }

	 mx_win_handler(MXWIN(app));
}

static APP *newapp(void)
{
	 /* Create the window for the app */
	 APP *app = (APP *) mx_win(0, sizeof(APP), handler, 0);
	 if (app) {
        /* Make the button */
		  mx_button(&app->choose, 0, app, 0);
		  mx_text_set(&app->choose, "choose", -1, 0);
		  mx_defaultrect(&app->choose, 0);
		  mx_text_align(&app->choose, MX_ALIGN_CENTER);

        /* Make the filename text */
        mx_textual(&app->filename, 0, app, 0);
		  mx_textual_set(&app->filename, "No filename chosen", -1, 0);
		  mx_defaultrect(&app->filename, 0);
		  mx_textual_align(&app->filename, MX_ALIGN_CENTER);

        /* Place the button and text */
        mx_move(&app->choose, 5, 5);
        mx_layout(&app->filename, (MX_LAYOUT)(MX_LAYOUT_X1 | MX_LAYOUT_BOTTOM), &app->choose, 0, 5);
	 }
	 return app;
}

int mx_guimain(int argc, char *argv[])
{
	 APP *app;

	 (void) argc;
	 (void) argv;

	 if (!mx_start())
		  return EXIT_FAILURE;

	 app = newapp();
	 MXASSERT(app);

	 mx_position(app, 50, 50, 200, 250);
	 mx_text_set(app, "Filename test", -1, 0);
	 mx_geometry(app);

	 return mx_execute();
}

/**
 ** memcopy.h ---- inline assembly memory copy macros -- WATCOM-C++ code
 **/

/* this is a good candidate for optimized assembler code */

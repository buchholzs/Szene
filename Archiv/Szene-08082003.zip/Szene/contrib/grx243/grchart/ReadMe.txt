========================================================================
    WIN32-ANWENDUNG : grchart-Projekt�bersicht
========================================================================

Der Anwendungs-Assistent hat die grchart-Anwendung erstellt.  
Diese Datei enth�lt eine �bersicht des Inhalts der Dateien der
 grchart-Anwendung.


grchart.vcproj
    Dies ist die Hauptprojektdatei f�r VC++-Projekte, die vom Anwendungs-Assistenten erstellt wird. 
    Sie enth�lt Informationen �ber die Version von Visual C++, mit der 
    die Datei generiert wurde, �ber die Plattformen, Konfigurationen und Projektfeatures,
    die mit dem Anwendungs-Assistenten ausgew�hlt wurden.

grchart.cpp
    Dies ist die wichtigste Anwendungsquelldatei.

/////////////////////////////////////////////////////////////////////////////
Der Anwendungs-Assistent hat folgende Ressourcen erstellt:

grchart.rc
    Hierbei handelt es sich um eine Auflistung aller Ressourcen von Microsoft Windows, die
    vom Programm verwendet werden. Sie enth�lt die Symbole, Bitmaps und Cursors, die im
    Unterverzeichnis RES gespeichert sind. Diese Datei l�sst sich direkt in Microsoft
    Visual C++ bearbeiten.

Resource.h
    Dies ist die Standardheaderdatei, die neue Ressourcen-IDs definiert.
    Die Datei wird mit Microsoft Visual C++ gelesen und aktualisiert.
grchart.ico
    Dies ist eine Symboldatei, die als Anwendungssymbol (32x32) verwendet wird.
    Das Symbol wird von der Hauptressourcendatei grchart.rc einbezogen.

small.ico
    Dies ist eine Symboldatei, die eine kleinere Version (16x16)
    des Anwendungssymbols enth�lt. Das Symbol wird von der Hauptressourcendatei
    grchart.rc einbezogen.

/////////////////////////////////////////////////////////////////////////////
Weitere Standarddateien:

StdAfx.h, StdAfx.cpp
    Mit diesen Dateien werden vorkompilierte Headerdateien (PCH)
    mit der Bezeichnung grchart.pch und eine vorkompilierte Typdatei mit der Bezeichnung StdAfx.obj erstellt.

/////////////////////////////////////////////////////////////////////////////
Weitere Hinweise:

Der Anwendungs-Assistent verwendet "TODO:"-Kommentare, um Teile des Quellcodes anzuzeigen, die hinzugef�gt oder angepasst werden m�ssen.

/////////////////////////////////////////////////////////////////////////////

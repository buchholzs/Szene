This is the release v0.2 of Plushplayer and Matedit.

These programs use the 3D plush library
(http://www.nullsoft.com/free/plush/) to display a scene
file written in XML.

Both programs run in DOS mode or Win32 mode. Use Dosbox to start the DOS programs.
Best results are achieved with S3 Graphic, use machine=svga_s3 in Dosbox config.

Then start

plushplr
 - or -
matedit2

There are also Win32 versions of these two programs.
To start, type

plushplr_w32
- or -
matedit2_w32


Plushplayer
===========
You can load any *.scx (Scene XML) file in the "scenes" folder.
When you start plushplr without an argument, it shows the file open dialog.

In the scene, you can navigate using the mouse and the following buttons:
w - step forward
a - step left
s - step backward
d - step right
r - reload a previously loaded scene
F1 - popup the key help window
F3 - popup the file open dialog.

Matedit2
========
You can modify the material using various sliders. Load a scene file
or use the default standard.scx. Click on one of the materials in
the material list and change its properties with the sliders.
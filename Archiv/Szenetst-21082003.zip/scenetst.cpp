/* This is simple demonstration of how to use expat. This program
reads an XML document from standard input and writes a line with the
name of each element to standard output indenting child elements by
one tab stop more than their parent element. */

#pragma warning (disable : 4786)
#include "grx20.h"
#include "grxkeys.h"

#include <assert.h>
#include <time.h>
#include <iostream>
#include <vector>
#include <stdexcept>

#include "Scene.h"

// const int screen_w = 320; const int screen_h = 200;
const int screen_w = 640; const int screen_h = 480;
const int BPP = 8;
#define WINTITLE "GRX Scene"
float mouse_sens = 2.5 * 2048.0/32768.0;
float velocity = 20.0; // m/s

const int CText = 10; // LIGHT_GREEN
const int cframeAvg = 3;

pl_uChar TheFrameBuffer[screen_w * screen_h];
pl_uChar ThePalette[768];
pl_ZBuffer TheZBuffer[screen_w * screen_h];

typedef vector<pl_Cam*> vector_cams;
vector_cams cams;

static signed short int old_mouse_x=0, old_mouse_y=0;
static signed short int mx=0, my=0;

void mouse_reset() 
{
	GrMouseEvent evt;
	GrMouseWarp(screen_w / 2, screen_h / 2);
	do {
		GrMouseGetEventT(GR_M_EVENT | GR_M_NOPAINT, &evt,0L);
	} while (evt.flags != 0);
	old_mouse_x = evt.x;
	old_mouse_y = evt.y;
}
void mouse_get(GrMouseEvent evt, int &mouse_x, int &mouse_y) 
{

  mouse_x = ((old_mouse_x - evt.x) + mx) / 2;
  mouse_y = ((old_mouse_y - evt.y) + my) / 2;
  mx = mouse_x;
  my = mouse_y;
  old_mouse_x = evt.x;
  old_mouse_y = evt.y;
}
pl_Cam *reload(Scene &scene, const string &file, vector_cams &cams) {
// reload
  scene.loadXML(file);
  register int i=0;
  cams.clear();
  for (Scene::CamMap::iterator it = scene.getCameras().begin();
		it != scene.getCameras().end(); it++) {
	cams.push_back(it->second);
	}

  cout << "Make palette" << endl;
  scene.makePalette(ThePalette, 20, 255);
  GrAllocEgaColors();  // Farben 1-15 belegen
  for (i = 20; i < 256; i++) {
	GrSetColor(i, ThePalette[ i*3 ], ThePalette[ i*3 + 1], ThePalette[ i*3 + 2 ]);
  }
  return scene.getCurrCamera();
}
void renderScene(string file) {
  pl_sChar lastmessage[80] = "";
  GrMouseEvent evt;
  int mouse_x, mouse_y;
  int width=screen_w, height=screen_h, bpp=BPP;

  GrSetMode( GR_width_height_bpp_graphics,width,height,bpp );
  GrSetWindowTitle( WINTITLE );
  GrMouseInit();

  char *memory[4] = {(char *)TheFrameBuffer,0,0,0};
  GrContext *ctx =
  GrCreateContext(screen_w,screen_h,memory,NULL);

  cout << "Rendering" << endl;
  Scene scene(screen_w, screen_h, TheZBuffer, TheFrameBuffer);

// reload
  pl_Cam *cam = reload(scene, file, cams);
  assert(cam != 0);

  GrSetColor(CText, 0, 192, 0);

  float prevtime = clock() / (float) CLOCKS_PER_SEC; 
  float currtime = prevtime , difftime = 0.0; 
  mouse_reset();

  float difftimeF = 0.0; 
  int frames = 1;
  float fps = 0.0;
  while( 1 ) {
        frames++;
	if (frames == cframeAvg) {
	  fps = (float)frames / difftimeF;
	  frames = 1;
	  difftimeF = 0.0;
	}
	currtime = (clock() / (float) CLOCKS_PER_SEC);
	difftime = currtime - prevtime;
	difftimeF += difftime;
	prevtime = currtime;

    GrMouseGetEventT(GR_M_EVENT | GR_M_NOPAINT,&evt, 0L);
	if (evt.flags & GR_M_KEYPRESS) {
		switch (evt.key) {
		case GrKey_q:
			return;
		case GrKey_l:	// Reload
			{
				cam = reload(scene, file, cams);
			}
			break;
	    case GrKey_LParen: mouse_sens /= 1.1f; 
		  sprintf((char *)lastmessage,"MouseSens: %.3f",mouse_sens);
		  break;

		case GrKey_F1:
			if (cams.size() >= 1) cam = cams[0];
			scene.setCurrCamera(cam);
			break;
		case GrKey_F2:
			if (cams.size() >= 2) cam = cams[1];
			scene.setCurrCamera(cam);
			break;
		case GrKey_F3:
			if (cams.size() >= 3) cam = cams[2];
			scene.setCurrCamera(cam);
			break;
		case GrKey_F4:
			if (cams.size() >= 4) cam = cams[3];
			scene.setCurrCamera(cam);
			break;

        // ] increases mouse sensitivity
        case GrKey_RParen: mouse_sens *= 1.1f; 
          sprintf((char *)lastmessage,"MouseSens: %.3f",mouse_sens);
		  break;
		}
	}
	mouse_get(evt, mouse_x, mouse_y);

	cam->Pitch += (mouse_y*mouse_sens); // update pitch and pan of ship
	if (GrKeyStat() & GR_KB_SHIFT) {
		cam->Roll += (mouse_x*mouse_sens);
	} else {
		cam->Pan -= (mouse_x*mouse_sens);
	}
	
	float v = 0.0;
	if (evt.buttons & GR_M_MIDDLE) { // if right button hit, we go forward quickly
		v = 2 * velocity;
	} else if (evt.buttons & GR_M_LEFT) { // if left button hit, we go forward slowly
		v = velocity;
	} else if (evt.buttons & GR_M_RIGHT) { // if middle button hit, we go backward slowly
		v = - 2 * velocity;
	}
	if (v != 0.0) {
	  cam->X -=
		difftime*v*sin(cam->Pan*PL_PI/180.0)*cos(cam->Pitch*PL_PI/180.0);
	  cam->Z += 
		difftime*v*cos(cam->Pan*PL_PI/180.0)*cos(cam->Pitch*PL_PI/180.0);
	  cam->Y += 
		difftime*v*sin(cam->Pitch*PL_PI/180.0);
	}
	
	if (!((evt.x >= 10 && evt.x <= screen_w - 10) &&
		 (evt.y >= 10 && evt.y <= screen_h - 10)))
		mouse_reset();
	scene.render();
	plTextPrintf(cam,cam->ClipLeft+5,cam->ClipTop+12, 0.0,CText,
		( pl_sChar *)"FPS=%.1f", fps);
	plTextPrintf(cam,cam->ClipLeft+5,cam->ClipBottom-12,0.0,CText,
		( pl_sChar *)"Pitch=%.2f Pan=%.2f Roll=%.2f MX=%d MY=%d",
		cam->Pitch,cam->Pan, cam->Roll, mouse_x, mouse_y);
	plTextPrintf(cam,cam->ClipLeft+5,cam->ClipBottom-24, 0.0,CText,
		( pl_sChar *)"X=%.2f Y=%.2f Z=%.2f  FPS=%.1f", 
		cam->X, cam->Y, cam->Z, 1.0 / difftime);
	plTextPrintf(cam,cam->ClipLeft+5,cam->ClipBottom-36, 0.0,CText,
		lastmessage);
	GrBitBlt(NULL, 0, 0,ctx,
          0, 0, screen_w - 1, screen_h - 1, GrWRITE);
  }
  GrSetMode( GR_default_text );
}

extern "C" int
GRXMain(int argc, char **argv)
{
	try 
	{
		if (argc != 2) {
			cerr << "Usage: " << argv[0] << " <scene.xml>" << endl;
			return 1;
		}
		// Parse only
		cout << "Parsing only" << endl;
		Scene scene1;
		scene1.loadXML(argv[1]);
		scene1.dump(cout);
                
		// Rendering
		cout << "Start rendering" << endl;
		renderScene(argv[1]);
		cout << "Rendering ok" << endl;
	}
	catch (exception &e) 
	{
		cerr << "Exception: " << e.what( ) << endl;
		cerr << "Typ: " << typeid(e).name( ) << endl;
	};
  return 0;
}

// NOTE: please use a PRESERVE:BEGIN/PRESERVE:END comment block
//       to preserve your hand-coding across code generations.


#include "Hud.h"

// ------------------------------------------------------------
Hud::Hud ()
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}

// ------------------------------------------------------------
Hud::Hud (const Hud&)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}

// ------------------------------------------------------------
Hud::~Hud ()
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}

// ------------------------------------------------------------
Hud& Hud::operator = (const Hud &arg)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	return *this;
	// PRESERVE:END
}

// ------------------------------------------------------------
int Hud::setStatusText (const string txt)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}



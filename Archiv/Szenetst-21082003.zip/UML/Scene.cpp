// NOTE: please use a PRESERVE:BEGIN/PRESERVE:END comment block
//       to preserve your hand-coding across code generations.


#include "Scene.h"

// ------------------------------------------------------------
Scene::Scene ()
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
Scene::Scene (pl_uInt screenWidth, pl_uInt screenHeight, pl_ZBuffer* zBuffer, pl_uChar* frameBuffer, pl_Float aspectRatio)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
Scene::~Scene ()
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
// Liefert die z.Zt. selektierte Kamera

void Scene::setCurrCamera (pl_Cam* cam)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
// Liefert die aktive Kamera

pl_Cam* Scene::getCurrCamera ()
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
// L�dt eine Szenebeschreibung im XML-Format

int Scene::loadXML (const string& fileName)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
// Liefert eine Kamera aus der Szenebeschreibung

pl_Cam* Scene::findCamera (const string& name)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
// Liefert ein Licht aus der Szenebeschreibung

pl_Light* Scene::findLight (const string& name)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
// Liefert ein Material aus der Szenebeschreibung

pl_Mat* Scene::findMaterial (const string& name)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
// Liefert ein Objekt aus der Szenebeschreibung

pl_Obj* Scene::findObject (const string& name)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
// Liefert eine Textur aus der Szenebeschreibung

pl_Texture* Scene::findTexture (const string& name)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
// Rendert eine Szene mit der ausgew�hlten Kamera 

void Scene::render ()
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
// Gibt eine Beschreibung der Szene auf den Stream aus

void Scene::dump (const ostream& str)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
// Erzeugt eine Camera anhand der Attributliste

void Scene::createCamera (const char** attr)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
// Erzeugt ein Light anhand der Attributliste

void Scene::createLight (const char** attr)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
// Erzeugt eine Textur anhand der Attributliste

void Scene::createTexture (const char** attr)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
// Erzeugt ein Material anhand der Attributliste

void Scene::createMaterial (const char** attr)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
// Erzeugt ein Object anhand der Attributliste

void Scene::createObject (enum sc_Tokens tok, const char** attr)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
// Erzeugt ein Object aus einer Datei anhand der Attributliste

void Scene::createObjectFromFile (enum sc_Tokens tok, const char** attr)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
// Erzeugt eine Transformation anhand der Attributliste

void Scene::createTransformation (enum sc_Tokens tok, const char** attr)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
// Berechnet eine Palette aus den vorhandenen Materialien 
// und mappt diese anschlie�end auf die Palette
// Parameter:
// pal : Palette, ein 768 byte-Array von unsigned chars,
// 3 bilden zusammen ein RGB-Tripel
// pstart : Startoffset, normal 0
// pend : Endoffset, normal 255

void Scene::makePalette (pl_uChar* pal, pl_sInt pstart, pl_sInt pend)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
Scene::Scene (const Scene& rhs)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
Scene& Scene::operator= (const Scene& arg)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
// Initialisiert wichtige Attribute

void Scene::init (pl_uInt screenWidth, pl_uInt screenHeight, pl_ZBuffer* zBuffer, pl_uChar* frameBuffer, pl_Float aspectRatio_)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
// L�scht die geladene Szene

void Scene::clear ()
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}



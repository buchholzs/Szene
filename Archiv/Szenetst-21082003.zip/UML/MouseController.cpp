// NOTE: please use a PRESERVE:BEGIN/PRESERVE:END comment block
//       to preserve your hand-coding across code generations.


#include "MouseController.h"

// ------------------------------------------------------------
MouseController::MouseController ()
		:ControllerBase()
		//TODO: check and complete member initialisation list!
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}

// ------------------------------------------------------------
MouseController::MouseController (const MouseController&)
		:ControllerBase()
		//TODO: check and complete member initialisation list!
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}

// ------------------------------------------------------------
MouseController::~MouseController ()
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}

// ------------------------------------------------------------
MouseController& MouseController::operator = (const MouseController &arg)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	return *this;
	// PRESERVE:END
}

// ------------------------------------------------------------
int MouseController::read ()
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}



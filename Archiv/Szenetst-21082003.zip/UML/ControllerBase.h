// NOTE: please use a PRESERVE:BEGIN/PRESERVE:END comment block
//       to preserve your hand-coding across code generations.

#ifndef _ControllerBase_H_
#define _ControllerBase_H_

#define exception class
#include "StatusObserver.h"
#include "ControllerBase.h"

class ControllerBase {
public:
	ControllerBase ();
	ControllerBase (const ControllerBase&);
	virtual ~ControllerBase ();
	ControllerBase& operator = (const ControllerBase &arg);

	// Kamera zur�ck
	void	moveBackward ();
	void	moveForward ();

	// Simulation beenden
	void	quit ();

	// Kamera links drehen
	// speed: Grad / s
	void	turnLeft (const unsigned int speed);

	// Kamera rechtsdrehen
	// speed: Grad / s
	void	turnRight (const unsigned int speed);

	// Hereinzoomen der Kamera
	void	zoomIn ();

	// Herauszoomen der Kamera (FOV)
	void	zoomOut ();

	// Abfrage des Eingabeger�tes (default: Keyboard) und f�hrt daraufhin Aktionen aus.
	virtual void	read ();

	// Hinzuf�gen eines Observers f�r den Status
	void	addStatusObserver (const StatusObserver *obs);

	// Entfernt einen Observer f�r den Status
	void	removeStatusObserver (const StatusObserver *obs);

	// Setzt eine Kamera anhand ihres Index als aktuelle Kamera.
	void	setCamera (const unsigned int index);

	// Setzt die Geschwindigkeit der Kamerabewegung (Einheit/s).
	// 
	void	setSpeed (const unsigned int speed);
private:

	// Benachrichtigt Observer von einem neuen Statustext
	void	notifyStatus (const string status);
};

#endif

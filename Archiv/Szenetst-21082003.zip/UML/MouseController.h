// NOTE: please use a PRESERVE:BEGIN/PRESERVE:END comment block
//       to preserve your hand-coding across code generations.

#ifndef _MouseController_H_
#define _MouseController_H_

#define exception class
#include "ControllerBase.h"

class MouseController : public ControllerBase {
public:
	MouseController ();
	MouseController (const MouseController&);
	virtual ~MouseController ();
	MouseController& operator = (const MouseController &arg);
	virtual int	read ();
};

#endif

// NOTE: please use a PRESERVE:BEGIN/PRESERVE:END comment block
//       to preserve your hand-coding across code generations.


#include "ControllerBase.h"

// ------------------------------------------------------------
ControllerBase::ControllerBase ()
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}

// ------------------------------------------------------------
ControllerBase::ControllerBase (const ControllerBase&)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}

// ------------------------------------------------------------
ControllerBase::~ControllerBase ()
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}

// ------------------------------------------------------------
ControllerBase& ControllerBase::operator = (const ControllerBase &arg)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	return *this;
	// PRESERVE:END
}

// ------------------------------------------------------------
// Kamera zur�ck

void ControllerBase::moveBackward ()
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
void ControllerBase::moveForward ()
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
// Simulation beenden

void ControllerBase::quit ()
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
// Kamera links drehen
// speed: Grad / s

void ControllerBase::turnLeft (const unsigned int speed)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
// Kamera rechtsdrehen
// speed: Grad / s

void ControllerBase::turnRight (const unsigned int speed)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
// Hereinzoomen der Kamera

void ControllerBase::zoomIn ()
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
// Herauszoomen der Kamera (FOV)

void ControllerBase::zoomOut ()
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
// Abfrage des Eingabeger�tes (default: Keyboard) und f�hrt daraufhin Aktionen aus.

void ControllerBase::read ()
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
// Hinzuf�gen eines Observers f�r den Status

void ControllerBase::addStatusObserver (const StatusObserver *obs)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
// Entfernt einen Observer f�r den Status

void ControllerBase::removeStatusObserver (const StatusObserver *obs)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
// Setzt eine Kamera anhand ihres Index als aktuelle Kamera.

void ControllerBase::setCamera (const unsigned int index)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
// Setzt die Geschwindigkeit der Kamerabewegung (Einheit/s).
// 

void ControllerBase::setSpeed (const unsigned int speed)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}


// ------------------------------------------------------------
// Benachrichtigt Observer von einem neuen Statustext

void ControllerBase::notifyStatus (const string status)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}



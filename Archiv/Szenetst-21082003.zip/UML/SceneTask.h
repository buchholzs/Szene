// NOTE: please use a PRESERVE:BEGIN/PRESERVE:END comment block
//       to preserve your hand-coding across code generations.

#ifndef _SceneTask_H_
#define _SceneTask_H_

#define exception class
#include "D:_Projekte_TASKS_INC_TASK.H.h"
#include "Scene.h"

class SceneTask : public Task {
public:
	SceneTask ();
	SceneTask (const SceneTask&);
	virtual ~SceneTask ();
	SceneTask& operator = (const SceneTask &arg);
	Scene	unnamed;
};

#endif

// NOTE: please use a PRESERVE:BEGIN/PRESERVE:END comment block
//       to preserve your hand-coding across code generations.


#include "StatusObserver.h"

// ------------------------------------------------------------
StatusObserver::StatusObserver ()
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}

// ------------------------------------------------------------
StatusObserver::StatusObserver (const StatusObserver&)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}

// ------------------------------------------------------------
StatusObserver::~StatusObserver ()
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}

// ------------------------------------------------------------
StatusObserver& StatusObserver::operator = (const StatusObserver &arg)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	return *this;
	// PRESERVE:END
}


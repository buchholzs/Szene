// NOTE: please use a PRESERVE:BEGIN/PRESERVE:END comment block
//       to preserve your hand-coding across code generations.


#include "JoystickController.h"

// ------------------------------------------------------------
JoystickController::JoystickController ()
		:ControllerBase()
		//TODO: check and complete member initialisation list!
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}

// ------------------------------------------------------------
JoystickController::JoystickController (const JoystickController&)
		:ControllerBase()
		//TODO: check and complete member initialisation list!
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}

// ------------------------------------------------------------
JoystickController::~JoystickController ()
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}

// ------------------------------------------------------------
JoystickController& JoystickController::operator = (const JoystickController &arg)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	return *this;
	// PRESERVE:END
}


// NOTE: please use a PRESERVE:BEGIN/PRESERVE:END comment block
//       to preserve your hand-coding across code generations.


#include "SceneTask.h"

// ------------------------------------------------------------
SceneTask::SceneTask ()
		:Task(), unnamed()
		//TODO: check and complete member initialisation list!
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}

// ------------------------------------------------------------
SceneTask::SceneTask (const SceneTask&)
		:Task(), unnamed()
		//TODO: check and complete member initialisation list!
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}

// ------------------------------------------------------------
SceneTask::~SceneTask ()
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	// PRESERVE:END
}

// ------------------------------------------------------------
SceneTask& SceneTask::operator = (const SceneTask &arg)
{
	// PRESERVE:BEGIN
	// Insert your preservable code here...
	return *this;
	// PRESERVE:END
}


// NOTE: please use a PRESERVE:BEGIN/PRESERVE:END comment block
//       to preserve your hand-coding across code generations.

#ifndef _ControllerTask_H_
#define _ControllerTask_H_

#define exception class
#include "D:_Projekte_TASKS_INC_TASK.H.h"
#include "ControllerBase.h"

class ControllerTask : public Task {
public:
	ControllerTask ();
	ControllerTask (const ControllerTask&);
	virtual ~ControllerTask ();
	ControllerTask& operator = (const ControllerTask &arg);
	ControllerBase	unnamed;
};

#endif

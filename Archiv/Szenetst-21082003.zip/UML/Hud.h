// NOTE: please use a PRESERVE:BEGIN/PRESERVE:END comment block
//       to preserve your hand-coding across code generations.

#ifndef _Hud_H_
#define _Hud_H_

#define exception class
class Hud {
public:
	Hud ();
	Hud (const Hud&);
	virtual ~Hud ();
	Hud& operator = (const Hud &arg);
	int	setStatusText (const string txt);
};

#endif

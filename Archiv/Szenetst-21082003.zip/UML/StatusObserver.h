// NOTE: please use a PRESERVE:BEGIN/PRESERVE:END comment block
//       to preserve your hand-coding across code generations.

#ifndef _StatusObserver_H_
#define _StatusObserver_H_

#define exception class
class StatusObserver {
public:
	StatusObserver ();
	StatusObserver (const StatusObserver&);
	virtual ~StatusObserver ();
	StatusObserver& operator = (const StatusObserver &arg);
	virtual void	updateStatus (const string &status) = 0;
};

#endif

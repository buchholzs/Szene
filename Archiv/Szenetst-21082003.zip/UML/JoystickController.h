// NOTE: please use a PRESERVE:BEGIN/PRESERVE:END comment block
//       to preserve your hand-coding across code generations.

#ifndef _JoystickController_H_
#define _JoystickController_H_

#define exception class
#include "ControllerBase.h"

class JoystickController : public ControllerBase {
public:
	JoystickController ();
	JoystickController (const JoystickController&);
	virtual ~JoystickController ();
	JoystickController& operator = (const JoystickController &arg);
};

#endif

/* This is simple demonstration of how to use expat. This program
reads an XML document from standard input and writes a line with the
name of each element to standard output indenting child elements by
one tab stop more than their parent element. */

#pragma warning (disable : 4786)

#include <assert.h>
#include <algorithm>
#include <iomanip>
#include <iostream>
#include <list>
#include <sstream>
#include <stdexcept>
#include <string>
#include <typeinfo>

#include <grx20.h>
#include <grxkeys.h>

#include "Scene.h"

#ifndef _MSC_VER
#define _MAX max
#define _MIN min
#endif
#define incKomp( m, k ) incKompI( m, k, 0, 255)
#define decKomp( m, k ) decKompI( m, k, 0, 255)

#define incKompI( m, k, l, u ) if (m != NULL) { m->k++; m->k = _MIN(u, _MAX(l, m->k)); matChanged=true; }

#define decKompI( m, k, l, u ) if (m != NULL) { m->k--; m->k = _MIN(u, _MAX(l, m->k)); matChanged=true; }

#ifdef _MSC_VER
const int screen_w = 320;
const int screen_h = 200;
#else
const int screen_w = 640;
const int screen_h = 480;
#endif
const int BPP = 8;
const char *WINTITLE="GRX Scene";
const char *defFileName = "standard.xml";
const char *CStdMat= "stdmat";
const char *CStdObj = "stdobj";

const int reset_area = 20;
const int CTextColor = 1;	// Idx of text color
const int CWinColors = 20;	// Readonly colors
const int CFixColors = CWinColors + 3;	// used for text and background

pl_uChar TheFrameBuffer[screen_w * screen_h];
pl_uChar ThePalette[768];
pl_ZBuffer TheZBuffer[screen_w * screen_h];
static string help_screen[] = {
	"Q - Increases the red specular component of the material of the sphere. ",
	"W - Decreases the red specular component of the material of the sphere. ",
	"E - Increases the green specular component of the material of the sphere. ",
	"R - Decreases the green specular component of the material of the sphere. ",
	"T - Increases the blue specular component of the material of the sphere. ",
	"Y - Decreases the blue specular component of the material of the sphere. ",
	"A - Increases the red diffuse component of the material of the sphere. ",
	"S - Decreases the red diffuse component of the material of the sphere. ",
	"D - Increases the green diffuse component of the material of the sphere. ",
	"F - Decreases the green diffuse component of the material of the sphere. ",
	"G - Increases the blue diffuse component of the material of the sphere. ",
	"H - Decreases the blue diffuse component of the material of the sphere. ",
	"1 - Increases the red ambient component of the material of the sphere. ",
	"2 - Decreases the red ambient component of the material of the sphere. ",
	"3 - Increases the green ambient component of the material of the sphere. ",
	"4 - Decreases the green ambient component of the material of the sphere. ",
	"5 - Increases the blue ambient component of the material of the sphere. ",
	"6 - Decreases the blue ambient component of the material of the sphere. ",
	"F1 - Increases the transparence of the material of the sphere. ",
	"F2 - Decreases the transparence of the material of the sphere.",
	"Y - Increases the shininess component of the material of the sphere. ",
	"X - Decreases the shininess component of the material of the sphere."
};

list<string> helpScreenLines(help_screen, 
			     help_screen + sizeof help_screen / sizeof help_screen[0] );

inline void checkPal() {
#if 0
	int r,g,b;
	for (int i = CWinColors; i < 256; ++i) {
		GrQueryColor(i,&r,&g,&b);
		assert(!(r==255 && g==0 && b==0));
	}
#endif
}
void printLines(const pl_Cam *cam, const list<string> &lines)
 {
	list<string>::const_iterator it;
	int i;
	for (it = lines.begin(), i = 0; it != lines.end(); ++it, i += 11) {
		plTextPutStr(const_cast<pl_Cam *>(cam), 5, i, 0.0, 
			     CTextColor, (pl_sChar *)it->c_str());
	}
}

void dumpMaterial(pl_Mat *mat, list<string> &l) {
	ostringstream buf;

	l.clear();
	if (mat) {
		buf << "A:" << setw(4) << mat->Ambient[0] << setw(4) << mat->Ambient[1] << setw(4) << mat->Ambient[2] << ends;
		l.push_back(buf.str()); buf.seekp(0);
		buf << "D:" << setw(4) << mat->Diffuse[0] << setw(4) << mat->Diffuse[1] << setw(4) << mat->Diffuse[2] << ends;
		l.push_back(buf.str()); buf.seekp(0);
		buf << "S:" << setw(4) << mat->Specular[0] << setw(4) << mat->Specular[1] << setw(4) << mat->Specular[2] << ends;
		l.push_back(buf.str()); buf.seekp(0);
		buf << "Shininess:" << setw(4) << mat->Shininess << ends;
		l.push_back(buf.str()); buf.seekp(0);
		buf << "Transparent:" << setw(4) << (int)mat->Transparent << ends;
		l.push_back(buf.str()); buf.seekp(0);
	} else {
		buf << "Kein Material ausgew�hlt." << ends;
		l.push_back(buf.str()); buf.seekp(0);
	}
}

void reloadPalette(Scene &scene) 
{
	int i;
	// Fixed colors
	for (i = CWinColors; i < CFixColors; ++i) {
		GrSetColor(i, 0, 0, 0);
	}
	GrSetColor(CTextColor, 0, 192, 0); // Textcolor
	checkPal();

	scene.makePalette(ThePalette, CFixColors, 255);
	for (i = CFixColors; i < 256; i++) {
		GrSetColor(i, ThePalette[ i*3 ], ThePalette[ i*3 + 1], ThePalette[ i*3 + 2 ]);
		checkPal();
	}
}

void renderScene(string file) {
  char lastmessage[80] = "";
  GrMouseEvent evt;
  int width=screen_w, height=screen_h, bpp=BPP;
  bool helpDisplayed = false;

  GrSetMode( GR_width_height_bpp_graphics,width,height,bpp );
  GrSetWindowTitle((char *)WINTITLE);
  GrMouseInit();

  char *memory[4] = {(char *)TheFrameBuffer,0,0,0};
  GrContext *ctx =
  GrCreateContext(screen_w,screen_h,memory,NULL);

  cout << "Rendering" << endl;
  Scene scene(screen_w, screen_h, TheZBuffer, TheFrameBuffer);
  scene.loadXML(file);
  pl_Cam *cam = NULL;
  pl_Mat *mat = NULL;
  pl_Obj *obj = NULL;
  bool doInit = true;
  bool matChanged = false;
  while( 1 ) {
	  if (doInit) {
		  doInit = false;
		  scene.loadXML(file);
		  reloadPalette(scene);
		  cam = scene.getCurrCamera();
		  mat = scene.findMaterial(CStdMat);
		  if (mat == NULL) {
			  string msg = string("Material \"") + CStdMat + "\" nicht gefunden.";
			  strcpy(lastmessage, msg.c_str());
		  }
		  obj = scene.findObject(CStdObj);
		  if (obj == NULL) {
			  string msg = string("Objekt \"") + CStdObj + "\" nicht gefunden.";
			  strcpy(lastmessage, msg.c_str());
		  }
	  }
	checkPal();
    GrMouseGetEvent(GR_M_KEYPRESS | GR_M_NOPAINT,&evt);
	checkPal();

	if (evt.flags & GR_M_KEYPRESS) {
		switch (evt.key) {
		case GrKey_Escape:
			return;
		case GrKey_l:	// Reload
		    strcpy((char *)lastmessage, "Reload");
			doInit = true;
			break;
		case GrKey_QuestionMark:	// help
			helpDisplayed = !helpDisplayed;
			break;
		case GrKey_q:
			incKomp( mat, Specular[0] );
			break;
		case GrKey_w:
			decKomp( mat, Specular[0] );
			break;
		case GrKey_e:
			incKomp( mat, Specular[1] );
			break;
		case GrKey_r:
			decKomp( mat, Specular[1] );
			break;
		case GrKey_t:
			incKomp( mat, Specular[2] );
			break;
		case GrKey_z:
			decKomp( mat, Specular[2] );
			break;
		case GrKey_a:
			incKomp( mat, Diffuse[0] );
			break;
		case GrKey_s:
			decKomp( mat, Diffuse[0] );
			break;
		case GrKey_d:
			incKomp( mat, Diffuse[1] );
			break;
		case GrKey_f:
			decKomp( mat, Diffuse[1] );
			break;
		case GrKey_g:
			incKomp( mat, Diffuse[2] );
			break;
		case GrKey_h:
			decKomp( mat, Diffuse[2] );
			break;
		case GrKey_1:
			incKomp( mat, Ambient[0] );
			break;
		case GrKey_2:
			decKomp( mat, Ambient[0] );
			break;
		case GrKey_3:
			incKomp( mat, Ambient[1] );
			break;
		case GrKey_4:
			decKomp( mat, Ambient[1] );
			break;
		case GrKey_5:
			incKomp( mat, Ambient[2] );
			break;
		case GrKey_6:
			decKomp( mat, Ambient[2] );
			break;
		case GrKey_F1:
			incKompI( mat, Transparent, (pl_uChar)0, (pl_uChar)4 );
			break;
		case GrKey_F2:
			decKompI( mat, Transparent, (pl_uChar)0, (pl_uChar)4 );
			break;
		case GrKey_y:
			incKompI( mat, Shininess, (pl_uInt)0, (pl_uInt)64 );
			break;
		case GrKey_x:
			decKompI( mat, Shininess, (pl_uInt)0 , (pl_uInt)64 );
			break;
		} 
	}
	if (matChanged && obj && mat) {
		matChanged = false;
		plMatInit(mat);
		reloadPalette(scene);
	}
	scene.render();

	if (helpDisplayed) {
		printLines(cam, helpScreenLines);
	} else {
		list<string> l;
		dumpMaterial(mat, l);
		printLines(cam, l);		
	}



	plTextPrintf(cam,cam->ClipLeft+5,cam->ClipBottom-12, 0.0,CTextColor,
		(pl_sChar *)lastmessage);

	GrBitBlt(NULL, 0, 0,ctx,
          0, 0, screen_w - 1, screen_h - 1, GrWRITE);
  }
  GrSetMode( GR_default_text );
}

extern "C" int
GRXMain(int argc, char **argv)
{
	try 
	{
		if (!(1 <= argc && argc <= 2)) {
			cerr << "Usage: " << argv[0] << " [scene.xml]" << endl;
			return 1;
		}
		memset(ThePalette, 0, sizeof ThePalette);

		const char *filename = (argc == 2) ? argv[1] : defFileName;

		// Rendering
		cout << "Start rendering" << endl;
		renderScene(filename);
		cout << "Rendering ok" << endl;
	}
	catch (exception &e) 
	{
		cerr << "Exception: " << e.what( ) << endl;
		cerr << "Typ: " << typeid(e).name( ) << endl;
	};
  return 0;
}

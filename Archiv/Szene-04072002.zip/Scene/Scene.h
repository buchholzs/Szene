// Copyright (c) 2002 Steffen Buchholz

// NOTE: please use a PRESERVE:BEGIN/PRESERVE:END comment block
//       to preserve your hand-coding across code generations.

#ifndef _Scene_H_
#define _Scene_H_

// PRESERVE:BEGIN
#include <stdexcept>
#include <string>
#include <map>
using namespace std;

#include <plush.h>
#include "sc_tokens.h"

/*
** Konstanten
*/
const pl_Float ASPECT_RATIO = 1.0;
const pl_Float FOV = 90.0;
// PRESERVE:END

// Forward decl
struct sc_TokenPair;

class Scene {
public:
  class ParseError : public logic_error {
	public:
		ParseError(const string& message) : logic_error(message) {} 
	};

	Scene () 
	{
		init(0, 0, 0, 0, ASPECT_RATIO);
	}
	Scene(pl_uInt screenWidth, pl_uInt screenHeight, pl_ZBuffer *zBuffer,
		pl_uChar *frameBuffer, pl_Float aspectRatio = ASPECT_RATIO)
	{
		init(screenWidth, screenHeight, zBuffer, 
			frameBuffer, aspectRatio);
	}
	virtual ~Scene ();

	// Liefert die z.Zt. selektierte Kamera
	void	setCurrCamera (pl_Cam *cam);

	// Liefert die aktive Kamera
	pl_Cam*	getCurrCamera ();

	// L�dt eine Szenebeschreibung im XML-Format
	void	loadXML (const string &fileName);

	// Liefert eine Kamera aus der Szenebeschreibung
	pl_Cam*	findCamera (const string &name);

	// Liefert ein Licht aus der Szenebeschreibung
	pl_Light*	findLight (const string &name);

	// Liefert ein Material aus der Szenebeschreibung
	pl_Mat*	findMaterial (const string &name);

	// Liefert ein Objekt aus der Szenebeschreibung
	pl_Obj*	findObject (const string &name);

	// Liefert eine Textur aus der Szenebeschreibung
	pl_Texture*	findTexture (const string &name);

	// Rendert eine Szene mit der ausgew�hlten Kamera 
	void	render ();

	// Gibt eine Beschreibung der Szene auf den Stream aus
	void	dump (const ostream &str);

	// Erzeugt eine Camera anhand der Attributliste
	void createCamera(const char **attr);

	// Erzeugt ein Light anhand der Attributliste
	void createLight(const char **attr);

	// Erzeugt eine Textur anhand der Attributliste
	void createTexture(const char **attr);

	// Erzeugt ein Material anhand der Attributliste
	void createMaterial(const char **attr);

	// Erzeugt ein Object anhand der Attributliste
	void createObject(enum sc_Tokens tok, const char **attr);

	// Erzeugt ein Object aus einer Datei anhand der Attributliste
	void createObjectFromFile(enum sc_Tokens tok, const char **attr);

	// Erzeugt eine Transformation anhand der Attributliste
	void createTransformation(enum sc_Tokens tok, const char **attr);

	/*
	** Berechnet eine Palette aus den vorhandenen Materialien 
	** und mappt diese anschlie�end auf die Palette
	** 
	** Parameter:
	**	pal : Palette, ein 768 byte-Array von unsigned chars,
	**		  3 bilden zusammen ein RGB-Tripel
	**  pstart : Startoffset, normal 0
	**  pend : Endoffset, normal 255
	*/
	void makePalette(pl_uChar *pal, pl_sInt pstart, pl_sInt pend);

	typedef map<string, pl_Cam*> CamMap;
	typedef map<string, pl_Light*> LightMap;
	typedef map<string, pl_Obj*> ObjMap;
	typedef map<string, pl_Mat*> MatMap;
	typedef map<string, pl_Texture*> TextureMap;

protected:
	Scene (const Scene& rhs);
	Scene& operator = (const Scene &arg);

private:
	// Initialisiert wichtige Attribute
	void init(pl_uInt screenWidth, pl_uInt screenHeight, pl_ZBuffer *zBuffer,
		pl_uChar *frameBuffer, pl_Float aspectRatio_);

	// L�scht die geladene Szene
	void clear ();

	CamMap	cameras_;
	LightMap	lights_;
	ObjMap	objects_;
	MatMap	materials_;
	TextureMap textures_;
	pl_Cam *currCam_;

	pl_uInt screenWidth_;	// Screen width
	pl_uInt screenHeight_;	// Screen height
	pl_ZBuffer *zBuffer_; // Z Buffer
	pl_uChar *frameBuffer_; // Frame buffer (screenWidth_ * screenHeight_)
	pl_Float aspectRatio_;	// Aspect ratio (normalerweise 1.0)
};

#endif
